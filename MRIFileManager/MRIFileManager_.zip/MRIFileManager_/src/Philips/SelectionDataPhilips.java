package Philips;

import javax.swing.JPopupMenu;

import AbstractClass.PrefParam;
import AbstractClass.SelectionData;
import MRIFileManager.FileManagerFrame;

public class SelectionDataPhilips extends SelectionData {
		
	private String dataSelected;
	
	public SelectionDataPhilips(FileManagerFrame wind) throws Exception {
		super();
		dataSelected = wind.getListPath().getSelectedItem().toString() + PrefParam.separator
				+ wind.getTabData().getValueAt(wind.getTabData().getSelectedRow(), 1);
		dataSelected = dataSelected.substring(12);
	}

	@Override
	public void popMenuData(JPopupMenu popMenu) {
		}
}