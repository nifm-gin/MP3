package Philips;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import MRIFileManager.ExtractTxtfromFile;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;

public class GetInfofromPar2 implements DictionParRec, ListPhilipsParamData2 {

	private HashMap<String, String> InformationPar = new HashMap<>();

	String[] listImgNbr = new String[6];
	// listImgNbr[0] = slice number
	// listImgNbr[1] = echo number
	// listImgNbr[2] = dynamic number
	// listImgNbr[3] = Image Type
	// listImgNbr[4] = diffusion number
	// listImgNbr[5] = gradient number

	String[] listRSI = new String[3];
	// listImgNbr[0] = RI
	// listImgNbr[1] = RS
	// listImgNbr[2] = SS

	public GetInfofromPar2(String file, boolean all) {

		String txt, txtGI, txtII, strLine = "";
		String[] columDetail;

		txt = new ExtractTxtfromFile(file).getTxt();

		/*********************************
		 * General Information
		 ***************************************/
		txtGI = txt.substring(txt.indexOf("= GENERAL INFORMATION ="));
		txtGI = txtGI.substring(txtGI.indexOf("\n") + 1);
		txtGI = txtGI.substring(txtGI.indexOf("\n") + 1, txtGI.indexOf("# === PIXEL VALUES =") - 3);

		String tmpj;

		try {
			BufferedReader bg = new BufferedReader(new StringReader(txtGI));
			strLine = "";
			while ((strLine = bg.readLine()) != null) {
				tmpj = strLine.substring(4, strLine.indexOf(":")).trim();
				try {
					tmpj = tmpj.replaceAll("\\[(.*?)\\]", "");
					tmpj = tmpj.replaceAll("\\((.*?)\\)", "");
					tmpj = tmpj.replaceAll("\\<(.*?)\\>", "");
					tmpj = tmpj.replaceAll("\\?", "");
				} catch (Exception e) {
					// new GetStackTrace(e);
					// FileManagerFrame.getBugText().setText(
					// FileManagerFrame.getBugText().getText() +
					// "\n----------------\n" + GetStackTrace.getMessage());
				}
				InformationPar.put(tmpj.trim(), strLine.substring(strLine.indexOf(":   ") + 4).trim());
			}
		} catch (Exception e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(GetStackTrace.getMessage());
		}

		if (all) {

			/*********************************
			 * Image Information
			 ***************************************/
			txtII = txt.substring(txt.indexOf("= IMAGE INFORMATION ="));
			txtII = txtII.substring(txtII.indexOf("\n") + 1);
			txtII = txtII.substring(txtII.indexOf("\n") + 1);
			txtII = txtII.substring(txtII.indexOf("\n") + 1, txtII.indexOf("# === END OF DATA DESCRIPTION FILE =") - 4);

			ArrayList<String[]> listColumn = new ArrayList<String[]>();

			try {
				BufferedReader br = new BufferedReader(new StringReader(txtII));
				strLine = "";
				while ((strLine = br.readLine()) != null) {
					columDetail = strLine.trim().split(" +");
					// if (Integer.parseInt(columDetail[4]) < 4)
					listColumn.add(columDetail);
				}
			} catch (Exception e) {
			}

			for (int i = 0; i < listImgNbr.length; i++)
				listImgNbr[i] = "";

			for (int i = 0; i < listRSI.length; i++)
				listRSI[i] = "";

			for (int i = 0; i < listColumn.size(); i++) {
				listImgNbr[0] += listColumn.get(i)[0] + " "; // slice number
				listImgNbr[1] += listColumn.get(i)[1] + " "; // echo number
				listImgNbr[2] += listColumn.get(i)[2] + " "; // dynamic number
				listImgNbr[3] += listColumn.get(i)[4] + " "; // image type
				listImgNbr[4] += listColumn.get(i)[41] + " "; // diffusion number
				listImgNbr[5] += listColumn.get(i)[42] + " "; // gradient number
				listRSI[0] += listColumn.get(i)[11] + " "; // RI
				listRSI[1] += listColumn.get(i)[12] + " "; // RS
				listRSI[2] += listColumn.get(i)[13] + " "; // SS
			}

			Collections.sort(listColumn, new Comparator<Object[]>() {
				@Override
				public int compare(Object[] strings, Object[] otherStrings) {
					return ((Integer) Integer.parseInt(strings[0].toString()))
							.compareTo(Integer.parseInt(otherStrings[0].toString()));
				}
			});

			String[] imageInfoLine = new String[imageInformationParRec.length];
			for (int i = 0; i < imageInfoLine.length; i++)
				imageInfoLine[i] = "";

			for (int i = 0; i < listColumn.size(); i++) {
				for (int j = 0; j < imageInfoLine.length; j++) {
					String tmp = listColumn.get(i)[Integer.parseInt(imageInformationParRec[j][1])];
					imageInfoLine[j] += tmp + " ";
					if (j == 9 || j == 23)
						imageInfoLine[j] += listColumn.get(i)[Integer.parseInt(imageInformationParRec[j][1]) + 1]
								+ "] [";
					if (j == 15 || j == 16 || j == 39)
						imageInfoLine[j] += listColumn.get(i)[Integer.parseInt(imageInformationParRec[j][1]) + 1] + " "
								+ listColumn.get(i)[Integer.parseInt(imageInformationParRec[j][1]) + 2] + "] [";
				}
			}

			for (int i = 0; i < imageInformationParRec.length; i++) {
				InformationPar.put(imageInformationParRec[i][0], deleteDuplicate(imageInfoLine[i]));
			}
		}
	}

	private String deleteDuplicate(String elements) {

		String resul = "";
		String[] list = null;

		if (!elements.contains("]"))
			list = elements.split(" +");
		else {
			list = elements.split("\\] \\[");
		}

		List<String> array = Arrays.asList(list);
		Set<String> hs = new LinkedHashSet<>(array);
		list = Arrays.copyOf(hs.toArray(), hs.toArray().length, String[].class);

		for (String hh : list)
			resul += hh + " ";

		return resul.trim();
	}

	@Override
	public HashMap<String, String> getInfoImage() {
		return InformationPar;
	}

	@Override
	public String[] getListImgNbr() {
		return listImgNbr;
	}

	@Override
	public String[] getListRSI() {
		return listRSI;
	}
}