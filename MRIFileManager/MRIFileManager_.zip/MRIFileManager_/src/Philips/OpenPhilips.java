package Philips;

import java.awt.EventQueue;
import java.util.HashMap;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;
import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.gui.StackWindow;
import ij.io.FileInfo;
import ij.io.FileOpener;
import ij.measure.Calibration;
import ij.plugin.HyperStackConverter;
import ij.process.ImageProcessor;

public class OpenPhilips implements ParamMRI2 {

	private ImagePlus imp;
	private int c, z, t;

	public OpenPhilips(HashMap<String, String> infoIm, Object[] orderIm, Boolean show, Boolean convert, String title) {

		String tmp = null, order;
		int w, h;
		float pxw, pxh;

		int nimages, nslice, necho, ntype, ndynamic, ndiffusion;
		int nbtype = 1;
		int currentSlice = 1, currentEcho = 1, currentDynamic = 1, currentType = 1, currentDiffusion = 1;

		double RS = 0;
		double RI = 0;
		double SS = 0;

		nimages = Integer.parseInt(infoIm.get("Images In Acquisition"));
		nslice = Integer.parseInt(infoIm.get("Number Of Slice"));
		necho = Integer.parseInt(infoIm.get("Number Of Echo"));
		ntype = infoIm.get("Image Type").split(" +").length;
		ndiffusion = Integer.parseInt(infoIm.get("Number Of Diffusion").trim());
		ndynamic = Integer.parseInt(infoIm.get("Number Of Repetition"));
		nbtype = ntype;
		
//		System.out.println(nimages+","+nslice+","+necho+","+ntype+","+ndiffusion+","+ndynamic+","+ntype);

		/****************************************************
		 * create imp
		 *****************************************************/
		tmp = infoIm.get("Scan Resolution");
		w = Integer.parseInt(tmp.split(" +")[0]);
		h = Integer.parseInt(tmp.split(" +")[1]);

		pxw = Float.parseFloat(infoIm.get("Spatial Resolution").split(" +")[0]);
		pxh = Float.parseFloat(infoIm.get("Spatial Resolution").split(" +")[1]);

//		System.out.println(w + "," + h + "," + pxw + "," + pxh);
		
		order = orderIm[0].toString();
		c = (int) orderIm[1];
		z = (int) orderIm[2];
		t = (int) orderIm[3];

//		System.out.println(c + "," + z + "," + t);

		FileInfo fi = new FileInfo();

		tmp = infoIm.get("Data Type");

		if (tmp.contains("16"))
			fi.fileType = FileInfo.GRAY16_UNSIGNED;
		else if (tmp.contains("32"))
			fi.fileType = FileInfo.GRAY32_FLOAT;
		else {
			fi.fileType = FileInfo.GRAY8;
		}

		tmp = infoIm.get("File path");

		fi.fileFormat = FileInfo.RAW;
		fi.fileName = tmp;
		fi.width = w;
		fi.height = h;
		fi.offset = 0;
		fi.gapBetweenImages = 0;

		fi.intelByteOrder = true;

		fi.unit = "mm";
		fi.valueUnit = "mm";

		fi.nImages = nimages;

		fi.pixelWidth = pxw;
		fi.pixelHeight = pxh;

		tmp = infoIm.get("Slice Thickness");

		fi.pixelDepth = Float.parseFloat(tmp);

		FileOpener fo = new FileOpener(fi);
		imp = fo.open(false);

		imp.setTitle(title);
		if (show || convert)
			imp = convertToGray32(imp);

		if (nimages != ntype * ndynamic * ndiffusion * necho * nslice) {
			nbtype = 1;
		}

		ImageStack imgOrdered;

		imgOrdered = new ImageStack(imp.getWidth(), imp.getHeight(), nbtype * ndynamic * ndiffusion * necho * nslice);

		ImagePlus imtmp = new ImagePlus();
		imtmp.setDimensions(nbtype * ndiffusion, nslice, necho * ndynamic);

		// System.out.println(nbtype * ndiffusion + "," + nslice + "," + necho *
		// ndynamic);

		for (int i = 0; i < nimages; i++) {
			currentSlice = Integer.parseInt(orderIm[5].toString().split(" +")[i]);
			currentEcho = Integer.parseInt(orderIm[6].toString().split(" +")[i]);
			currentDynamic = Integer.parseInt(orderIm[7].toString().split(" +")[i]);
			currentType = Integer.parseInt(orderIm[8].toString().split(" +")[i]);
			currentDiffusion = Integer.parseInt(orderIm[9].toString().split(" +")[i]);

			imp.setSlice(i + 1);

			if (convert || show) {

				RI = Double.parseDouble(orderIm[11].toString().split(" +")[i]);
				RS = Double.parseDouble(orderIm[12].toString().split(" +")[i]);
				SS = Double.parseDouble(orderIm[13].toString().split(" +")[i]);

				imp.getProcessor().multiply(1 / SS);
				if (RS != 0.0)
					imp.getProcessor().add(RI / (RS * SS));
			}

			if (ntype == 1)
				imgOrdered.setProcessor(imp.getProcessor(),
						imtmp.getStackIndex(currentDiffusion, currentSlice, currentEcho * currentDynamic));
			else if (currentType < 4) {
				imgOrdered.setProcessor(imp.getProcessor(), imtmp.getStackIndex((currentType + 1) * currentDiffusion,
						currentSlice, currentEcho * currentDynamic));
			}
		}

		imp.setStack(imgOrdered);
		imp.resetDisplayRange();
		imp = HyperStackConverter.toHyperStack(imp, c, z, t, order, "grayscale");

		if (show) {
			EventQueue.invokeLater(new Runnable() {
				@Override
				public void run() {
					new StackWindow(imp);
				}
			});
			imp.close();
		}
	}

	public ImagePlus getImp() {
		return imp;
	}

	private ImagePlus convertToGray32(ImagePlus imgtmp) {

		int width = imgtmp.getWidth();
		int height = imgtmp.getHeight();
		int nSlices = imgtmp.getStackSize();

		if (imgtmp.getType() != ImagePlus.GRAY32) {
			ImageStack stack1 = imgtmp.getStack();
			ImageStack stack2 = new ImageStack(width, height);
			String label;
			int inc = nSlices / 20;
			if (inc < 1)
				inc = 1;
			ImageProcessor ip1, ip2;
			Calibration cal = imgtmp.getCalibration();
			for (int i = 1; i <= nSlices; i++) {
				label = stack1.getSliceLabel(1);
				ip1 = stack1.getProcessor(1);
				ip1.setCalibrationTable(cal.getCTable());
				ip2 = ip1.convertToFloat();
				stack1.deleteSlice(1);
				stack2.addSlice(label, ip2);
				if ((i % inc) == 0) {
					IJ.showProgress((double) i / nSlices);
					IJ.showStatus("Converting to 32-bits: " + i + PrefParam.separator + nSlices);
				}
			}
			IJ.showProgress(1.0);
			imgtmp.setStack(null, stack2);
			imgtmp.setCalibration(imgtmp.getCalibration()); // update
															// calibration
		}
		return imgtmp;
	}

}