package Philips;

import java.io.File;
import java.io.IOException;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;

public class ListPhilipsData extends PrefParam implements ParamMRI2 {

	private String chemPar;
	private String[] paramListData = headerListData;

	public ListPhilipsData(String chemPar) {
		this.chemPar = chemPar;
	}

	public Object[] listParamDataPhilips() throws IOException {
		Object[] resul = new Object[8];

		File f = new File(searchPhilips(".REC", chemPar));

		File fp = new File(f.getAbsolutePath().replace(".REC", ".PAR"));

		ListPhilipsParamData2 infoParam = null;
		int ind=0;

		if (fp.exists()) {
			infoParam = new GetInfofromPar2(fp.getAbsolutePath(),false);
		} else {
			infoParam = new GetInfofromXML2(f.getAbsolutePath().replace(".REC", ".XML"),false);
			ind=1;
		}

		resul[0] = iconPhilips;
		resul[1] = chemPar;

		String tmp = null;
		for (int i = 2; i < resul.length; i++) {
			try {
			tmp = dictionaryMRISystem.get(paramListData[i]).get("keyName").split(";")[ind].trim();
			resul[i] = infoParam.getInfoImage().get(tmp);
			} catch (Exception e) {
				resul[i]="";
			}
		}

		return resul;
	}

	private String searchPhilips(String extToFind, String searchIn) {

		String filePhilips = null;
		String[] listOfFiles = new File(searchIn).list();

		int i = 0;

		try {
			while (i < listOfFiles.length) {
				if (listOfFiles[i].endsWith(extToFind)) {
					filePhilips = listOfFiles[i];
					break;
				}
				i++;
			}
		} catch (Exception e) {

		}
		return searchIn + separator + filePhilips;
	}
}