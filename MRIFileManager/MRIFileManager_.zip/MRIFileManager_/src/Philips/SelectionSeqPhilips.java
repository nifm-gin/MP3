package Philips;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;
import AbstractClass.SelectionSeq;
import ExportFiles.GetListFieldFromFilestmpRep;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;
import MRIFileManager.OpenImageJ;
import MRIFileManager.ShowImagePanel;
import MRIFileManager.ThumbnailList;
import MRIFileManager.TreeInfo2;
import ij.IJ;
import ij.ImagePlus;

public class SelectionSeqPhilips implements ParamMRI2, SelectionSeq {

	private FileManagerFrame wind;
	private String seqSelected;

	public SelectionSeqPhilips(FileManagerFrame wind) {
		this.wind = wind;
		seqSelected = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRow(), 0).toString();
	}

	@Override
	public void goSelectionSeq() {

		try {
			wind.getTreeInfoGeneral()
					.setModel(new TreeInfo2(listParamInfoSystem, hmInfo.get(seqSelected)).getTreeInfo().getModel());
			for (int j = 0; j < wind.getTreeInfoGeneral().getRowCount(); j++)
				wind.getTreeInfoGeneral().expandRow(j);
			wind.getTreeInfoUser()
					.setModel(new TreeInfo2(listParamInfoUser, hmInfo.get(seqSelected)).getTreeInfo().getModel());
			for (int j = 0; j < wind.getTreeInfoUser().getRowCount(); j++)
				wind.getTreeInfoUser().expandRow(j);
		} catch (Exception e1) {
			new GetStackTrace(e1);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
		}

		try{
		new ShowImagePanel(wind,new OpenPhilips(hmInfo.get(seqSelected), hmOrderImage.get(seqSelected), false, false,seqSelected).getImp(),
				seqSelected);
		} catch (Exception e) {
			URL imgURLError = getClass().getResource("/errorFile.jpg");
			new ShowImagePanel(wind,new ImagePlus("",new ImageIcon(imgURLError).getImage()),seqSelected);
			
		}

		String seqSel;

		if (wind.getTabSeq().getSelectedRowCount() == 1) {
			seqSel = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[0], 0).toString();
			ThumbnailList.list.setSelectedValue(seqSel, true);
		} else {
			int[] ls = new int[wind.getTabSeq().getSelectedRowCount()];
			for (int i = 0; i < wind.getTabSeq().getSelectedRowCount(); i++) {
				seqSel = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i], 0).toString();
				for (int g = 0; g < ThumbnailList.list.getModel().getSize(); g++)
					if (ThumbnailList.list.getModel().getElementAt(g) == seqSel)
						ls[i] = g;
			}
			ThumbnailList.list.setSelectedIndices(ls);
		}
	}

	@Override
	public void popMenuSeq(JPopupMenu pm) {

		JMenuItem sampleOpen = new JMenuItem("Open image(s) Ctrl+o");
		pm.add(sampleOpen);
		sampleOpen.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				openImage();
			}
		});

		/*********************************************************************************/
		pm.addSeparator();
		/*********************************************************************************/
		JMenuItem openParamFile = new JMenuItem("see PAR/Xml file");
		pm.add(openParamFile);
		openParamFile.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				showParamFile(hmSeq.get(seqSelected)[0], "see PAR/Xml file");
			}
		});

		/*********************************************************************************/
		pm.addSeparator();
		/*********************************************************************************/
		JMenuItem addBasket = new JMenuItem("Add to basket Ctrl+b");
		pm.add(addBasket);

		addBasket.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				fillBasket();
			}
		});
	}

	@Override
	public void openImage() {
		new OpenImageJ();

		for (int i = 0; i < wind.getTabSeq().getSelectedRowCount(); i++) {
			String seqSelected = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i], 0).toString();
//			new FillHmsPhilips(seqSelected);
			new OpenPhilips(hmInfo.get(seqSelected), hmOrderImage.get(seqSelected), true, false,seqSelected);
		}
	}

	@Override
	public void showParamFile(String chemPar, String keyword) {

		String pathFile = null;
		String tm = "";
		boolean fileOk = false;

		if (keyword.contentEquals("see PAR/Xml file")) {

			pathFile = chemPar.replace(".REC", ".PAR");

			if (!new File(pathFile).exists())
				pathFile = chemPar.replace(".REC", ".Xml");

			if (!new File(pathFile).exists()) {
				JOptionPane.showMessageDialog(wind, "PAR/Xml doesn't exist");
				return;
			}
		}

		try {
			BufferedInputStream in = new BufferedInputStream(new FileInputStream(pathFile));
			StringWriter out = new StringWriter();
			int b;
			while ((b = in.read()) != -1)
				out.write(b);
			out.flush();
			out.close();
			in.close();
			tm = tm + out.toString();
			fileOk = true;

		} catch (IOException e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
		}

		if (fileOk) {
			new OpenImageJ();
			IJ.log(tm);
		}
	}

	@Override
	public void fillBasket() {

		String seqSel = null;
		String listInBask = "[Philips] ";

		GetListFieldFromFilestmpRep dg = new GetListFieldFromFilestmpRep(PrefParam.namingNiftiExport);

		for (int i = 0; i < wind.getTabSeq().getSelectedRowCount(); i++) {

			listInBask = "[Philips] ";
			seqSel = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i], 0).toString();
			new FillHmsPhilips(seqSel);

			if (hmInfo.get(seqSel).get("Slice Orientation").split(" ").length > 1)
				JOptionPane.showMessageDialog(wind, "Can't export seq. n� " + seqSel + " (number of orientation > 1)");

			else {
				for (String gk : dg.getListFieldTrue()) {
					if (gk.contains("Patient Name") || gk.contains("Study Name") || gk.contains("Creation Date")) {
						listInBask += (String) wind.getTabData().getValueAt(wind.getTabData().getSelectedRow(),
								wind.getTabData().getColumn(gk).getModelIndex());
					}
					if (gk.contains("Seq. n�") || gk.contains("Protocol") || gk.contains("Sequence Name")) {
						listInBask += (String) wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i],
								wind.getTabSeq().getColumn(gk).getModelIndex());
					}
					listInBask += dg.getSeparateChar();
				}
				listInBask = listInBask.substring(0, listInBask.lastIndexOf(dg.getSeparateChar()));

				int n = 0;

				if (listinBasket.contains(listInBask)) {
					n = JOptionPane.showOptionDialog(null,
							listInBask + "\n" + "This already exits, Do you want to overwrite it? ", "Warning",
							JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
							new Object[] { "Yes", "No" }, "No");
				}

				if (n == 0) {
					listinBasket.removeElement(listInBask);
					listinBasket.add(listinBasket.size(), listInBask);
					listBasket_hms.put(listInBask, hmInfo.get(seqSel));
					listBasket_hmo.put(listInBask, hmOrderImage.get(seqSel));
				}

			}
		}
		wind.getListBasket().setModel(listinBasket);
		wind.getListBasket().updateUI();
		wind.getTabbedPane().setSelectedIndex(1);
		wind.getTabbedPane().setTitleAt(1, "Basket " + "(" + listinBasket.size() + ")");
	}
}