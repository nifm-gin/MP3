package Philips;

public interface ListPhilipsParamData {

	Object[] getInfoGeneral();
	
	Object[] getInfoImage();
	
	String[] getListImgNbr();
	
	String[] getListRSI();
	
}