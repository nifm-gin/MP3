package Philips;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;

public class GetInfofromXML2 implements DictionParRec, ListPhilipsParamData2 {

	private HashMap<String, String> InformationXml = new HashMap<>();

	public String[] ImageInformationXml = new String[50];

	String[] listImgNbr = new String[6];
	// listImgNbr[0] = slice number
	// listImgNbr[1] = echo number
	// listImgNbr[2] = dynamic number
	// listImgNbr[3] = Image Type
	// listImgNbr[4] = diffusion number
	// listImgNbr[5] = gradient number

	String[] listRSI = new String[3];
	// listImgNbr[0] = RI
	// listImgNbr[1] = RS
	// listImgNbr[2] = SS

	public GetInfofromXML2(String file, boolean all) {

		for (int i = 0; i < listImgNbr.length; i++)
			listImgNbr[i] = "";

		for (int i = 0; i < listRSI.length; i++)
			listRSI[i] = "";

		Document doc = null;
		SAXBuilder sxBuild = new SAXBuilder();

		try {
			doc = sxBuild.build(new File(file));
		} catch (Exception e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
		}
		Iterator<Element> ite1, ite2;
		Element classElement = doc.getRootElement();
		List<Element> stdlist = classElement.getChildren();

		/*****************************************
		 * GENERAL INFORMATION
		 ***********************************************/
		Element seriesInfo = stdlist.get(0);
		List<Element> list1 = seriesInfo.getChildren();
		ite1 = list1.iterator();

		while (ite1.hasNext()) {
			Element std1 = ite1.next();
			InformationXml.put(std1.getAttributeValue("Name"), std1.getValue());
		}

		String mp;

		mp = InformationXml.get("FOV AP");
		mp += " " + InformationXml.get("FOV FH") + " " + InformationXml.get("FOV RL");
		InformationXml.put("FOV AP", mp);

		mp = InformationXml.get("Angulation AP");
		mp += " " + InformationXml.get("Angulation FH") + " " + InformationXml.get("Angulation RL");
		InformationXml.put("Angulation AP", mp);

		mp = InformationXml.get("Off Center AP");
		mp += " " + InformationXml.get("Off Center FH") + " " + InformationXml.get("Off Center RL");
		InformationXml.put("Off Center AP", mp);

		if (all) {
			/*****************************************
			 * IMAGE INFORMATION
			 ***********************************************/

			Element imageArray = stdlist.get(1);
			List<Element> list2 = imageArray.getChildren();
			ite1 = list2.iterator();
			String columnDetail = "";
			ArrayList<String[]> listColumn = new ArrayList<String[]>();

			while (ite1.hasNext()) {
				Element std2 = ite1.next();
				List<Element> list3 = std2.getChildren();
				columnDetail = "";

				for (int h = 0; h < list3.size(); h++) {

					if (list3.get(h).getChildren().size() != 0) {
						List<Element> list4 = list3.get(h).getChildren();
						ite2 = list4.iterator();

						while (ite2.hasNext()) {
							Element std4 = ite2.next();
							columnDetail = columnDetail + std4.getValue() + " ";
						}
					} else {
						columnDetail = columnDetail + list3.get(h).getValue() + " ";
					}
				}
				String[] column = columnDetail.split((" +"));
				listColumn.add(column);
			}

			for (int k = 0; k < listImgNbr.length; k++)
				listImgNbr[k] = "";

			for (int k = 0; k < listColumn.size(); k++) {
				listImgNbr[0] += listColumn.get(k)[0] + " "; // slice number
				listImgNbr[1] += listColumn.get(k)[1] + " "; // echo number
				listImgNbr[2] += listColumn.get(k)[2] + " "; // dynamic number
				listImgNbr[3] += listColumn.get(k)[7] + " "; // image type
				listImgNbr[4] += listColumn.get(k)[4] + " "; // diffusion number
				listImgNbr[5] += listColumn.get(k)[5] + " "; // gradient number
				listRSI[0] += listColumn.get(k)[15] + " "; // RI
				listRSI[1] += listColumn.get(k)[16] + " "; // RS
				listRSI[2] += listColumn.get(k)[17] + " "; // SS
			}

			Collections.sort(listColumn, new Comparator<Object[]>() {
				@Override
				public int compare(Object[] strings, Object[] otherStrings) {
					return ((Integer) Integer.parseInt(strings[0].toString()))
							.compareTo(Integer.parseInt(otherStrings[0].toString()));
				}
			});

			String[] imageInfoLine = new String[imageInformationXmlRec.length];
			for (int i = 0; i < imageInfoLine.length; i++)
				imageInfoLine[i] = "";

			for (int i = 0; i < listColumn.size(); i++) {
				for (int j = 0; j < imageInfoLine.length; j++) {
					String tmp = listColumn.get(i)[Integer.parseInt(imageInformationXmlRec[j][1])];
					imageInfoLine[j] += tmp + " ";
					if (j == 12 || j == 24)
						imageInfoLine[j] += listColumn.get(i)[Integer.parseInt(imageInformationXmlRec[j][1]) + 1]
								+ "] [";
					if (j == 39 || j == 42 || j == 45)
						imageInfoLine[j] += listColumn.get(i)[Integer.parseInt(imageInformationXmlRec[j][1]) + 1] + " "
								+ listColumn.get(i)[Integer.parseInt(imageInformationXmlRec[j][1]) + 2] + "] [";
				}
			}
			for (int i = 0; i < imageInformationXmlRec.length; i++) {
				InformationXml.put(imageInformationXmlRec[i][0], deleteDuplicate(imageInfoLine[i]));
			}
		}
	}

	private String deleteDuplicate(String elements) {

		String resul = "";
		String[] list = null;

		if (!elements.contains("]"))
			list = elements.split(" +");
		else {
			list = elements.split("\\] \\[");
		}

		List<String> array = Arrays.asList(list);
		Set<String> hs = new LinkedHashSet<>(array);
		list = Arrays.copyOf(hs.toArray(), hs.toArray().length, String[].class);

		for (String hh : list)
			resul += hh + " ";

		return resul.trim();
	}

	@Override
	public HashMap<String, String> getInfoImage() {
		return InformationXml;
	}

	@Override
	public String[] getListImgNbr() {
		String[] listType2 = { "M", "R", "I", "P", "CR", "T0", "T1", "T2", "RHO", "SPECTRO", "DERIVED", "ADC", "RCBV",
				"RCBF", "MTT", "TTP", "NC1", "NC2", "NC3" };
		String[] lo = listImgNbr[3].toString().split(" +");
		for (int i = 0; i < lo.length; i++) {
			listImgNbr[3] = listImgNbr[3].toString().replace(lo[i],
					String.valueOf(Arrays.asList(listType2).indexOf(lo[i])));
		}
		return listImgNbr;
	}

	@Override
	public String[] getListRSI() {
		return listRSI;
	}
}