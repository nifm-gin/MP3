package Philips;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import AbstractClass.ListParam2;
import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;

public class ListPhilipsParam2 extends PrefParam implements ParamMRI2, ListParam2 {

	private String pathPhilips;
	private HashMap<String, String> InfoImage;
	private String[] listImgNbr, listRSI;
	private int ind = 0;
	private String[] listType2 = { "M", "R", "I", "P", "CR", "T0", "T1", "T2", "RHO", "SPECTRO", "DERIVED", "ADC",
			"RCBV", "RCBF", "MTT", "TTP", "NC1", "NC2", "NC3" };
	// = 0 "M"
	// = 1 "R"
	// = 2 "I"
	// = 3 "P"
	// = 4 "CR"
	// = 5 "T0"
	// = 6 "T1"
	// = 7 "T2"
	// = 8 "RHO"
	// = 9 "SPECTRO"
	// = 10 "DERIVED"
	// = 11 "ADC"
	// = 12 "RCBV"
	// = 13 "RCBF"
	// = 14 "MTT"
	// = 15 "TTP"
	// = 16 "NC1"
	// = 17 "NC2"
	// = 18 "NC3"

	public ListPhilipsParam2(String pathPhilips) {
		this.pathPhilips = pathPhilips;
	}

	@Override
	public HashMap<String, String> ListParamValue() throws IOException {
		HashMap<String, String> lv = new HashMap<String, String>();
		String pathPhilips2;
		String acq = "", rec = "";
		pathPhilips2 = pathPhilips.replace(".REC", ".PAR");
		ind = 0;
		if (!new File(pathPhilips2).exists()) {
			pathPhilips2 = pathPhilips.replace(".REC", ".Xml");
			ind = 1;
		}

		ListPhilipsParamData2 philipsParam = null;

		switch (ind) {
		case 0:
			philipsParam = new GetInfofromPar2(pathPhilips2,true);
			InfoImage = philipsParam.getInfoImage();
			acq = InfoImage.get("Acquisition nr");
			rec = InfoImage.get("Reconstruction nr");
			break;
		case 1:
			philipsParam = new GetInfofromXML2(pathPhilips2,true);
			InfoImage = philipsParam.getInfoImage();
			acq = InfoImage.get("Aquisition Number");
			rec = InfoImage.get("Reconstruction Number");
			break;
		}

		if (acq.length() == 1)
			acq = "0" + acq;
		if (rec.length() == 1)
			rec = "0" + rec;

		// InfoImage = philipsParam.getInfoImage();
		listImgNbr = philipsParam.getListImgNbr();
		listRSI = philipsParam.getListRSI();

		File filePhilips = new File(pathPhilips);

		lv.put("noSeq", acq + "-" + rec);
		lv.put("File path", filePhilips.getAbsolutePath());
		lv.put("File Name", filePhilips.getName());
		lv.put("File Size (Mo)", String.valueOf(filePhilips.length() / (1024 * 1024.0)));

		for (String sg : dictionaryMRISystem.keySet()) {
			lv.put(sg, InfoImage.get(dictionaryMRISystem.get(sg).get("keyName").split(";")[ind].trim()));
		}

		for (String sg : dictionaryMRIUser.keySet()) {
			lv.put(sg, InfoImage.get(dictionaryMRIUser.get(sg).get("keyName").split(";")[ind].trim()));
		}

		String lvtmp;

		/************************************************
		 * recalculate Image in acq
		 ************************************************/
		lvtmp = lv.get("Images In Acquisition");
		lvtmp = String.valueOf(lvtmp.split(" +").length);
		lv.put("Images In Acquisition", lvtmp);

		/***************** modifify data type if <0 ********************/
		lvtmp = lv.get("Data Type");
		if (Integer.parseInt(lvtmp.trim()) < 0)
			lvtmp = "0";
		lv.put("Data Type", lvtmp);

		/******** modifiy echo number *********/
		lvtmp = lv.get("Number Of Echo");
		lvtmp = String.valueOf(lvtmp.trim().split(" +").length);
		lv.put("Number Of Echo", lvtmp);

		/*********** redefinite diffusion ****************/
		lvtmp = lv.get("Number Of Diffusion");
		if (!lvtmp.contentEquals("1"))
			lvtmp = String.valueOf(lvtmp.split(" +").length);
		lv.put("Number Of Diffusion", lvtmp);

		/********* redefinite Slice Thickness, added to Slice Gap *********/
		lvtmp = lv.get("Slice Thickness");
		String sliceGap = lv.get("Slice Gap");
		try {
			lvtmp = String.valueOf(Float.parseFloat(lvtmp) + Float.parseFloat(sliceGap));
		} catch (Exception e) {
			lvtmp = String.valueOf(Float.parseFloat(lvtmp.split(" +")[0]) + Float.parseFloat(sliceGap.split(" +")[0]));
			;
		}
		lv.put("Slice Thickness", lvtmp);

		/************************************************
		 * redefinite Slice Orientation
		 ************************************************/
		try {
			lvtmp = lv.get("Slice Orientation");
			String[] listOrient = { "", "axial", "sagittal", "coronal" };
			for (String gg : lvtmp.split(" +"))
				lvtmp = lvtmp.replace(gg, listOrient[Integer.parseInt(gg)]);
			lv.put("Slice Orientation", lvtmp);
		} catch (Exception e) {
		}

		/************************************************
		 * redefinite Image Type
		 ************************************************/
		lvtmp = lv.get("Image Type");

		try {
			for (String gg : lvtmp.split(" +"))
				lvtmp = lvtmp.replace(gg, listType2[Integer.parseInt(gg)]);
			lv.put("Image Type", lvtmp);
		} catch (Exception e) {
		}

		lv.put("MRI parameters", lvtmp);

		return lv;
	}

	@Override
	public Object[] ListOrderStack(String dim, String nImage) {
		String[] s1 = listImgNbr.clone();
		String[] s2 = listImgNbr.clone();

		// listImgNbr[0] = slice number
		// listImgNbr[1] = echo number
		// listImgNbr[2] = dynamic number
		// listImgNbr[3] = Image Type
		// listImgNbr[4] = diffusion number
		// listImgNbr[5] = gradient number

		String order = "";

		List<String> list = Arrays.asList(s2);

		Collections.sort(list, Collections.reverseOrder());

		for (String e : list) {
			for (int i = 0; i < s1.length; i++)
				if (s1[i].contentEquals(e) && !order.contains(String.valueOf(i))) {
					order += String.valueOf(i) + " ";
					break;
				}
		}

		for (int i = 4; i < 19; i++)
			s1[3] = s1[3].replace(String.valueOf(i), "");

		Set<String> uniqueWords;

		for (int i = 0; i < s1.length; i++) {
			uniqueWords = new HashSet<String>(Arrays.asList(s1[i].split(" +")));
			s1[i] = String.valueOf(uniqueWords.size());
		}

		// System.out.println(this+" : "+order);
		//
		// for (String yy : listImgNbr)
		// System.out.println(yy);
		//
		// for (String kk : s1)
		// System.out.println(kk);

		Object[] lv = new Object[14];

		// if (order.substring(0, 1).contentEquals("2"))
		// lv[0] = "xyczt";
		// else
		lv[0] = "xyczt";

		if (s1[3].contentEquals("0"))
			s1[3] = "1";

		if (Integer.parseInt(s1[4]) > 1)
			lv[0] = "xyctz";

		lv[1] = Integer.parseInt(s1[3]);
		lv[2] = Integer.parseInt(s1[0]);
		lv[3] = Integer.parseInt(s1[1]) * Integer.parseInt(s1[2]) * Integer.parseInt(s1[4]);
		lv[4] = null;
		lv[5] = listImgNbr[0];
		lv[6] = listImgNbr[1];
		lv[7] = listImgNbr[2];
		lv[8] = listImgNbr[3];
		lv[9] = listImgNbr[4];
		lv[10] = listImgNbr[5];
		lv[11] = listRSI[0];
		lv[12] = listRSI[1];
		lv[13] = listRSI[2];

		return lv;
	}
}