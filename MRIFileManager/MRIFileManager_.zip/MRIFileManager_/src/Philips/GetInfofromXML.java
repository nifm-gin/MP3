package Philips;

import java.io.File;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;

import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;

public class GetInfofromXML implements ListPhilipsParamData {

	private Object[] GeneralInformationXml = new Object[44];

	// GeneralInformation[0] = "Patient Name"
	// GeneralInformation[1] = "Examination Name"
	// GeneralInformation[2] = "Protocol Name"
	// GeneralInformation[3] = "Examination Date"
	// GeneralInformation[4] = "Examination Time"
	// GeneralInformation[5] = "Series Data Type"
	// GeneralInformation[6] = "Aquisition Number"
	// GeneralInformation[7] = "Reconstruction Number"
	// GeneralInformation[8] = "Scan Duration"
	// GeneralInformation[9] = "Max No Phases"
	// GeneralInformation[10] = "Max No Echoes"
	// GeneralInformation[11] = "Max No Slices"
	// GeneralInformation[12] = "Max No Dynamics"
	// GeneralInformation[13] = "Max No Mixes"
	// GeneralInformation[14] = "Max No B Values"
	// GeneralInformation[15] = "Max No Gradient Orients"
	// GeneralInformation[16] = "No Label Types"
	// GeneralInformation[17] = "Patient Position"
	// GeneralInformation[18] = "Preparation Direction"
	// GeneralInformation[19] = "Technique"
	// GeneralInformation[20] = "Scan Resolution X"
	// GeneralInformation[21] = "Scan Resolution Y"
	// GeneralInformation[22] = "Scan Mode"
	// GeneralInformation[23] = "Repetition Times"
	// GeneralInformation[24] = "FOV AP"
	// GeneralInformation[25] = "FOV FH"
	// GeneralInformation[26] = "FOV RL"
	// GeneralInformation[27] = "Water Fat Shift"
	// GeneralInformation[28] = "Angulation AP"
	// GeneralInformation[29] = "Angulation FH"
	// GeneralInformation[30] = "Angulation RL"
	// GeneralInformation[31] = "Off Center AP"
	// GeneralInformation[32] = "Off Center FH"
	// GeneralInformation[33] = "Off Center RL"
	// GeneralInformation[34] = "Flow Compensation"
	// GeneralInformation[35] = "Presaturation"
	// GeneralInformation[36] = "Phase Encoding Velocity"
	// GeneralInformation[37] = "MTC"
	// GeneralInformation[38] = "SPIR"
	// GeneralInformation[39] = "EPI factor"
	// GeneralInformation[40] = "Dynamic Scan"
	// GeneralInformation[41] = "Diffusion"
	// GeneralInformation[42] = "Diffusion Echo Time"
	// GeneralInformation[43] = "PhotometricInterpretation"

	public String[] ImageInformationXml = new String[50];

	// ImageInformation[x][0] = "Slice"
	// ImageInformation[x][1] = "Echo"
	// ImageInformation[x][2] = "Dynamic"
	// ImageInformation[x][3] = "Phase"
	// ImageInformation[x][4] = "BValue"
	// ImageInformation[x][5] = "Grad Orient"
	// ImageInformation[x][6] = "Label Type"
	// ImageInformation[x][7] = "Type"
	// ImageInformation[x][8] = "Sequence"
	// ImageInformation[x][9] = "Index"
	// ImageInformation[x][10] = "Pixel Size"
	// ImageInformation[x][11] = "Scan Percentage"
	// ImageInformation[x][12] = "Resolution X"
	// ImageInformation[x][13] = "Resolution Y"
	// ImageInformation[x][14] = "Rescale Intercept"
	// ImageInformation[x][15] = "Rescale Slope"
	// ImageInformation[x][16] = "Scale Slope"
	// ImageInformation[x][17] = "Window Center"
	// ImageInformation[x][18] = "Window Width"
	// ImageInformation[x][19] = "Slice Thickness"
	// ImageInformation[x][20] = "Slice Gap"
	// ImageInformation[x][21] = "Display Orientation"
	// ImageInformation[x][22] = "fMRI Status Indication"
	// ImageInformation[x][23] = "Image Type Ed Es"
	// ImageInformation[x][24] = "Pixel Spacing X"
	// ImageInformation[x][25] = "Pixel Spacing Y"
	// ImageInformation[x][26] = "Echo Time"
	// ImageInformation[x][27] = "Dyn Scan Begin Time"
	// ImageInformation[x][28] = "Trigger Time"
	// ImageInformation[x][29] = "Diffusion B Factor"
	// ImageInformation[x][30] = "No Averages"
	// ImageInformation[x][31] = "Image Flip Angle"
	// ImageInformation[x][32] = "Cardiac Frequency"
	// ImageInformation[x][33] = "Min RR Interval"
	// ImageInformation[x][34] = "Max RR Interval"
	// ImageInformation[x][35] = "TURBO Factor"
	// ImageInformation[x][36] = "Inversion Delay"
	// ImageInformation[x][37] = "Contrast Type"
	// ImageInformation[x][38] = "Diffusion Anisotropy Type"
	// ImageInformation[x][39] = "Diffusion AP"
	// ImageInformation[x][40] = "Diffusion FH"
	// ImageInformation[x][41] = "Diffusion RL"
	// ImageInformation[x][42] = "Angulation AP"
	// ImageInformation[x][43] = "Angulation FH"
	// ImageInformation[x][44] = "Angulation RL"
	// ImageInformation[x][45] = "Offcenter AP"
	// ImageInformation[x][46] = "Offcenter FH"
	// ImageInformation[x][47] = "Offcenter RL"
	// ImageInformation[x][48] = "Slice Orientation"
	// ImageInformation[x][49] = "Image Planar Configuration"
	// ImageInformation[x][50] = "Samples Per Pixel"

	String[] listImgNbr = new String[6];
	// listImgNbr[0] = slice number
	// listImgNbr[1] = echo number
	// listImgNbr[2] = dynamic number
	// listImgNbr[3] = Image Type
	// listImgNbr[4] = diffusion number
	// listImgNbr[5] = gradient number

	String[] listRSI = new String[3];
	// listImgNbr[0] = RI
	// listImgNbr[1] = RS
	// listImgNbr[2] = SS

	public GetInfofromXML(String file) {

		for (int i = 0; i < listImgNbr.length; i++)
			listImgNbr[i] = "";

		for (int i = 0; i < listRSI.length; i++)
			listRSI[i] = "";

		Document doc = null;
		SAXBuilder sxBuild = new SAXBuilder();

		try {
			doc = sxBuild.build(new File(file));
		} catch (Exception e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
		}
		Iterator<Element> i, j;
		Element classElement = doc.getRootElement();
		List<Element> stdlist = classElement.getChildren();

		/*****************************************
		 * GENERAL INFORMATION
		 ***********************************************/
		Element seriesInfo = stdlist.get(0);
		List<Element> list1 = seriesInfo.getChildren();
		i = list1.iterator();
		int ind = 0;

		while (i.hasNext()) {
			Element std1 = i.next();
			// System.out.println("
			// "+std1.getAttributeValue("Name")+"\t\t"+std1.getValue());
			GeneralInformationXml[ind] = std1.getValue();
			ind++;
		}

		GeneralInformationXml[23] = GeneralInformationXml[23].toString().replace("0.0000E+00", "");

		/*****************************************
		 * IMAGE INFORMATION
		 ***********************************************/

		Element imageArray = stdlist.get(1);
		List<Element> list2 = imageArray.getChildren();
		i = list2.iterator();
		String columnDetail = "";

		while (i.hasNext()) {
			Element std2 = i.next();
			List<Element> list3 = std2.getChildren();
			columnDetail = "";

			for (int h = 0; h < list3.size(); h++) {

				if (list3.get(h).getChildren().size() != 0) {
					List<Element> list4 = list3.get(h).getChildren();
					// System.out.println(list4.size());
					j = list4.iterator();

					while (j.hasNext()) {
						Element std4 = j.next();
						columnDetail = columnDetail + std4.getValue() + " ";
						// System.out.println(std4.getAttributeValue("Name")+" :
						// "+std4.getValue());
					}
				} else {
					columnDetail = columnDetail + list3.get(h).getValue() + " ";
					// System.out.println("
					// "+list3.get(h).getAttributeValue("Name")+" :
					// "+list3.get(h).getValue());
				}
			}

			String[] column = columnDetail.split((" +"));
			for (int k = 0; k < ImageInformationXml.length; k++) {
				if (ImageInformationXml[k] == null)
					ImageInformationXml[k] = "";
				if (!ImageInformationXml[k].contains(column[k]))
					ImageInformationXml[k] = ImageInformationXml[k] + column[k] + " ";
				if (k < 6 && k != 3) {
					listImgNbr[k] += column[k] + " ";
					// System.out.println(listImgNbr[3]);
				}

				if (k == 7)
					listImgNbr[3] += column[k] + " ";
				if (k == 15)
					listRSI[0] += column[k] + " "; // RI
				if (k == 16)
					listRSI[1] += column[k] + " "; // RS
				if (k == 17)
					listRSI[2] += column[k] + " "; // SS
			}
		}
	}

	@Override
	public Object[] getInfoGeneral() {
		return GeneralInformationXml;
	}

	@Override
	public Object[] getInfoImage() {
		// System.out.println(ImageInformationXml[24]+" ,
		// "+ImageInformationXml[25]);
		return ImageInformationXml;
	}

	@Override
	public String[] getListImgNbr() {
		String[] listType2 = { "M", "R", "I", "P", "CR", "T0", "T1", "T2", "RHO", "SPECTRO", "DERIVED", "ADC", "RCBV",
				"RCBF", "MTT", "TTP", "NC1", "NC2", "NC3" };
		String[] lo = listImgNbr[3].toString().split(" +");
		for (int i = 0; i < lo.length; i++) {
			listImgNbr[3] = listImgNbr[3].toString().replace(lo[i],
					String.valueOf(Arrays.asList(listType2).indexOf(lo[i])));
		}
		return listImgNbr;
	}

	@Override
	public String[] getListRSI() {
		return listRSI;
	}
}