package Philips;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

import AbstractClass.ImageThumb;
import AbstractClass.ParamMRI2;
import ij.ImagePlus;
import ij.io.FileInfo;
import ij.io.FileOpener;

public class imageThumbPhilips extends ImageThumb implements ParamMRI2 {

	private Image img;
	private ImagePlus imp;

	@Override
	public Image ImageThumbShow(String noSeq) {
		String[] listParamToFind = { "Scan Resolution", "Images In Acquisition", "Byte Order", "Data Type" };
		String[] values = new String[listParamToFind.length];
		
		for (int i=0;i<listParamToFind.length;i++) {
			values[i]=hmInfo.get(noSeq).get(listParamToFind[i]);
		}
		
		FileInfo fi = new FileInfo();

		int w = Integer.parseInt(values[0].split(" +")[0]);
		int h = Integer.parseInt(values[0].split(" +")[1]);
		int nImage = Integer.parseInt(values[1]);

		Float f = new Float(nImage);
		int intValue = f.intValue();

		intValue = intValue / 2;

		int mult = 1;

		if (values[3].contains("16")) {
			fi.fileType = FileInfo.GRAY16_UNSIGNED;
			mult = 2;
		} else if (values[3].contains("32")) {
			fi.fileType = FileInfo.GRAY32_FLOAT;
			mult = 4;
		} else {
			fi.fileType = FileInfo.GRAY8;
		}

		int off = w * h * intValue * mult;

		fi.fileName = hmSeq.get(noSeq)[0];
		fi.width = w;
		fi.height = h;
		fi.offset = off;
		fi.nImages = 1;
		fi.intelByteOrder = true;

		FileOpener fo = new FileOpener(fi);

		imp = fo.open(false);
		imp.resetDisplayRange();

		img = imp.getImage();
		imp.close();

		img = getScaledImage(img, 120, 120);

		return img;
	}

	private Image getScaledImage(Image srcImg, int w, int h) {
		BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = resizedImg.createGraphics();

		g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2.drawImage(srcImg, 0, 0, w, h, null);
		g2.dispose();

		return resizedImg;
	}
}