package Philips;

import java.io.IOException;


import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;

public class ListPhilipsSequence extends PrefParam implements ParamMRI2 {

	private String[] listParamSeq = headerListSeq;
	private String pathPhilips;
	public static String noSeqCurrent;

	public ListPhilipsSequence(String pathPhilips) {
		this.pathPhilips = pathPhilips;
	}

	public Object[] ListSeqPhilips() throws IOException {

		Object[] resul = new String[listParamSeq.length];
		
		new FillHmsPhilips(pathPhilips);
		
		resul[0]=noSeqCurrent;
		
		for (int i = 1; i < resul.length; i++) {
			try {
				resul[i] = hmInfo.get(noSeqCurrent).get(listParamSeq[i]);
				if (resul[i]==null)
					resul[i]="";
			} catch (Exception e) {
				resul[i] = "";
			}
		}
		return resul;
	}
}