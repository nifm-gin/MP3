package Philips;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;

import MRIFileManager.ExtractTxtfromFile;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;

public class GetInfofromPar implements ListPhilipsParamData {

	private Object[] GeneralInformation = new Object[35];

	// GeneralInformation[0] = Patient name
	// GeneralInformation[1] = Examination name
	// GeneralInformation[2] = Protocol name
	// GeneralInformation[3] = Examination date/time
	// GeneralInformation[4] = Series Type
	// GeneralInformation[5] = Acquisition nr
	// GeneralInformation[6] = Reconstruction nr
	// GeneralInformation[7] = Scan Duration [sec]
	// GeneralInformation[8] = Max. number of cardiac phases
	// GeneralInformation[9] = Max. number of echoes
	// GeneralInformation[10] = Max. number of slices/locations
	// GeneralInformation[11] = Max. number of dynamics
	// GeneralInformation[12] = Max. number of mixes
	// GeneralInformation[13] = Patient position
	// GeneralInformation[14] = Preparation direction
	// GeneralInformation[15] = Technique
	// GeneralInformation[16] = Scan resolution (x, y)
	// GeneralInformation[17] = Scan mode
	// GeneralInformation[18] = Repetition time [ms]
	// GeneralInformation[19] = FOV (ap,fh,rl) [mm]
	// GeneralInformation[20] = Water Fat shift [pixels]
	// GeneralInformation[21] = Angulation midslice(ap,fh,rl)[degr]
	// GeneralInformation[22] = Off Centre midslice(ap,fh,rl) [mm]
	// GeneralInformation[23] = Flow compensation <0=no 1=yes> ?
	// GeneralInformation[24] = Presaturation <0=no 1=yes> ?
	// GeneralInformation[25] = Phase encoding velocity [cm/sec]
	// GeneralInformation[26] = MTC <0=no 1=yes> ?
	// GeneralInformation[27] = SPIR <0=no 1=yes> ?
	// GeneralInformation[28] = EPI factor <0,1=no EPI>
	// GeneralInformation[29] = Dynamic scan <0=no 1=yes> ?
	// GeneralInformation[30] = Diffusion <0=no 1=yes> ?
	// GeneralInformation[31] = Diffusion echo time [ms]
	// GeneralInformation[32] = Max. number of diffusion values
	// GeneralInformation[33] = Max. number of gradient orients
	// GeneralInformation[34] = Number of label types <0=no ASL>

	private String[] ImageInformation = new String[49];
	// ImageInformation[0] = slice number (integer)
	// ImageInformation[1] = echo number (integer)
	// ImageInformation[2] = dynamic scan number (integer)
	// ImageInformation[3] = cardiac phase number (integer)
	// ImageInformation[4] = image_type_mr (integer)
	// ImageInformation[5] = scanning sequence (integer)
	// ImageInformation[6] = index in REC file (in images) (integer)
	// ImageInformation[7] = image pixel size (in bits) (integer)
	// ImageInformation[8] = scan percentage (integer)
	// ImageInformation[9] = recon resolution (x y) (2*integer)
	// ImageInformation[10] = recon resolution (x y) (2*integer)
	// ImageInformation[11] = rescale intercept (float)
	// ImageInformation[12] = rescale slope (float)
	// ImageInformation[13] = scale slope (float)
	// ImageInformation[14] = window center (integer)
	// ImageInformation[15] = window width (integer)
	// ImageInformation[16] = image angulation (ap,fh,rl in degrees ) (3*float)
	// ImageInformation[17] = image angulation (ap,fh,rl in degrees ) (3*float)
	// ImageInformation[18] = image angulation (ap,fh,rl in degrees ) (3*float)
	// ImageInformation[19] = image offcentre (ap,fh,rl in mm ) (3*float)
	// ImageInformation[20] = image offcentre (ap,fh,rl in mm ) (3*float)
	// ImageInformation[21] = image offcentre (ap,fh,rl in mm ) (3*float)
	// ImageInformation[22] = slice thickness (in mm ) (float)
	// ImageInformation[23] = slice gap (in mm ) (float)
	// ImageInformation[24] = image_display_orientation (integer)
	// ImageInformation[25] = slice orientation ( TRA/SAG/COR ) (integer)
	// ImageInformation[26] = fmri_status_indication (integer)
	// ImageInformation[27] = image_type_ed_es (end diast/end syst) (integer)
	// ImageInformation[28] = pixel spacing (x,y) (in mm) (2*float)
	// ImageInformation[29] = pixel spacing (x,y) (in mm) (2*float)
	// ImageInformation[30] = echo_time (float)
	// ImageInformation[31] = dyn_scan_begin_time (float)
	// ImageInformation[32] = trigger_time (float)
	// ImageInformation[33] = diffusion_b_factor (float)
	// ImageInformation[34] = number of averages (integer)
	// ImageInformation[35] = image_flip_angle (in degrees) (float)
	// ImageInformation[36] = cardiac frequency (bpm) (integer)
	// ImageInformation[37] = minimum RR-interval (in ms) (integer)
	// ImageInformation[38] = maximum RR-interval (in ms) (integer)
	// ImageInformation[39] = TURBO factor <0=no turbo> (integer)
	// ImageInformation[40] = Inversion delay (in ms) (float)
	// ImageInformation[41] = diffusion b value number (imagekey!) (integer)
	// ImageInformation[42] = gradient orientation number (imagekey!) (integer)
	// ImageInformation[43] = contrast type (string)
	// ImageInformation[44] = diffusion anisotropy type (string)
	// ImageInformation[45] = diffusion (ap, fh, rl) (3*float)
	// ImageInformation[46] = diffusion (ap, fh, rl) (3*float)
	// ImageInformation[47] = diffusion (ap, fh, rl) (3*float)
	// ImageInformation[48] = label type (ASL) (imagekey!) (integer)

	String[] listImgNbr = new String[6];
	// listImgNbr[0] = slice number
	// listImgNbr[1] = echo number
	// listImgNbr[2] = dynamic number
	// listImgNbr[3] = Image Type
	// listImgNbr[4] = diffusion number
	// listImgNbr[5] = gradient number

	String[] listRSI = new String[3];
	// listImgNbr[0] = RI
	// listImgNbr[1] = RS
	// listImgNbr[2] = SS

	public GetInfofromPar(String file) {

		for (int i = 0; i < listImgNbr.length; i++)
			listImgNbr[i] = "";

		for (int i = 0; i < listRSI.length; i++)
			listRSI[i] = "";

		String txt, txtGI, txtII, strLine = "";
		String[] columDetail;

		txt = new ExtractTxtfromFile(file).getTxt();

		/*********************************
		 * General Information
		 ***************************************/
		txtGI = txt.substring(txt.indexOf("= GENERAL INFORMATION ="));
		txtGI = txtGI.substring(txtGI.indexOf("\n") + 1);
		txtGI = txtGI.substring(txtGI.indexOf("\n") + 1, txtGI.indexOf("# === PIXEL VALUES =") - 3);

		try {
			BufferedReader bg = new BufferedReader(new StringReader(txtGI));
			strLine = "";
			int i = 0;
			while ((strLine = bg.readLine()) != null) {
				GeneralInformation[i] = strLine.substring(strLine.indexOf(":   ") + 4);
				i++;
			}
		} catch (Exception e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(GetStackTrace.getMessage());
		}

		/*********************************
		 * Image Information
		 ***************************************/
		txtII = txt.substring(txt.indexOf("= IMAGE INFORMATION ="));
		txtII = txtII.substring(txtII.indexOf("\n") + 1);
		txtII = txtII.substring(txtII.indexOf("\n") + 1);
		txtII = txtII.substring(txtII.indexOf("\n") + 1, txtII.indexOf("# === END OF DATA DESCRIPTION FILE =") - 4);

		try {
			BufferedReader br = new BufferedReader(new StringReader(txtII));
			strLine = "";
			while ((strLine = br.readLine()) != null) {
				columDetail = strLine.trim().split(" +");

				for (int i = 0; i < 49; i++) {
					if (ImageInformation[i] == null)
						ImageInformation[i] = "";

					if (!ImageInformation[i].contains(columDetail[i]))
						ImageInformation[i] += columDetail[i] + " ";

					if (i < 3)
						listImgNbr[i] += columDetail[i] + " "; 	// slice number
																// Echo number
																// dynamic number
					if (i == 4)
						listImgNbr[3] += columDetail[i] + " "; // Image
																		// Type
					if (i == 41)
						listImgNbr[4] += columDetail[i] + " "; // Diffusion
																		// number
					if (i == 42)
						listImgNbr[5] += columDetail[i] + " "; // Gradient
																		// number
					if (i == 11)
						listRSI[0] += columDetail[i] + " "; // RI
					if (i == 12)
						listRSI[1] += columDetail[i] + " "; // RS
					if (i == 13)
						listRSI[2] += columDetail[i] + " "; // SS
				}

			}
		} catch (IOException e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(GetStackTrace.getMessage());
		}

	} // end constructor

	@Override
	public Object[] getInfoGeneral() {
		return GeneralInformation;
	}

	@Override
	public Object[] getInfoImage() {
		return ImageInformation;
	}

	@Override
	public String[] getListImgNbr() {
		return listImgNbr;
	}

	@Override
	public String[] getListRSI() {
		return listRSI;
	}
}