package Philips;

import java.util.HashMap;

import AbstractClass.ParamMRI2;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;

public class FillHmsPhilips implements ParamMRI2 {
	
	private HashMap<String, String> listParam;

	public FillHmsPhilips(String pathPhilips) {

			try {
				ListPhilipsParam2 listPhilipsPar = new ListPhilipsParam2(pathPhilips);
				listParam = listPhilipsPar.ListParamValue();
				ListPhilipsSequence.noSeqCurrent=listParam.get("noSeq");
				hmInfo.put(listParam.get("noSeq"), listParam);
				hmOrderImage.put(listParam.get("noSeq"), listPhilipsPar.ListOrderStack("",""));
		
				/**********************
				 * Hashmap hm add
				 *******************************************************/
				String[] hmValue = new String[1];
				hmValue[0] = pathPhilips;
				hmSeq.put(listParam.get("noSeq"), hmValue);
				
			} catch (Exception e) {
				new GetStackTrace(e);
				FileManagerFrame.getBugText().setText(
						FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
			}
	}
}