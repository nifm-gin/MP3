package Philips;

import AbstractClass.ParamMRI2;
import AbstractClass.convertNifti;
import ij.ImagePlus;
import ij.ImageStack;
import ij.process.ImageProcessor;

public class ConvertPhilipsToNifti extends convertNifti implements ParamMRI2 {

	private AffineQuaternionPhilips2 bts;
	
	@Override
	public ImagePlus convertToNifti(String lb) {
		ImagePlus imp = new OpenPhilips(listBasket_hms.get(lb), listBasket_hmo.get(lb), false,true, lb).getImp();
		ImageStack stack = imp.getStack();
		for (int i=1; i<=stack.getSize(); i++) {
			ImageProcessor ip = stack.getProcessor(i);
			ip.flipVertical();
		}
		return imp;
	}

	@Override
	public void AffineQuaternion(String lb) {
//		bts = new AffineQuaternionPhilips(listBasket_hms.get(lb).get("File path"));
		bts = new AffineQuaternionPhilips2(lb);
	}

	@Override
	public double[][] srow() {
		return bts.getsform();
	}

	@Override
	public double[] quaterns() {
		return bts.getquaterns();
	}
}