package Philips;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import AbstractClass.ListParam;
import AbstractClass.ParamMRI;
import AbstractClass.PrefParam;

public class ListPhilipsParam extends PrefParam implements ParamMRI, ListParam {

	private String pathPhilips;
	private Object[] InfoGeneral, InfoImage;
	private String[] listImgNbr, listRSI;
	private int ind = 0;
	private String[] listType2 = { "M", "R", "I", "P", "CR", "T0", "T1", "T2", "RHO", "SPECTRO", "DERIVED", "ADC",
			"RCBV", "RCBF", "MTT", "TTP", "NC1", "NC2", "NC3" };
	// = 0 "M"
	// = 1 "R"
	// = 2 "I"
	// = 3 "P"
	// = 4 "CR"
	// = 5 "T0"
	// = 6 "T1"
	// = 7 "T2"
	// = 8 "RHO"
	// = 9 "SPECTRO"
	// = 10 "DERIVED"
	// = 11 "ADC"
	// = 12 "RCBV"
	// = 13 "RCBF"
	// = 14 "MTT"
	// = 15 "TTP"
	// = 16 "NC1"
	// = 17 "NC2"
	// = 18 "NC3"

	public ListPhilipsParam(String pathPhilips) {

		this.pathPhilips = pathPhilips;

	}

	@Override
	public HashMap<String, String[]> ListParamValue() throws IOException {
		HashMap<String, String[]> lv = new HashMap<String, String[]>();
		String[] values;
		String pathPhilips2;
		pathPhilips2 = pathPhilips.replace(".REC", ".PAR");
		ind = 0;
		if (!new File(pathPhilips2).exists()) {
			pathPhilips2 = pathPhilips.replace(".REC", ".Xml");
			ind = 3;
		}

		ListPhilipsParamData philipsParam = null;

		switch (ind) {
		case 0:
			philipsParam = new GetInfofromPar(pathPhilips2);
			new GetInfofromPar2(pathPhilips2,true);
			break;
		case 3:
			philipsParam = new GetInfofromXML(pathPhilips2);
			break;
		}

		InfoGeneral = philipsParam.getInfoGeneral();
		InfoImage = philipsParam.getInfoImage();
		listImgNbr = philipsParam.getListImgNbr();
		listRSI = philipsParam.getListRSI();

		for (String sg : listParamInfoGeneral.keySet()) {
			values = new String[listParamInfoGeneral.get(sg).length];
			if (sg.contentEquals("File Info")) {
				File filePhilips = new File(pathPhilips);
				values[0] = filePhilips.getAbsolutePath();
				values[1] = filePhilips.getName();
				values[2] = String.valueOf(filePhilips.length() / (1024 * 1024.0));
			} else {
				for (int i = 0; i < listParamInfoGeneral.get(sg).length; i++) {
					try {
						if (dictionaryParamMRI.get(listParamInfoGeneral.get(sg)[i])[1 + ind]
								.contains("GENERAL INFORMATION")
								|| dictionaryParamMRI.get(listParamInfoGeneral.get(sg)[i])[1 + ind]
										.contains("Series_Info"))
							if (!dictionaryParamMRI.get(listParamInfoGeneral.get(sg)[i])[2 + ind].contains("-"))
								values[i] = InfoGeneral[Integer
										.parseInt(dictionaryParamMRI.get(listParamInfoGeneral.get(sg)[i])[2 + ind])]
												.toString();
							else {
								String[] lv1 = dictionaryParamMRI.get(listParamInfoGeneral.get(sg)[i])[2 + ind]
										.split("-");
								int low = Integer.parseInt(lv1[0]);
								int high = Integer.parseInt(lv1[1]);
								values[i] = "";
								for (int h = low; h <= high; h++)
									values[i] += InfoGeneral[h] + " ";
							}
						else {
							if (!dictionaryParamMRI.get(listParamInfoGeneral.get(sg)[i])[2 + ind].contains("-"))
								values[i] = InfoImage[Integer
										.parseInt(dictionaryParamMRI.get(listParamInfoGeneral.get(sg)[i])[2 + ind])]
												.toString();
							else {
								String[] lv1 = dictionaryParamMRI.get(listParamInfoGeneral.get(sg)[i])[2 + ind]
										.split("-");
								int low = Integer.parseInt(lv1[0]);
								int high = Integer.parseInt(lv1[1]);
								values[i] = "";
								for (int h = low; h <= high; h++)
									values[i] += InfoImage[h] + " ";
							}
						}
					} catch (Exception e) {
						values[i] = "";
					}
				}
			}
			lv.put(sg, values);
		}

		String[] lvtmp;
		String tmp;

		lvtmp = lv.get("Dimensions");

		/************************************************
		 * recalculate Image in acq
		 ************************************************/
		tmp = lvtmp[2];
		tmp = String.valueOf(tmp.split(" +").length);
		lvtmp[2] = tmp;
		
		/***************** modifify data type if <0 ********************/
		
		tmp = lvtmp[4].trim();
		if (Integer.parseInt(tmp)<0)
			tmp="0";
		lvtmp[4] = tmp;
		
		
		/******** modifiy echo number *********/
		tmp = lvtmp[6].trim();
		tmp = String.valueOf(tmp.trim().split(" +").length);
		lvtmp[6]=tmp;

		/*********** redefinite diffusion ****************/
		tmp = lvtmp[8];
		tmp = String.valueOf(tmp.split(" +").length);
		lvtmp[8] = tmp;

		lv.put("Dimensions", lvtmp);

		lvtmp = lv.get("MRI parameters");

		/********* redefinite Slice Thickness, added to Slice Gap *********/
		tmp = lvtmp[5];
		String sliceGap = InfoImage[Integer.parseInt(dictionaryParamMRI.get("Slice Gap")[2 + ind])].toString();
		try {
			tmp = String.valueOf(Float.parseFloat(tmp) + Float.parseFloat(sliceGap));
		} catch (Exception e) {
			tmp = String.valueOf(Float.parseFloat(tmp.split(" +")[0]) + Float.parseFloat(sliceGap.split(" +")[0]));
			;
		}
		lvtmp[5] = tmp;

		/************************************************
		 * redefinite Slice Orientation
		 ************************************************/
		try {
			tmp = lvtmp[8];
			String[] listOrient = { "", "axial", "sagittal", "coronal" };
			for (String gg : tmp.split(" +"))
				tmp = tmp.replace(gg, listOrient[Integer.parseInt(gg)]);
			lvtmp[8] = tmp;
		} catch (Exception e) {

		}

		/************************************************
		 * redefinite Image Type
		 ************************************************/
		tmp = lvtmp[10];

		try {
			for (String gg : tmp.split(" +")) {
				
				if (Integer.parseInt(gg) < 0)
					gg = "0";
				tmp = tmp.replace(gg, listType2[Integer.parseInt(gg)]);
			}
			lvtmp[10] = tmp;
		} catch (Exception e) {
		}

		lv.put("MRI parameters", lvtmp);

		return lv;
	}

	@Override
	public Object[] ListOrderStack(String dim, String nImage) {
		// for (String ll : listImgNbr)
		// System.out.println(ll);
		String[] s1 = listImgNbr.clone();
		String[] s2 = listImgNbr.clone();

		String order = "";

		List<String> list = Arrays.asList(s2);

		Collections.sort(list, Collections.reverseOrder());

		for (String e : list) {
			for (int i = 0; i < s1.length; i++)
				if (s1[i].contentEquals(e) && !order.contains(String.valueOf(i))) {
					order += String.valueOf(i) + " ";
					break;
				}
		}

		for (int i = 4; i < 19; i++)
			s1[3] = s1[3].replace(String.valueOf(i), "");

		Set<String> uniqueWords;

		for (int i = 0; i < s1.length; i++) {
			uniqueWords = new HashSet<String>(Arrays.asList(s1[i].split(" +")));
			s1[i] = String.valueOf(uniqueWords.size());
		}

		// System.out.println(this+" : "+order);
		//
		// for (String yy : listImgNbr)
		// System.out.println(yy);
		//
		// for (String kk : s1)
		// System.out.println(kk);

		Object[] lv = new Object[14];

		// if (order.substring(0, 1).contentEquals("2"))
		// lv[0] = "xyczt";
		// else
		lv[0] = "xyczt";

		if (s1[3].contentEquals("0"))
			s1[3] = "1";
		
		if (Integer.parseInt(s1[4])>1)
			lv[0] = "xyctz";

		lv[1] = Integer.parseInt(s1[3]);
		lv[2] = Integer.parseInt(s1[0]);
		lv[3] = Integer.parseInt(s1[1]) * Integer.parseInt(s1[2]) * Integer.parseInt(s1[4]);
		lv[4] = null;
		lv[5] = listImgNbr[0];
		lv[6] = listImgNbr[1];
		lv[7] = listImgNbr[2];
		lv[8] = listImgNbr[3];
		lv[9] = listImgNbr[4];
		lv[10] = listImgNbr[5];
		lv[11] = listRSI[0];
		lv[12] = listRSI[1];
		lv[13] = listRSI[2];

		// String[] lo = lv[8].toString().split(" +");
		// for (int i=0;i<lo.length;i++){
		// lv[8]=lv[8].toString().replace(lo[i],
		// String.valueOf(Arrays.asList(listType2).indexOf(lo[i])));
		// }

		return lv;
	}
}