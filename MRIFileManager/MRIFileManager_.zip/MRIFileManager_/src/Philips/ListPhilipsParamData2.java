package Philips;

import java.util.HashMap;

public interface ListPhilipsParamData2 {
	
	HashMap<String, String> getInfoImage();
	
	String[] getListImgNbr();
	
	String[] getListRSI();
	
}