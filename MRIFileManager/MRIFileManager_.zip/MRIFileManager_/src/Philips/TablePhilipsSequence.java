package Philips;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import AbstractClass.ParamMRI;
import AbstractClass.PrefParam;

public class TablePhilipsSequence extends PrefParam {

	private Object[][] data;
	private List<String> listPhilips = new ArrayList<String>();

	public TablePhilipsSequence(String repertory) throws IOException {

		List<String> list2dseq = searchPhilips(repertory);

		if (!list2dseq.isEmpty()) {

			data = new Object[list2dseq.size()][ParamMRI.headerListSeq.length];
			for (int i = 0; i < data[0].length; i++)
				data[0][i] = "";
			data[0][0] = "no Philips sequence found";

			for (int i = 0; i < data.length; i++) {
				data[i] = new ListPhilipsSequence(repertory + separator + list2dseq.get(i)).ListSeqPhilips();
			}
		} else {
			data = new Object[1][ParamMRI.headerListSeq.length];
			for (int i = 0; i < data[0].length; i++)
				data[0][i] = "";
			data[0][0] = "no Philips sequence found";
		}
	}

	private List<String> searchPhilips(String rep) {
		String[] listOfFiles = new File(rep).list();

		for (String lg : listOfFiles)
			if (lg.contains(".REC"))
				listPhilips.add(lg);
		
		return listPhilips;
	}

	public Object[][] getSequence() {
		return data;
	}

}
