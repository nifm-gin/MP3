package Dicom;

import javax.swing.JPopupMenu;

import AbstractClass.ParamMRI2;
import AbstractClass.SelectionSeq;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;
import MRIFileManager.OpenImageJ;
import MRIFileManager.ShowImagePanel;
import MRIFileManager.ThumbnailList;
import MRIFileManager.TreeInfo2;

public class SelectionSeqDicom implements ParamMRI2, SelectionSeq {

	private FileManagerFrame wind;
	private String seqSelected;

	public SelectionSeqDicom(FileManagerFrame wind) {
		this.wind = wind;
		seqSelected = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRow(), 0).toString();
	}

	@Override
	public void goSelectionSeq() {
		try {
			wind.getTreeInfoGeneral().setModel(new TreeInfo2(listParamInfoSystem,hmInfo.get(seqSelected)).getTreeInfo().getModel());
			for (int j = 0; j < wind.getTreeInfoGeneral().getRowCount(); j++)
				wind.getTreeInfoGeneral().expandRow(j);
		} catch (Exception e1) {
			new GetStackTrace(e1);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
		}
		
//		new ShowImagePanel(wind, new OpenDicom(seqSelected, false, false, seqSelected).getImp(), seqSelected);
		
		String seqSel;

		if (wind.getTabSeq().getSelectedRowCount() == 1) {
			seqSel = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[0], 0).toString();
			ThumbnailList.list.setSelectedValue(seqSel, true);
		} else {
			int[] ls = new int[wind.getTabSeq().getSelectedRowCount()];
			for (int i = 0; i < wind.getTabSeq().getSelectedRowCount(); i++) {
				seqSel = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i], 0).toString();
				for (int g = 0; g < ThumbnailList.list.getModel().getSize(); g++)
					if (ThumbnailList.list.getModel().getElementAt(g) == seqSel)
						ls[i] = g;
			}
			ThumbnailList.list.setSelectedIndices(ls);
		}

	}

	@Override
	public void popMenuSeq(JPopupMenu popMenu) {
		// TODO Auto-generated method stub

	}

	@Override
	public void openImage() {
		new OpenImageJ();
		// new OpenImageJ("C:\\Program Files\\ImageJ\\ImageJ.exe");

		for (int i = 0; i < wind.getTabSeq().getSelectedRowCount(); i++) {
			String seqSelected = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i], 0).toString();
//			new FillHmsBruker(seqSelected);
//			new OpenBruker(hmInfo.get(seqSelected), hmOrderImage.get(seqSelected), true, false, seqSelected);
			new OpenDicom(seqSelected);
		}
	}

	@Override
	public void showParamFile(String chemFile, String keyword) {
		// TODO Auto-generated method stub

	}

	@Override
	public void fillBasket() {
		// TODO Auto-generated method stub

	}

}
