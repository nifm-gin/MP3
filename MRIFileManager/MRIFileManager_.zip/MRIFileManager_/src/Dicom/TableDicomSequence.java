package Dicom;

import java.util.concurrent.ForkJoinPool;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;

public class TableDicomSequence extends PrefParam implements ParamMRI2 {

	private Object[][] data;
	private String[] listParamSeq = headerListSeq;

	public TableDicomSequence(String repertory) {

		int processeurs = Runtime.getRuntime().availableProcessors();
		ForkJoinPool pool = new ForkJoinPool(processeurs);
		
		switch (formatDicom) {
		case "DIRFILE":
			ListDirfileSequence ls1 = new ListDirfileSequence(repertory);
//			Thread t1 = new Thread(ls1);
//			t1.start();
//			try {
//				t1.join();
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			pool.invoke(ls1);
			break;
		case "DICOMDIR":
			ListDicomDirSequence ls2 = new ListDicomDirSequence(repertory);
//			Thread t2 = new Thread(ls2);
//			t2.start();
//			try {
//				t2.join();
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			pool.invoke(ls2);
			break;
		case "DCM":
			ListDcmSequence ls3 = new ListDcmSequence(repertory);
//			Thread t3 = new Thread(ls3);
//			t3.start();
//			try {
//				t3.join();
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			pool.invoke(ls3);
			break;
		}

		if (!hmInfo.isEmpty()) {
			data = new Object[hmInfo.size()][listParamSeq.length];
			for (String jj : hmInfo.keySet()) {
				data[Integer.parseInt(jj)][0] = jj;
				for (int i = 1; i < listParamSeq.length; i++) {
					data[Integer.parseInt(jj)][i] = hmInfo.get(jj).get(listParamSeq[i]);
				}
			}
		} else {
			data = new Object[1][headerListSeq.length];
			for (int i = 0; i < data[0].length; i++)
				data[0][i] = "";
			data[0][0] = "no Dicom sequence found";
		}
	}

	public Object[][] getSequence() {
		return data;
	}

}