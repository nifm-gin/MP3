package Dicom;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import AbstractClass.ListParam2;
import AbstractClass.ParamMRI2;

public class ListDicomParam implements ParamMRI2, ListParam2 {

	private String noSeq;
	private int numberFrames;

	public ListDicomParam(String noSeq, int numberFrames) {
		this.noSeq = noSeq;
		this.numberFrames = numberFrames;
		run();
	}

	public void run() {

		String hdr = hmSeq.get(noSeq)[0];
		hdr = new HeaderDicom().getHeaderDicom(hdr);

		HashMap<String, String> listValues = new HashMap<>();
		ArrayList<String[]> listA = null;

		for (String kk : dictionaryMRISystem.keySet()) {
			listValues.put(kk, searchParam(hdr, dictionaryMRISystem.get(kk).get("keyName")));
		}
		hmInfo.put(noSeq, listValues);

		listA = new ArrayList<String[]>();
		String[] listSlice = null;

		if (numberFrames > 1) {

			hdr = new HeaderDicom().getHeaderDicom(hmSeq.get(noSeq)[0]);

			String[] list = hdr.split("0008,0008");

			for (int i = 0; i < list.length; i++) {
				listSlice = new String[5]; // for Image Number, Echo Time,
				// Repetition Time, Inversion Time,
				// Slice Orientation
				listSlice[0] = searchParam(list[i], "Image Number");
				if (!listSlice[0].isEmpty()) {
					listSlice[1] = searchParam(list[i], "Echo Time");
					listSlice[2] = searchParam(list[i], "Repetition Time");
					listSlice[3] = searchParam(list[i], "Inversion Time");
					listSlice[4] = searchParam(list[i], "Image Orientation (Patient)");
					try {
						listSlice[4] = new DicomOrientation(listSlice[4]).getOrientationDicom();
					} catch (Exception e) {
						listSlice[4] = "";
					}
					listA.add(listSlice);
				}
			}
			
			String[] lastEl = listA.get(listA.size() - 1).clone();
			
			Collections.sort(listA, new Comparator<Object[]>() {
				public int compare(Object[] strings, Object[] otherStrings) {
					return ((Integer) Integer.parseInt(strings[0].toString()))
							.compareTo((Integer) Integer.parseInt(otherStrings[0].toString()));
				}
			});

			for (int h = 0; h < 5; h++)
				listSlice[h] = "";

			List<String> listTE = new ArrayList<>();
			List<String> listTR = new ArrayList<>();
			List<String> listIT = new ArrayList<>();
			List<String> listSO = new ArrayList<>();

			for (int i = 0; i < listA.size(); i++) {
				if (!listA.get(i)[1].isEmpty()) {
					listTE.add(listA.get(i)[1]);
					listTR.add(listA.get(i)[2]);
					listIT.add(listA.get(i)[3]);
					listSO.add(listA.get(i)[4]);
				} else {
					listTE.add(lastEl[1]);
					listTR.add(lastEl[2]);
					listIT.add(lastEl[3]);
					listSO.add(lastEl[4]);
				}
			}

			listA.clear();

			listSlice[1] = String.join(" ", listTE);
			listSlice[2] = String.join(" ", listTR);
			listSlice[3] = String.join(" ", listIT);
			listSlice[4] = String.join(" ", listSO);

			// for (String gg : listTE)
			// listSlice[1] += gg + " ";
			//
			// for (String gg : listTR)
			// listSlice[2] += gg + " ";
			//
			// for (String gg : listIT)
			// listSlice[3] += gg + " ";
			//
			// for (String gg : listSO)
			// listSlice[4] += gg + " ";

			listValues.put("Echo Time", deleteDuplicate(listSlice[1]));
			listValues.put("Repetition Time", deleteDuplicate(listSlice[2]));
			listValues.put("Inversion Time", deleteDuplicate(listSlice[3]));
			listValues.put("Slice Orientation", deleteDuplicate(listSlice[4]));

//			hmInfo.put(noSeq, listValues);

		} else {
			for (String kk : hmSeq.get(noSeq)) {
				hdr = new HeaderDicom().getHeaderDicom(kk);
				listSlice = new String[5];
				listSlice[0] = searchParam(hdr.split("Image Number: 0 ")[1], "Image Number");
				if (!listSlice[0].isEmpty()) {
					listSlice[1] = searchParam(hdr, "Echo Time");
					listSlice[2] = searchParam(hdr, "Repetition Time");
					listSlice[3] = searchParam(hdr, "Inversion Time");
					listSlice[4] = searchParam(hdr, "Image Orientation (Patient)");
					try {
						listSlice[4] = new DicomOrientation(listSlice[4]).getOrientationDicom();
					} catch (Exception e) {
						listSlice[4] = "";
					}
					listA.add(listSlice);
				}
			}

			Collections.sort(listA, new Comparator<Object[]>() {
				public int compare(Object[] strings, Object[] otherStrings) {
					return ((Integer) Integer.parseInt(strings[0].toString()))
							.compareTo((Integer) Integer.parseInt(otherStrings[0].toString()));
				}
			});

			for (int h = 0; h < 5; h++)
				listSlice[h] = "";

			List<String> listTE = new ArrayList<>();
			List<String> listTR = new ArrayList<>();
			List<String> listIT = new ArrayList<>();
			List<String> listSO = new ArrayList<>();

			for (int i = 0; i < listA.size(); i++) {
				listTE.add(listA.get(i)[1]);
				listTR.add(listA.get(i)[2]);
				listIT.add(listA.get(i)[3]);
				listSO.add(listA.get(i)[4]);
			}

			listA.clear();

			for (String gg : listTE)
				listSlice[1] += gg + " ";

			for (String gg : listTR)
				listSlice[2] += gg + " ";

			for (String gg : listIT)
				listSlice[3] += gg + " ";

			for (String gg : listSO)
				listSlice[4] += gg + " ";

			listValues.put("Echo Time", deleteDuplicate(listSlice[1]));
			listValues.put("Repetition Time", deleteDuplicate(listSlice[2]));
			listValues.put("Inversion Time", deleteDuplicate(listSlice[3]));
			listValues.put("Slice Orientation", deleteDuplicate(listSlice[4]));

			listValues.put("Images In Acquisition",String.valueOf(hmSeq.get(noSeq).length));

//			hmInfo.put(noSeq, listValues);

		}
		
		listValues=new DicomDictionaryAdjustement().valuesAdjustement(listValues);
		
		hmInfo.put(noSeq, listValues);

	}

	private String searchParam(String txt, String paramToFind) {
		String resul = "";
		int indx = txt.indexOf(paramToFind);
		try {
			if (indx != -1) {
				resul = txt.substring(indx);
				resul = resul.substring(resul.indexOf(":") + 1, resul.indexOf("\n"));
			}
		} catch (Exception e) {
			resul = "";
		}

		return resul.trim();
	}

	private String deleteDuplicate(String elements) {

		String resul = "";
		String[] list = null;

		list = elements.split(" +");

		List<String> array = Arrays.asList(list);
		Set<String> hs = new LinkedHashSet<>(array);
		list = Arrays.copyOf(hs.toArray(), hs.toArray().length, String[].class);

		for (String hh : list)
			resul += hh + " ";

		return resul.trim();
	}

	@Override
	public HashMap<String, String> ListParamValue() throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object[] ListOrderStack(String dim, String nImage) {
		// TODO Auto-generated method stub
		return null;
	}
}