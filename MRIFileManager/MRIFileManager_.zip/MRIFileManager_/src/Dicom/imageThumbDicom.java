package Dicom;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

import AbstractClass.ImageThumb;
import AbstractClass.ParamMRI2;
import ij.ImagePlus;
import ij.io.FileInfo;
import ij.io.FileOpener;
import ij.plugin.DICOM;
import ij.plugin.Duplicator;

public class imageThumbDicom extends ImageThumb implements ParamMRI2 {

	private Image img;
	private ImagePlus imp;

	@Override
	public Image ImageThumbShow(String noSeq) {

		String[] listParamToFind = { "Scan Resolution", "Images In Acquisition", "Byte Order", "Data Type" };
		String[] values = new String[listParamToFind.length];

		for (int i = 0; i < listParamToFind.length; i++) {
			values[i] = hmInfo.get(noSeq).get(listParamToFind[i]);
		}

		FileInfo fi = new FileInfo();

		int w = Integer.parseInt(values[0].split(" +")[0]);
		int h = Integer.parseInt(values[0].split(" +")[1]);
		int nImage = Integer.parseInt(values[1]);

		Float f = new Float(nImage);
		int intValue = f.intValue();
		intValue = intValue / 2;

		int mult = 1;

		if (values[3].contains("16")) {
			fi.fileType = FileInfo.GRAY16_UNSIGNED;
			mult = 2;
		} else if (values[3].contains("32")) {
			fi.fileType = FileInfo.GRAY32_FLOAT;
			mult = 4;
		} else {
			fi.fileType = FileInfo.GRAY8;
		}

		int off = w * h * intValue * mult;
		String filename = hmSeq.get(noSeq)[0];

//		System.out.println(hmSeq.get(noSeq).length+" , "+intValue);
		
		if (hmSeq.get(noSeq).length > 1) {
			filename = hmSeq.get(noSeq)[intValue];
			imp = new ImagePlus(filename);
//			System.out.println(filename);
		}

		else {
			imp = new ImagePlus(filename);
			imp = new Duplicator().run(imp,intValue,intValue);

		}
		imp.resetDisplayRange();

		img = imp.getImage();
		imp.close();

		img = getScaledImage(img, 120, 120);

		return img;
	}

	private Image getScaledImage(Image srcImg, int w, int h) {
		BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = resizedImg.createGraphics();

		g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2.drawImage(srcImg, 0, 0, w, h, null);
		g2.dispose();

		return resizedImg;
	}
}