package Dicom;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.RecursiveAction;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;
import ij.plugin.DICOM;

public class ListDcmSequence extends RecursiveAction implements ParamMRI2 {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String chemDicom;

	public ListDcmSequence(String chemDicom) {
		this.chemDicom = chemDicom;
		// run();
	}

	public void run() {

		String numberFrames;
		HashMap<String, String> listValues = new HashMap<>();
		ArrayList<String[]> listA = null;
		String[] listSlice = null;
		String hdr;

		File dir = new File(chemDicom);
		String[] files = dir.list();

		hdr = new HeaderDicom().getHeaderDicom(chemDicom + PrefParam.separator + files[0]);

		for (String kk : dictionaryMRISystem.keySet()) {
			listValues.put(kk, searchParam(hdr, dictionaryMRISystem.get(kk).get("keyName")));
		}
		hmInfo.put("00", listValues);

		numberFrames = searchParam(hdr, "Number of Frames");

		if (numberFrames.isEmpty())
			numberFrames = "1";

		listA = new ArrayList<String[]>();

		if (Integer.parseInt(numberFrames) == 1) {

			DICOM dcm;

			for (String gg : files) {
				dcm = new DICOM();
				dcm.open(chemDicom + PrefParam.separator + gg);
				listSlice = new String[6];
				listSlice[0] = dcm.getStringProperty("Image Number");
				if (listSlice[0] != null)
					if (!listSlice[0].isEmpty()) {
						listSlice[0] = listSlice[0].trim();
						listSlice[1] = dcm.getStringProperty("Echo Time");
						listSlice[2] = dcm.getStringProperty("Repetition Time");
						listSlice[3] = dcm.getStringProperty("Inversion Time");
						listSlice[4] = dcm.getStringProperty("Image Orientation (Patient)");
						listSlice[5] = chemDicom + PrefParam.separator + gg;

						try {
							listSlice[4] = new DicomOrientation(listSlice[4]).getOrientationDicom();
						} catch (Exception e) {
							listSlice[4] = "";
						}
						listA.add(listSlice);
					}
				dcm.close();
			}

			String[] lastEl = listA.get(listA.size() - 1).clone();

			Collections.sort(listA, new Comparator<Object[]>() {
				public int compare(Object[] strings, Object[] otherStrings) {
					// System.out.println((Integer)
					// Integer.parseInt(strings[0].toString()));
					return ((Integer) Integer.parseInt(strings[0].toString()))
							.compareTo((Integer) Integer.parseInt(otherStrings[0].toString()));
				}
			});

			// Collections.sort(listA, new Comparator<Object[]>() {
			// public int compare(Object[] strings, Object[] otherStrings) {
			// int ord1,ord2;
			// ord1 = (Integer) Integer.parseInt(strings[0].toString());
			// ord2 = (Integer) Integer.parseInt(otherStrings[0].toString());
			// System.out.println(ord1+" , "+ord2);
			// if (ord2<ord1)
			// return 1;
			// else if (ord2>ord1)
			// return -1;
			// else return
			// strings.toString().compareTo(otherStrings.toString());
			// }
			// });

			for (int h = 0; h < 6; h++)
				listSlice[h] = "";

			List<String> listTE = new ArrayList<>();
			List<String> listTR = new ArrayList<>();
			List<String> listIT = new ArrayList<>();
			List<String> listSO = new ArrayList<>();
			String[] listFileDcm = new String[listA.size()];
			listValues.put("Images In Acquisition", String.valueOf(listFileDcm.length));

			for (int i = 0; i < listA.size(); i++) {
				if (!listA.get(i)[1].isEmpty()) {
					listTE.add(listA.get(i)[1]);
					listTR.add(listA.get(i)[2]);
					listIT.add(listA.get(i)[3]);
					listSO.add(listA.get(i)[4]);
					listFileDcm[i] = listA.get(i)[5];
				} else {
					listTE.add(lastEl[1]);
					listTR.add(lastEl[2]);
					listIT.add(lastEl[3]);
					listSO.add(lastEl[4]);
					listFileDcm[i] = lastEl[5];
				}
			}

			hmSeq.put("00", listFileDcm);

			// listA.clear();

			listSlice[1] = String.join(" ", listTE);
			listSlice[2] = String.join(" ", listTR);
			listSlice[3] = String.join(" ", listIT);
			listSlice[4] = String.join(" ", listSO);

			listValues.put("Echo Time", deleteDuplicate(listSlice[1]));
			listValues.put("Repetition Time", deleteDuplicate(listSlice[2]));
			listValues.put("Inversion Time", deleteDuplicate(listSlice[3]));
			listValues.put("Slice Orientation", deleteDuplicate(listSlice[4]));

		} else {

		}

		listValues = new DicomDictionaryAdjustement().valuesAdjustement(listValues);

		hmInfo.put("00", listValues);

	}

	private String searchParam(String txt, String paramToFind) {
		String resul = "";
		int indx = txt.indexOf(paramToFind);
		try {
			if (indx != -1) {
				resul = txt.substring(indx);
				resul = resul.substring(resul.indexOf(":") + 1, resul.indexOf("\n"));
			}
		} catch (Exception e) {
			resul = "";
		}
		return resul.trim();
	}

	private String deleteDuplicate(String elements) {

		String resul = "";

		if (elements != null) {

			String[] list = null;

			list = elements.split(" +");

			List<String> array = Arrays.asList(list);
			Set<String> hs = new LinkedHashSet<>(array);
			list = Arrays.copyOf(hs.toArray(), hs.toArray().length, String[].class);

			for (String hh : list)
				resul += hh + " ";
		}

		return resul.trim();
	}

	@Override
	protected void compute() {
		run();
	}
}