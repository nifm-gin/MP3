package Dicom;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.RecursiveAction;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;


public class ListDicomDirSequence extends RecursiveAction implements ParamMRI2 {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String headerDicom, chemDicom;
	private int numberOfFrame;

	public ListDicomDirSequence(String chemDicom) {

		String headerDicom = hmData.get(chemDicom);
		headerDicom = new HeaderDicom().getHeaderDicom(headerDicom);

		int numberOfFrame = 1;

		Pattern pattern = Pattern.compile("(0028,0008)(\\s)(.*)");
		Matcher matcher = pattern.matcher(headerDicom);
		while (matcher.find()) {
			String group = matcher.group();
			group = group.substring(group.indexOf(": ") + 2);
			group = group.replaceAll(" ", "");
			if (Integer.parseInt(group) > 1) {
				numberOfFrame = 2;
				break;
			}
		}

		this.headerDicom = headerDicom;
		this.chemDicom = chemDicom;
		this.numberOfFrame = numberOfFrame;
		// searchList(headerDicom, chemDicom, NumberOfFrame);

	}

	public void run() {

		String[] listImDcm;
		String ImNum = "", fileName = "";
		String noSeq = null;

		if (numberOfFrame == 1) {
			listImDcm = headerDicom.split("Image Number: 0");
			ArrayList<String[]> listPathDicom = new ArrayList<>();

			for (int i = 1; i < listImDcm.length; i++) {
				if (i < 11)
					noSeq = "0" + String.valueOf(i - 1);
				else
					noSeq = String.valueOf(i - 1);

				Pattern pat = Pattern.compile("(0004,1500|0020,0013)(\\s)(.*)");
				Matcher match = pat.matcher(listImDcm[i]);
				Boolean val = false;
				String[] tmp;
				while (match.find()) {
					String resul = match.group();
					if (resul.contains("0004,1500") && !resul.contains("XX_") && !resul.contains("PS_")
							&& resul.contains(":")) {
						fileName = resul.substring(resul.indexOf(": ") + 2);
						val = true;
					}
					if (resul.contains("0020,0013") && val && !resul.contains("Image Number: 0")) {
						tmp = new String[2];
						ImNum = resul.substring(resul.indexOf(": ") + 2);
						val = false;
						tmp[0] = ImNum.trim();
						tmp[1] = fileName.trim();
						listPathDicom.add(tmp);
					}
				}

				if (!listPathDicom.isEmpty()) {

					Collections.sort(listPathDicom, new Comparator<Object[]>() {
						public int compare(Object[] strings, Object[] otherStrings) {
							return ((Integer) Integer.parseInt(strings[0].toString()))
									.compareTo((Integer) Integer.parseInt(otherStrings[0].toString()));
						}
					});

					String[] listPath = new String[listPathDicom.size()];
					for (int h = 0; h < listPathDicom.size(); h++)
						listPath[h] = chemDicom + PrefParam.separator + listPathDicom.get(h)[1].toString();

					hmSeq.put(noSeq, listPath);

					listPathDicom.clear();
				}
			}

		} else {
			listImDcm = headerDicom.split("0004,1430  >---: IMAGE");
			String[] tmp;
			for (int i = 1; i < listImDcm.length; i++) {
				if (i < 11)
					noSeq = "0" + String.valueOf(i - 1);
				else
					noSeq = String.valueOf(i - 1);

				ImNum = searchParam(listImDcm[i], "Image Number");
				fileName = searchParam(listImDcm[i], "0004,1500");
				if (!fileName.contains("XX_") && !fileName.contains("PS_") && !fileName.isEmpty()) {
					tmp = new String[1];
					tmp[0] = chemDicom + PrefParam.separator + fileName;
					hmSeq.put(noSeq, tmp);
				}
			}
		}

		for (String jj : hmSeq.keySet())
			new ListDicomParam(jj, numberOfFrame);

	}

	private String searchParam(String txt, String paramToFind) {
		String resul = "";
		int indx = txt.indexOf(paramToFind);
		try {
			if (indx != -1) {
				resul = txt.substring(indx);
				resul = resul.substring(resul.indexOf(":") + 1, resul.indexOf("\n"));
			}
		} catch (Exception e) {
			resul = "";
		}

		return resul.trim();
	}

	@Override
	protected void compute() {
		run();
	}
}