package Dicom;

import javax.swing.JPopupMenu;

import AbstractClass.SelectionData;
import MRIFileManager.FileManagerFrame;

public class SelectionDataDicom extends SelectionData{
	
	public SelectionDataDicom(FileManagerFrame wind) throws Exception {

	}

	@Override
	public void popMenuData(JPopupMenu popMenu) {
		
	}

}
