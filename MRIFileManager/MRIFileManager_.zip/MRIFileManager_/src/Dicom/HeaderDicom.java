package Dicom;

import ij.plugin.DICOM;

public class HeaderDicom {
	
	
	public HeaderDicom() {
	}
	
	public String getHeaderDicom(String pathDicom) {
		String txt = null;
		try {
			DICOM dcm = new DICOM();
			txt = dcm.getInfo(pathDicom);
			dcm.close();
		} catch (Exception e) {
			txt = "";
		}
		return txt;
	}
}