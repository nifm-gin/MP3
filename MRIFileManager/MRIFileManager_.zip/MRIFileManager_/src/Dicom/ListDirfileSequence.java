package Dicom;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.RecursiveAction;
import java.util.regex.Pattern;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;

public class ListDirfileSequence extends RecursiveAction implements ParamMRI2 {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String chemDicom;

	public ListDirfileSequence(String chemDicom) {
		this.chemDicom = chemDicom;
	}

	public void run() {

		String headerDicom = hmData.get(chemDicom); // repertoire +"dirfile"
													// (1er)

		headerDicom = new HeaderDicom().getHeaderDicom(headerDicom); // header
																		// de
																		// dirfile
																		// (1er)
		String[] listDirfile = headerDicom.split("0004,1500"); // split of
																// dirfile (2e)
		String stb;

		for (int i = 1; i < listDirfile.length; i++) {
			stb = listDirfile[i];
			stb = stb.substring(stb.indexOf(": ") + 2, stb.indexOf("\n"));
			stb = stb.replace("\\", PrefParam.separator);
			stb = getTruePath(chemDicom, stb); // list of dirfile (2e)
			headerDicom = new HeaderDicom().getHeaderDicom(chemDicom + PrefParam.separator + stb);
			searchListParam(headerDicom, chemDicom, String.valueOf(i - 1));
		}

	}

	private void searchListParam(String hdr, String pathDicom, String noSeq) {

		HashMap<String, String> listValues = new HashMap<>();

		String pathImDcm = searchParam(hdr, "0004,1500");
		pathImDcm = getTruePath(pathDicom, pathImDcm);

		String hdr2 = new HeaderDicom().getHeaderDicom(pathDicom + PrefParam.separator + pathImDcm);

		for (String kk : dictionaryMRISystem.keySet()) {
			if (dictionaryMRISystem.get(kk).get("file") != null) {
				if (dictionaryMRISystem.get(kk).get("file").contains("dirfile"))
					listValues.put(kk, searchParam(hdr, dictionaryMRISystem.get(kk).get("keyName")));
			} else
				listValues.put(kk, searchParam(hdr2, dictionaryMRISystem.get(kk).get("keyName")));
		}
		
		
		ArrayList<String[]> listA = new ArrayList<String[]>();

		if (Integer.parseInt(noSeq) < 10)
			noSeq = "0" + noSeq;

		String[] listImDcm = hdr.split("0004,1430");
		String[] listSlice = null;
		String[] tmp = new String[listImDcm.length - 1];
		String fileName;

		for (int i = 1; i < listImDcm.length; i++) {
			listSlice = new String[5]; // for Image Number, Echo Time,
										// Repetition Time, Inversion Time,
										// Slice Orientation
			listSlice[0] = searchParam(listImDcm[i], "Image Number");
			listSlice[1] = searchParam(listImDcm[i], "Echo Time");
			listSlice[2] = searchParam(listImDcm[i], "Repetition Time");
			listSlice[3] = searchParam(listImDcm[i], "Inversion Time");
			listSlice[4] = searchParam(listImDcm[i], "Image Orientation (Patient)");
			fileName = searchParam(listImDcm[i], "0004,1500");
			tmp[i - 1] = pathDicom + PrefParam.separator + getTruePath(pathDicom, fileName);
			try {
				listSlice[4] = new DicomOrientation(listSlice[4]).getOrientationDicom();
			} catch (Exception e) {
				listSlice[4] = "";
			}
			listA.add(listSlice);
		}

		hmSeq.put(noSeq, tmp);

		String[] lastEl = listA.get(listA.size() - 1).clone();

		Collections.sort(listA, new Comparator<Object[]>() {
			public int compare(Object[] strings, Object[] otherStrings) {
				return ((Integer) Integer.parseInt(strings[0].toString()))
						.compareTo((Integer) Integer.parseInt(otherStrings[0].toString()));
			}
		});

		for (int h = 0; h < 5; h++)
			listSlice[h] = "";

		List<String> listTE = new ArrayList<>();
		List<String> listTR = new ArrayList<>();
		List<String> listIT = new ArrayList<>();
		List<String> listSO = new ArrayList<>();

		for (int i = 0; i < listA.size(); i++) {
			if (!listA.get(i)[1].isEmpty()) {
				listTE.add(listA.get(i)[1]);
				listTR.add(listA.get(i)[2]);
				listIT.add(listA.get(i)[3]);
				listSO.add(listA.get(i)[4]);
			} else {
				listTE.add(lastEl[1]);
				listTR.add(lastEl[2]);
				listIT.add(lastEl[3]);
				listSO.add(lastEl[4]);
			}
		}

		listA.clear();

		for (String gg : listTE)
			listSlice[1] += gg + " ";

		for (String gg : listTR)
			listSlice[2] += gg + " ";

		for (String gg : listIT)
			listSlice[3] += gg + " ";

		for (String gg : listSO)
			listSlice[4] += gg + " ";

		listValues.put("Echo Time", deleteDuplicate(listSlice[1]));
		listValues.put("Repetition Time", deleteDuplicate(listSlice[2]));
		listValues.put("Inversion Time", deleteDuplicate(listSlice[3]));
		listValues.put("Slice Orientation", deleteDuplicate(listSlice[4]));
		listValues.put("Images In Acquisition", String.valueOf(hmSeq.get(noSeq).length));

		listValues = new DicomDictionaryAdjustement().valuesAdjustement(listValues);

		hmInfo.put(String.valueOf(noSeq), listValues);
	}

	private String searchParam(String txt, String paramToFind) {
		String resul = "";
		int indx = txt.indexOf(paramToFind);
		try {
			if (indx != -1) {
				resul = txt.substring(indx);
				resul = resul.substring(resul.indexOf(":") + 1, resul.indexOf("\n"));
			}
		} catch (Exception e) {
			resul = "";
		}

		return resul.trim();
	}

	private String getTruePath(String chemDcm, String pathDirfile) {

		String pattern = Pattern.quote(System.getProperty("file.separator"));

		for (int i = 0; i < pathDirfile.split(pattern).length; i++) {
			if (!new File(chemDcm + PrefParam.separator + pathDirfile).exists())
				pathDirfile = pathDirfile.substring(pathDirfile.indexOf(PrefParam.separator) + 1);
			else
				break;
		}
		return pathDirfile;
	}


	private String deleteDuplicate(String elements) {

		String resul = "";
		String[] list = null;

		list = elements.split(" +");

		List<String> array = Arrays.asList(list);
		Set<String> hs = new LinkedHashSet<>(array);
		list = Arrays.copyOf(hs.toArray(), hs.toArray().length, String[].class);

		for (String hh : list)
			resul += hh + " ";

		return resul.trim();
	}

	@Override
	protected void compute() {
		run();
	}
}