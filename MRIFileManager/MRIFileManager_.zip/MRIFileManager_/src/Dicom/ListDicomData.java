package Dicom;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;

public class ListDicomData extends PrefParam implements ParamMRI2 {

	private String[] paramListData = headerListData;
	private String headerDicom;

	public ListDicomData(String chemDicom) {

		headerDicom = chemDicom + separator + "DIRFILE";
		formatDicom = "DIRFILE";

		if (!new File(headerDicom).exists()) {
			headerDicom = chemDicom + separator + "DICOMDIR";
			formatDicom = "DICOMDIR";
			if (!new File(headerDicom).exists()) {
				headerDicom = null;
				formatDicom = "DCM";
			}
		}
		hmData.put(chemDicom, headerDicom);

		if (!formatDicom.contentEquals("DCM"))
			headerDicom = new HeaderDicom().getHeaderDicom(headerDicom);


		String pathRel = "";

		switch (formatDicom) {

		case "DIRFILE":
			pathRel = searchParam(headerDicom, "00E1,1019  ---: ");
			pathRel = pathRel.replace("\\", separator);
			headerDicom = chemDicom + separator + pathRel;

			if (!new File(headerDicom).exists()) {
				pathRel = pathRel.substring(pathRel.indexOf(separator) + 1);
				headerDicom = chemDicom + separator + pathRel;
			}
			break;

		case "DICOMDIR":
			pathRel = searchParam(headerDicom, "0004,1500  >---:");
			pathRel = pathRel.replace("\\", separator);
			headerDicom = chemDicom + separator + pathRel;
			break;

		case "DCM":
			File dcmFile = new File(chemDicom);

			for (File gh : dcmFile.listFiles()) {
				try {
					RandomAccessFile raf = new RandomAccessFile(gh, "r");
					raf.seek(128);
					if (raf.readLine().substring(0, 4).contains("DICM")) {
						raf.close();
						headerDicom = gh.getAbsolutePath();
						raf.close();
						break;
					}
					raf.close();
				} catch (Throwable ed) {
				}
			}
			break;

		default:
			break;
		}
		headerDicom = new HeaderDicom().getHeaderDicom(headerDicom);
	}

	public Object[] listParamDataDicom() throws IOException {
		Object[] resul = new Object[paramListData.length];

		for (int i = 2; i < resul.length; i++)
			resul[i] = searchParam(headerDicom, dictionaryMRISystem.get(paramListData[i]).get("keyName"));

		return resul;
	}

	private String searchParam(String txt, String paramToFind) {

		String resul = "";
		resul = txt.substring(txt.indexOf(paramToFind) + paramToFind.length() + 1);
		resul = resul.substring(0, resul.indexOf("\n"));

		return resul.trim();
	}
}