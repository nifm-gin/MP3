package Dicom;

import AbstractClass.ParamMRI2;
import ij.ImagePlus;
import ij.ImageStack;
import ij.plugin.DICOM;

public class OpenDicom implements ParamMRI2 {

	public OpenDicom(String noSeq) {
		DICOM dcm;
		ImagePlus imp;
		ImageStack ims;

		if (hmSeq.get(noSeq).length == 1) {
			dcm = new DICOM();
			dcm.open(hmSeq.get(noSeq)[0]);
			dcm.show();
		} else {
			imp = new ImagePlus(hmSeq.get(noSeq)[0]);
			ims = new ImageStack(imp.getWidth(),imp.getHeight());
			for (String kk : hmSeq.get(noSeq)) {
				imp = new ImagePlus(kk);
				ims.addSlice(imp.getProcessor());
			}
			imp = new ImagePlus(noSeq, ims);
			imp.resetDisplayRange();
			imp.show();
		}

	}
}