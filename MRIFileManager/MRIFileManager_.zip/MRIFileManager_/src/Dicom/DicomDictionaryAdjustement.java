package Dicom;

import java.util.HashMap;

public class DicomDictionaryAdjustement {
	
	public DicomDictionaryAdjustement() {
	}
	
	public HashMap<String, String> valuesAdjustement(HashMap<String, String> listValues) {
		
		String tmp;
		
		listValues.put("Scan Resolution", listValues.get("Rows")+" "+listValues.get("Columns"));
				
		tmp = listValues.get("Read Direction");
		String read_direction = "";
		if (tmp.split(" +")[0].contentEquals("0")) { // case column read
														// direction
			for (String gg : listValues.get("Slice Orientation").split(" +"))
				switch (gg) {
				case "axial":
					read_direction += "L_R ";
					break;
				case "coronal":
					read_direction += "L_R ";
					break;
				case "sagittal":
					read_direction += "A_P ";
					break;
				case "oblique":
					read_direction += "nc ";
					break;
				}
			listValues.put("Read Direction", read_direction.trim());
		} else { // case row read direction
			for (String gg : listValues.get("Slice Orientation").split(" +"))
				switch (gg) {
				case "axial":
					read_direction += "A_P ";
					break;
				case "coronal":
					read_direction += "H_F " ;
					break;
				case "sagittal":
					read_direction += "H_F ";
					break;
				case "oblique":
					read_direction += "nc ";
					break;
				}
			listValues.put("Read Direction", read_direction.trim());
		}
		
		return listValues;
	}

}
