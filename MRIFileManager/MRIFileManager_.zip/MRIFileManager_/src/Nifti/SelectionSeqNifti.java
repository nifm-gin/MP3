package Nifti;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import AbstractClass.ParamMRI2;
import AbstractClass.SelectionSeq;
import MRIFileManager.ExtractTxtfromFile;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;
import MRIFileManager.OpenImageJ;
import MRIFileManager.ShowImagePanel;
import MRIFileManager.ThumbnailList;
import MRIFileManager.TreeInfo2;
import ij.IJ;

public class SelectionSeqNifti implements ParamMRI2, SelectionSeq {

	private FileManagerFrame wind;
	private String seqSelected;

	public SelectionSeqNifti(FileManagerFrame wind) {
		this.wind = wind;
		seqSelected = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRow(), 0).toString();
	}

	@Override
	public void goSelectionSeq() {

		try {
			wind.getTreeInfoGeneral().setModel(new TreeInfo2(listParamInfoSystem, hmInfo.get(seqSelected)).getTreeInfo().getModel());
			for (int j = 0; j < wind.getTreeInfoGeneral().getRowCount(); j++)
				wind.getTreeInfoGeneral().expandRow(j);
			wind.getTreeInfoUser().setModel(new TreeInfo2(listParamInfoUser, hmInfo.get(seqSelected)).getTreeInfo().getModel());
			for (int j = 0; j < wind.getTreeInfoUser().getRowCount(); j++)
				wind.getTreeInfoUser().expandRow(j);
		} catch (Exception e1) {
			new GetStackTrace(e1);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
		}

		new ShowImagePanel(wind, new OpenNifti(seqSelected, false, seqSelected).getImp(),seqSelected);

		String seqSel;

		if (wind.getTabSeq().getSelectedRowCount() == 1) {
			seqSel = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[0], 0).toString();
			ThumbnailList.list.setSelectedValue(seqSel, true);
		} else {
			int[] ls = new int[wind.getTabSeq().getSelectedRowCount()];
			for (int i = 0; i < wind.getTabSeq().getSelectedRowCount(); i++) {
				seqSel = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i], 0).toString();
				for (int g = 0; g < ThumbnailList.list.getModel().getSize(); g++)
					if (ThumbnailList.list.getModel().getElementAt(g) == seqSel)
						ls[i] = g;
			}
			ThumbnailList.list.setSelectedIndices(ls);
		}

	}

	@Override
	public void popMenuSeq(JPopupMenu pm) {
		JMenuItem sampleOpen = new JMenuItem("Open image(s) Ctrl+o");
		pm.add(sampleOpen);

		sampleOpen.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				openImage();
			}
		});
		/*********************************************************************************/
		pm.addSeparator();
		/*********************************************************************************/
		
		JMenuItem openParamFile = new JMenuItem("see Nifti header");
		
		openParamFile.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				showParamFile(hmSeq.get(seqSelected)[0], "header");
				
			}
		});
		pm.add(openParamFile);
		
		JMenuItem seeJsonFile = new JMenuItem("see Json file");
		pm.add(seeJsonFile);
		seeJsonFile.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				showParamFile(hmSeq.get(seqSelected)[0], "see Json file");
			}
		});
	}

	@Override
	public void openImage() {
		new OpenImageJ();

		for (int i = 0; i < wind.getTabSeq().getSelectedRowCount(); i++) {
			String seqSelected = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i], 0).toString();
			new OpenNifti(seqSelected, true, seqSelected);
		}
	}

	@Override
	public void fillBasket() {
	}

	@Override
	public void showParamFile(String chemFile, String keyword) {

		String tm = "";
		
		if (keyword.contains("header")) {
			Nifti1Dataset niftiHdr = new Nifti1Dataset(chemFile);
			try {
				niftiHdr.readHeader();
				tm=chemFile+"\n"+niftiHdr.getHeader();
			} catch (Exception e) {
				new GetStackTrace(e);
				FileManagerFrame.getBugText().setText(
						FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
			} 
		}
		
		else if (keyword.contentEquals("see Json file")) {

			String pathFile = chemFile.replace(".nii", ".Json");

			if (!new File(pathFile).exists()) {
				JOptionPane.showMessageDialog(wind, "Json doesn't exist");
				return;
			}
			
			else {
				tm = new ExtractTxtfromFile(pathFile).getTxt();
			}
			
			
		}
		
		new OpenImageJ();
		IJ.log(tm);
		
		
	}
}