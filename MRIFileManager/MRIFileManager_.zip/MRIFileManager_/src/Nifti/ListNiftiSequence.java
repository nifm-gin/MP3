package Nifti;

import java.io.IOException;
import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;

public class ListNiftiSequence extends PrefParam implements ParamMRI2 {

	private String[] listParamSeq = headerListSeq;
	private int noSeq;
	private String pathNifti;

	public ListNiftiSequence(String pathNifti, int noSeq) {

		this.pathNifti = pathNifti;
		this.noSeq = noSeq;

	}

	public String[] ListSeqNifti() throws IOException {

		String[] resul = new String[listParamSeq.length];
		if (noSeq < 10)
			resul[0] = "0" + String.valueOf(noSeq);
		else
			resul[0] = String.valueOf(noSeq);

		/**********************
		 * Hashmap hm add
		 *******************************************************/
		String[] hmValue = new String[1];
		hmValue[0] = pathNifti;
		hmSeq.put(resul[0].toString(), hmValue);
		new FillHmsNifti2(resul[0].toString());

		for (int i = 1; i < resul.length; i++) {
			resul[i] = hmInfo.get(resul[0].toString()).get(listParamSeq[i]);
			if (resul[i] == null)
				resul[i] = "";
			else {
				resul[i] = resul[i].replace("[", "");
				resul[i] = resul[i].replace("]", "");
				resul[i] = resul[i].replace("\"", "");
				resul[i] = resul[i].replace(",", " ");
			}
		}

		return resul;
	}
}