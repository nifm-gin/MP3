package Nifti;

import java.io.FileReader;
import java.util.HashMap;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class ReadJson {

	private JSONParser parser = new JSONParser();
	private Object obj, obj1;
	private HashMap<String, String> listObject = new HashMap<>();

	public ReadJson(String jsonPath) {

		try {
			obj = parser.parse(new FileReader(jsonPath));
			JSONObject object = (JSONObject) obj;
			listObject(object);
			// for (String sr : listObject.keySet())
			// System.out.println(sr+" : "+listObject.get(sr));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void listObject(JSONObject object) {

		for (Object sw : object.keySet().toArray()) {

			try {
				obj = parser.parse(object.get(sw).toString());

				if (obj.toString().contains("{")) {
					listUnderObject((JSONObject) object.get(sw));
				} else
					listObject.put(sw.toString(), obj.toString());
			} catch (Exception e) {
				listObject.put(sw.toString(), obj.toString());
			}
		}
	}

	private void listUnderObject(JSONObject underObject) {
		for (Object sx : underObject.keySet().toArray()) {
			try {
				obj1 = parser.parse(underObject.get(sx).toString());
				if (obj1.toString().contains("{"))
					listUnderObject((JSONObject) underObject.get(sx));
				else
					listObject.put(sx.toString(), underObject.get(sx).toString());
			} catch (Exception e) {
				listObject.put(sx.toString(), underObject.get(sx).toString());
			}
		}
	}

	public HashMap<String, String> getlistObject() {
		// for (String hh : listObject.keySet())
		// System.out.println(hh+" : "+listObject.get(hh));
		return listObject;
	}
}