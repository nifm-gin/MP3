package Nifti;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.net.URL;
import javax.swing.ImageIcon;
import AbstractClass.ImageThumb;
import AbstractClass.ParamMRI2;
import ij.ImagePlus;
import ij.io.FileInfo;
import ij.io.FileOpener;

public class ImageThumbNifti extends ImageThumb implements ParamMRI2 {

	private Image img;
	private ImagePlus imp;

	private URL imgURL = getClass().getResource("/WhiteScreen.jpg");

	@Override
	public Image ImageThumbShow(String noSeq) {

		String[] listParamToFind = { "Scan Resolution", "Images In Acquisition", "Byte Order", "Data Type" };
		String[] values = new String[listParamToFind.length];

		for (int i = 0; i < values.length; i++) {
			values[i] = hmInfo.get(noSeq).get(listParamToFind[i]);
			
			if (values[i] == "") {
				img = new ImageIcon(imgURL).getImage();
				return img;
			}
		}
		
		String tmp;
		int w, h, nImage = 1;

		FileInfo fi = new FileInfo();

		tmp = values[0].toString();
		
		w = Integer.parseInt(tmp.split(" +")[0]);
		h = Integer.parseInt(tmp.split(" +")[1]);

		nImage = Integer.parseInt(values[1]);

		Float f = new Float(nImage);
		int intValue = f.intValue();
		intValue = intValue / 2;

		tmp = values[3];
		int mult = 1;

		if (tmp.contains("NIFTI_TYPE_INT16")) {
			fi.fileType = FileInfo.GRAY16_UNSIGNED;
			mult = 2;
		} else if (tmp.contains("NIFTI_TYPE_FLOAT32")) {
			fi.fileType = FileInfo.GRAY32_FLOAT;
			mult = 4;
		} else {
			fi.fileType = FileInfo.GRAY8;
		}

		int off = w * h * intValue * mult;

		
		fi.fileName = hmInfo.get(noSeq).get("File path");
		fi.width = w;
		fi.height = h;
		fi.offset = off + 348;
		fi.nImages = 1;

		if (values[2].contains("little"))
			fi.intelByteOrder = true;
		else
			fi.intelByteOrder = false;

		FileOpener fo = new FileOpener(fi);

		imp = fo.open(false);
		imp.resetDisplayRange();

		if (imp != null)
			img = imp.getImage();

		img = getScaledImage(img, 120, 120);

		return img;
	}

	private Image getScaledImage(Image srcImg, int w, int h) {
		BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = resizedImg.createGraphics();

		g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2.drawImage(srcImg, 0, 0, w, h, null);
		g2.dispose();

		return resizedImg;
	}
}