package Nifti;

import AbstractClass.ParamMRI2;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;

public class FillHmsNifti2 implements ParamMRI2 {

	public FillHmsNifti2(String seqSel) {

			try {
				ListNiftiParam2 listNiftiPar = new ListNiftiParam2(hmSeq.get(seqSel)[0],seqSel);
				hmInfo.put(seqSel, listNiftiPar.ListParamValue());
				hmOrderImage.put(seqSel, listNiftiPar.ListOrderStack("",""));
			} catch (Exception e) {
				new GetStackTrace(e);
				FileManagerFrame.getBugText().setText(
						FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
			}
	}
}