package Nifti;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;


public class TableNiftiSequence extends PrefParam implements ParamMRI2{

	private Object[][] data;
	private List<String> listNifti = new ArrayList<String>();

	public TableNiftiSequence(String repertory) throws IOException {

		List<String> listNifti = searchNifti(repertory);

		if (listNifti != null) {
			data = new Object[listNifti.size()][headerListSeq.length];
			for (int i = 0; i < data[0].length; i++)
				data[0][i] = "";
			data[0][0] = "no Nifti file(s) found";

			for (int i = 0; i < data.length; i++) 
				data[i] = new ListNiftiSequence(repertory+separator+listNifti.get(i),i).ListSeqNifti();

		} else {
			data = new Object[1][headerListSeq.length];
			for (int i = 0; i < data[0].length; i++)
				data[0][i] = i;
			data[0][0] = "no Nifti file(s) found";
		}
		
		

	}

	private List<String> searchNifti(String rep) {
		String[] listOfFiles = new File(rep).list();

		for (String lg : listOfFiles)
			if (lg.endsWith(".nii"))
				listNifti.add(lg);

		return listNifti;
	}

	public Object[][] getSequence() {
		return data;
	}

}
