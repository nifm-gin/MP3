package Nifti;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import AbstractClass.PrefParam;

public class ListNiftiData extends PrefParam {

	private String pathNifti;

	public ListNiftiData(String pathNifti) {
		this.pathNifti = pathNifti;
	}

	public Object[] listParamDataNifti() throws IOException {
		Object[] resul = new Object[8];

		File f = new File(searchNifTI(".nii", pathNifti));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date d = new Date(f.lastModified());

		resul[0] = iconNifTI;
		resul[1] = "";
		resul[2] = "";//f.getName().substring(0, f.getName().indexOf("."));
		resul[3] = "";
		resul[4] = sdf.format(d);
		for (int j = 5; j < 8; j++)
			resul[j] = "";

		return resul;
	}

	private String searchNifTI(String extToFind, String searchIn) {

		String fileNifTI = null;
		String[] listOfFiles = new File(searchIn).list();

		int i = 0;

		try {
			while (i < listOfFiles.length) {
				if (listOfFiles[i].endsWith(extToFind)) {
					fileNifTI = listOfFiles[i];
					break;
				}
				i++;
			}
		} catch (Exception e) {

		}
		return searchIn + separator + fileNifTI;
	}
}