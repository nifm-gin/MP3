package Nifti;

import java.awt.EventQueue;
import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;
import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.gui.StackWindow;
import ij.io.FileInfo;
import ij.io.FileOpener;
import ij.measure.Calibration;
import ij.plugin.HyperStackConverter;
import ij.process.ImageProcessor;

public class OpenNifti implements ParamMRI2{

	private ImagePlus imp;
	

	public OpenNifti(String noSeq, Boolean show, String title) {
	
		String tmp = null, order;
		int w, h;
		float pxw, pxh, pxz;
		int c, z, t;

		tmp = hmInfo.get(noSeq).get("Scan Resolution");
		w = Integer.parseInt(tmp.split(" ")[0]);
		h = Integer.parseInt(tmp.split(" ")[1]);

		pxw = Float.parseFloat(hmInfo.get(noSeq).get("Spatial Resolution").split(" +")[0]);
		pxh = Float.parseFloat(hmInfo.get(noSeq).get("Spatial Resolution").split(" +")[1]);
		pxz = Float.parseFloat(hmInfo.get(noSeq).get("Spatial Resolution").split(" +")[2]);

		order = hmOrderImage.get(noSeq)[0].toString();

		c = (int) hmOrderImage.get(noSeq)[1];
		z = (int) hmOrderImage.get(noSeq)[2];
		t = (int) hmOrderImage.get(noSeq)[3];

		FileInfo fi = new FileInfo();

		tmp = hmInfo.get(noSeq).get("Data Type");

		if (tmp.contains("NIFTI_TYPE_INT16"))
			fi.fileType = FileInfo.GRAY16_UNSIGNED;
		else if (tmp.contains("NIFTI_TYPE_FLOAT32"))
			fi.fileType = FileInfo.GRAY32_FLOAT;
		else {
			fi.fileType = FileInfo.GRAY8;
		}

		tmp = hmInfo.get(noSeq).get("File path");

		fi.fileFormat = FileInfo.RAW;
		fi.fileName = tmp;
		fi.width = w;
		fi.height = h;
		fi.offset = 352;
		fi.gapBetweenImages = 0;

		if (hmInfo.get(noSeq).get("Byte Order").contains("little"))
			fi.intelByteOrder = true;
		else
			fi.intelByteOrder = false;
		fi.unit = "mm";
		fi.valueUnit = "mm";

		fi.nImages = Integer.parseInt(hmInfo.get(noSeq).get("Images In Acquisition"));

		fi.pixelWidth = pxw;
		fi.pixelHeight = pxh;
		fi.pixelDepth = pxz;
		fi.frameInterval=1;

		FileOpener fo = new FileOpener(fi);
		imp = fo.open(false);
		imp.setTitle(title);
		imp=convertToGray32(imp);

		imp = HyperStackConverter.toHyperStack(imp, c, z, t, order, "grayscale");
		imp.resetDisplayRange();
		
		if (show)
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				new StackWindow(imp);				
			}
		});

	}

	public ImagePlus getImp() {
		return imp;
	}

	private ImagePlus convertToGray32(ImagePlus imgtmp) {

		int width = imgtmp.getWidth();
		int height = imgtmp.getHeight();
		int nSlices = imgtmp.getStackSize();

		if (imgtmp.getType() != ImagePlus.GRAY32) {
			ImageStack stack1 = imgtmp.getStack();
			ImageStack stack2 = new ImageStack(width, height);
			String label;
			int inc = nSlices / 20;
			if (inc < 1)
				inc = 1;
			ImageProcessor ip1, ip2;
			Calibration cal = imgtmp.getCalibration();
			for (int i = 1; i <= nSlices; i++) {
				label = stack1.getSliceLabel(1);
				ip1 = stack1.getProcessor(1);
				ip1.setCalibrationTable(cal.getCTable());
				ip2 = ip1.convertToFloat();
				stack1.deleteSlice(1);
				stack2.addSlice(label, ip2);
				if ((i % inc) == 0) {
					IJ.showProgress((double) i / nSlices);
					IJ.showStatus("Converting to 32-bits: " + i + PrefParam.separator + nSlices);
				}
			}
			IJ.showProgress(1.0);
			imgtmp.setStack(null, stack2);
			imgtmp.setCalibration(imgtmp.getCalibration()); // update
															// calibration
		}
		return imgtmp;
	}
}