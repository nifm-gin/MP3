package AbstractClass;

import java.awt.Image;
import java.net.URL;

import javax.swing.ImageIcon;

public abstract class ImageThumb {
	
	private URL imgURL = getClass().getResource("/WhiteScreen.jpg");
	
	public abstract Image ImageThumbShow(String pathFile);
	
	public Image ImageThumbShow() {
		Image img = new ImageIcon(imgURL).getImage();
		return img;
	}
}