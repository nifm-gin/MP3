package AbstractClass;

import java.awt.Cursor;

import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.table.TableRowSorter;

import BrukerParavision.TableBrukerSequence;
import Dicom.TableDicomSequence;
import MRIFileManager.ChangeDetailSeq;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;
import MRIFileManager.TableModel;
import MRIFileManager.ThumbnailList;
import MRIFileManager.TreeInfo2;
import Nifti.TableNiftiSequence;
import Philips.TablePhilipsSequence;

public abstract class SelectionData extends PrefParam implements ParamMRI2, Format {

	public SelectionData() {

	}

	public abstract void popMenuData(JPopupMenu popMenu);

	public void goSelectionData(FileManagerFrame wind) {
		wind.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		Object[][] seq = null;

		hmSeq.clear();
		hmInfo.clear();

		wind.getBoxThumb().removeAll();
		wind.getBoxThumb().updateUI();
		wind.getScrollThumb().updateUI();
		wind.resetTabSeq();

		try {
			wind.getTabData().getValueAt(0, 1).toString();
		} catch (Exception e) {
			return;
		}

		if (!wind.getTabData().getValueAt(0, 1).toString().isEmpty()) {
			try {

				switch (formatCurrentInt) {
				case Bruker:
					seq = new TableBrukerSequence(wind.getListPath().getSelectedItem().toString().substring(12)
							+ separator + wind.getTabData().getValueAt(wind.getTabData().getSelectedRow(), 1))
									.getSequence();
					break;
				case Philips:
					seq = new TablePhilipsSequence(wind.getListPath().getSelectedItem().toString().substring(12)
							+ separator + wind.getTabData().getValueAt(wind.getTabData().getSelectedRow(), 1))
									.getSequence();
					break;

				case Dicom:
					seq = new TableDicomSequence(wind.getListPath().getSelectedItem().toString().substring(12)
							+ separator + wind.getTabData().getValueAt(wind.getTabData().getSelectedRow(), 1))
									.getSequence();
					break;
				case Nifti:
					seq = new TableNiftiSequence(wind.getListPath().getSelectedItem().toString().substring(12)
							+ separator + wind.getTabData().getValueAt(wind.getTabData().getSelectedRow(), 1))
									.getSequence();

					break;
				}

			} catch (Exception e) {
				new GetStackTrace(e);
				FileManagerFrame.getBugText().setText(
						FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
			}
		}
		int[] listWidthColumn = null;
		boolean tr = false;
		if (wind.getTabSeq().isEnabled()) {
			listWidthColumn = wind.widthColumnJtable(wind.getTabSeq());
			tr = true;
		}

		TableModel model = new TableModel(seq, ParamMRI2.headerListSeq);
		TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(model);
		wind.getTabSeq().setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		wind.getTabSeq().setModel(model);
		wind.getTabSeq().setRowSorter(sorter);
		wind.getTabSeq().setEnabled(true);

		if (tr)
			for (int i = 0; i < listWidthColumn.length; i++)
				wind.getTabSeq().getColumnModel().getColumn(i).setPreferredWidth(listWidthColumn[i]);

		wind.getTabSeq().getRowSorter().toggleSortOrder(0);
		new ChangeDetailSeq(wind);
		wind.getTabSeq().updateUI();

		wind.getTreeInfoGeneral().setModel(new TreeInfo2(ParamMRI2.listParamInfoSystem, null).getTreeInfo().getModel());
		for (int j = 0; j < wind.getTreeInfoGeneral().getRowCount(); j++)
			wind.getTreeInfoGeneral().expandRow(j);

		wind.getTreeInfoUser().setModel(new TreeInfo2(ParamMRI2.listParamInfoUser, null).getTreeInfo().getModel());
		for (int j = 0; j < wind.getTreeInfoUser().getRowCount(); j++)
			wind.getTreeInfoUser().expandRow(j);

		// hmInfo.clear();
		// hmOrderImage.clear();

		wind.getBoxImage().removeAll();
		wind.getPreview().updateUI();

		wind.getTabSeq().setRowSelectionInterval(0, 0);

		Thread t = new Thread(new ThumbnailList(wind));
		t.start();
	}
}