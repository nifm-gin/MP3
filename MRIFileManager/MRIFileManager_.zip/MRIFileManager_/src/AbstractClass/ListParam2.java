package AbstractClass;

import java.io.IOException;
import java.util.HashMap;

public interface ListParam2 {

	public abstract HashMap<String, String> ListParamValue() throws IOException;

	public abstract Object[] ListOrderStack(String dim, String nImage);

}
