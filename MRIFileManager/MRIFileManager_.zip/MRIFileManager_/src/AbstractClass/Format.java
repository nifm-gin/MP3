package AbstractClass;

public interface Format {
	
	public static final int
	Bruker=0,
	Dicom=1,
	Philips=2,
	Nifti=3;
	
	public enum format {
		Bruker("Bruker"),
		Dicom("Dicom"),
		Philips("Philips"),
		Nifti("Nifti");

		private int nb;
		
		format(String name) {
			if (name.contains("Bruker")) nb=0;
			if (name.contains("Dicom")) nb=1;
			if (name.contains("Philips")) nb=2;
			if (name.contains("Nifti")) nb=3;
		}
		public int toInt() {
			return nb;
		}
	}
}