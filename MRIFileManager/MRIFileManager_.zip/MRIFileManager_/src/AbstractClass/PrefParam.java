package AbstractClass;

import java.io.File;

import javax.swing.ImageIcon;

public class PrefParam {
	
	public static String[] nameLookAndFeel = { "Nimbus", "Noire", "Texture", "McWin","Aluminium","Bernstein","Graphite","Luna","Mint"
												,"HiFi","Fast","Aero","Acryl","Smart" };

	public static String[] urlLookAndFeel = { 	"com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel", 	//Nimbus
												"com.jtattoo.plaf.noire.NoireLookAndFeel",				//Noire
												"com.jtattoo.plaf.texture.TextureLookAndFeel",			//Texture
												"com.jtattoo.plaf.mcwin.McWinLookAndFeel",				//McWin
												"com.jtattoo.plaf.aluminium.AluminiumLookAndFeel",		//Aluminium
												"com.jtattoo.plaf.bernstein.BernsteinLookAndFeel",		//Bernstein
												"com.jtattoo.plaf.graphite.GraphiteLookAndFeel",		//Graphite
												"com.jtattoo.plaf.luna.LunaLookAndFeel",				//Luna
												"com.jtattoo.plaf.mint.MintLookAndFeel",				//Mint
												"com.jtattoo.plaf.hifi.HiFiLookAndFeel",				//HiFi
												"com.jtattoo.plaf.fast.FastLookAndFeel",				//Fast
												"com.jtattoo.plaf.aero.AeroLookAndFeel",				//Aero
												"com.jtattoo.plaf.acryl.AcrylLookAndFeel",				//Acryl	
												"com.jtattoo.plaf.smart.SmartLookAndFeel",				//Smart
												};


	public static String separator, LookFeelCurrent;

	public static int widthScreen, heightScreen;

	public static ImageIcon iconBruker, iconDicom, iconNifTI, iconPhilips;
	
	public static String lectBruker, lectDicom, lectParRec, lectNifTI;

	public static String formatCurrent, namingNiftiExport, formatDicom;
	
	public static String lectCurrent;
	
	public static String pathDictionaryUser;
	
	public static int formatCurrentInt;

	public static File FilestmpRep, FilestmpExportNifit;
}