package AbstractClass;

import java.util.HashMap;
import java.util.List;

import javax.swing.DefaultListModel;

public interface ParamMRI2 {
	
	/******************************* header table *******************************************************/
	public final String[] headerListData = {"Format","Directory/File","Patient Name","Study Name","Creation Date","Patient Sex","Patient Weight","Patient BirthDate"};
	public final String[] headerListSeq 	= {"Seq. n�","Protocol","Sequence Name","Acquisition Time","Acquisition Date","Scan Mode","Echo Time","Repetition Time","Inversion Time","Slice Orientation","Flip Angle"};

	/******************************* Dictionnary MRI ****************************************************************/
	public HashMap<String, HashMap<String, String>> dictionaryMRISystem = new HashMap<String, HashMap<String, String>>(); 
	// (key#1 : value#1) = (labelMRI , (key#2 : value#2) = (tags 'where' yaml : value))
	
	public HashMap<String, HashMap<String, String>> dictionaryMRIUser = new HashMap<String, HashMap<String, String>>(); 
	// (key#1 : value#1) = (labelMRI , (key#2 : value#2) = (tags 'where' yaml : value))
	
	public HashMap<String, HashMap<String, String>> dictionaryJsonSystem = new HashMap<String, HashMap<String, String>>(); 
	// (key#1 : value#1) = (labelMRI , (key#2 : value#2) = (tag 'json' yaml : value))
	
	public HashMap<String, HashMap<String, String>> dictionaryJsonUser = new HashMap<String, HashMap<String, String>>(); 
	// (key#1 : value#1) = (labelMRI , (key#2 : value#2) = (tag 'json' yaml : value))
	
	/******************************* for Information viewer ***********************************************************/
	public HashMap<String,List<String>> listParamInfoSystem = new HashMap<String,List<String>>(); 
	//(key : value) = (category , list of label MRI ) DictionaryMRI_system.yml
	
	public HashMap<String,List<String>> listParamInfoUser = new HashMap<String,List<String>>(); 
	//(key : value) = (category , list of label MRI ) DictionaryMRI_user.yml

	/******************************* HashMap for each sequence ******************************************************/
	public HashMap<String, String> hmData = new HashMap<>(); // only for Dicom , associate listData with path of DicomDir or DirFile
	
	public HashMap<String, String[]> hmSeq = new HashMap<>(); // listSeq for data selected (key,value)=(n� Seq , pathFile)
	
	public HashMap<String, HashMap<String,String>> hmInfo = new HashMap<>(); 
	// (key#1 : value#1) = (n� seq , (key#2 : value#2) =(labelMRI : value))
	
	public HashMap<String, Object[]> hmOrderImage = new HashMap<>(); // order stack image (key,value)=(n� Seq , {xyczt,c,z,t,info})

	/******************************* List basket ********************************************************************/
	public DefaultListModel<String> listinBasket = new DefaultListModel<>();
	public HashMap<String, HashMap<String,String>> listBasket_hms= new HashMap<String, HashMap<String,String>>(); //(key,value)=(listinBasket ,list#2 hmInfo)
	public HashMap<String, Object[]> listBasket_hmo= new HashMap<String, Object[]>(); //(key,value)=(listinBasket ,listParamInfo)

	/******************************* List process ********************************************************************/
	public String[] listProcessLabel = {"T1map","T2map","TImap","T1map_FA","pCasl"};
}