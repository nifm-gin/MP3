package MRIFileManager;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import ij.IJ;
import ij.ImageJ;

public class OpenImageJ {

	private ImageJ ij;
	// private Process proc;

	public OpenImageJ() {

		if (IJ.getInstance() == null) {
			System.getProperties().setProperty("plugins.dir",
					System.getProperty("user.dir") + File.separator + "dist" + File.separator);

			ij = new ImageJ();

			IJ.maxMemory();
			ij.addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(final WindowEvent e) {
					for (java.awt.Window fg : java.awt.Window.getWindows()) {
						if (!fg.toString().contains("MRIFileManager") && !fg.toString().contains("Log"))
							fg.dispose();
					}
				}

				@Override
				public void windowClosed(final WindowEvent e) {
					for (java.awt.Window fg : java.awt.Window.getWindows()) {
						if (!fg.toString().contains("MRIFileManager") && !fg.toString().contains("Log"))
							fg.dispose();
					}
				}
			});
		}
	}

	// public OpenImageJ(String pathImageJ) {
	// try {
	// proc = Runtime.getRuntime().exec(pathImageJ);
	// System.out.println(proc.getInputStream().toString());
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }

}