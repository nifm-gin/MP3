package MRIFileManager;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.table.TableRowSorter;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;
import ExportFiles.BasketManager;
import ExportFiles.ExportFiles;

public class FileManagerFrame extends JFrame implements ItemListener {

	private static final long serialVersionUID = -9059196585238802336L;
	public static String OS = System.getProperty("os.name").toLowerCase();
	private int WScreen, HScreen;
	private int WFrame, HFrame;

	private JFrame winBug, frameDetailSeq;
	private static JTextArea textBug;

	private JCheckBoxMenuItem showicon;
	private JSplitPane split1, split2, split3, split4;

	private JTabbedPane tabPrincipal = new JTabbedPane();
	private JTabbedPane tabInfoParam = new JTabbedPane();

	private JComboBox<String> listPath;

	private JTextField[] textFieldManagingDiction = new JTextField[4];
	private JCheckBox chJson;
	private JButton buttonRec;

	private JTable tabData, tabSeq, tabDictionnaryMri;
	private JTree treeParamInfoGeneral,treeParamInfoUser;
	private JScrollPane treeInfoGeneral, treeInfoUser;

	private JScrollPane preview, thumb, treeData;

	private Box boxImage, boxSlid1, boxSlid2, boxSlid3, boxThumb;

	private JSlider slidImage1, slidImage2, slidImage3;
	private JLabel c, z, t;

	private JList<String> listOfBasket;
	private JLabel pathExportNifti, pathDictionnary;

	private JDialog dlg;

	private JPopupMenu popupMenuDetailSeq;
	private JCheckBoxMenuItem[] itemSeqDetail;
	private JCheckBox[] ls;

	public static void main(String[] args) {
		new FileManagerFrame().run(args);
	}

	public void run(String[] arg) {

		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {

				PrefParam.FilestmpExportNifit = null;

				for (String jj : arg) {
					if (jj.contains("ExportNifti")) {
						jj = jj.substring(jj.indexOf("]") + 1);
						jj = jj.replace(" ", "");
						PrefParam.FilestmpExportNifit = new File(jj);
						break;
					}
				}

				Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

				WScreen = (int) screenSize.getWidth();
				HScreen = (int) screenSize.getHeight();

				PrefParam.widthScreen = WScreen;
				PrefParam.heightScreen = HScreen;

				try {
					init();
					buildBug();
					MriFilesWindow();
					buildBasketWindow();
					buildDetailDisplaySeq();
					buildProgress();
					lookFeel();
				} catch (Exception e) {
					new GetStackTrace(e);
					FileManagerFrame.getBugText().setText(FileManagerFrame.getBugText().getText()
							+ "\n----------------\n" + GetStackTrace.getMessage());
				}
				
			}
		});
	}

	private void init() {

		PrefParam.separator = File.separator;
		PrefParam.LookFeelCurrent = "Nimbus";

		URL URLBruker = getClass().getResource("/BrukerLogo32.jpg");
		PrefParam.iconBruker=new ImageIcon(URLBruker);
		URL URLDicom = getClass().getResource("/Dicom_dcm_Logo32.jpg");
		PrefParam.iconDicom=new ImageIcon(URLDicom);
		URL URLPhilips = getClass().getResource("/PhilipsLogo32.jpg");
		PrefParam.iconPhilips=new ImageIcon(URLPhilips);
		URL URLNifti = getClass().getResource("/NifTILogo32.jpg");
		PrefParam.iconNifTI=new ImageIcon(URLNifti);
		
		PrefParam.lectBruker = " ";
		PrefParam.LookFeelCurrent = "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel";

		new PrefParamLoad(); // paths file in FilestmpRep.txt
	}

	private void buildBug() {

		winBug = new JFrame();
		winBug.setTitle("Error window");
		winBug.setLocationRelativeTo(null);
		winBug.setResizable(true);
		winBug.setSize(WScreen / 4, HScreen / 5);

		JPanel panel4 = new JPanel();

		panel4.setLayout(new FlowLayout());
		panel4.setBackground(Color.GRAY);
		textBug = new JTextArea("empty for instant");
		textBug.setEditable(false);

		JScrollPane scrollPaneArea = new JScrollPane(textBug);
		panel4.setLayout(new BorderLayout());
		panel4.add(scrollPaneArea, BorderLayout.CENTER);
		winBug.setContentPane(panel4);
	}

	private void MriFilesWindow() {

		setLocationRelativeTo(null);
		// setExtendedState(JFrame.MAXIMIZED_BOTH);
		setTitle("MRI Files Manager (IRMaGe)");
		setSize(new Dimension(WScreen, HScreen));
		setResizable(true);
		setExtendedState(Frame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);

		JMenuBar menu_bar1 = new JMenuBar();

		JMenu file = new JMenu("File");
		JMenu openf = new JMenu("Open");
		JMenu exportf = new JMenu("export");
		JMenu inform = new JMenu("Information");
		JMenu pref = new JMenu("Preference");
		JMenu option = new JMenu("Option");
		JMenu tools = new JMenu("Tools");

		JMenuItem openBruker = new JMenuItem(new ActionsButtonMenu(this, "Open Bruker (PV5,PV6)"));
		openBruker.setIcon(PrefParam.iconBruker);
		JMenuItem openDicom = new JMenuItem(new ActionsButtonMenu(this, "Open Dicom"));
		openDicom.setIcon(PrefParam.iconDicom);
		JMenuItem openParRec = new JMenuItem(new ActionsButtonMenu(this, "Open Philips Archieva"));
		openParRec.setIcon(PrefParam.iconPhilips);
		JMenuItem openNifti = new JMenuItem(new ActionsButtonMenu(this, "Open NifTI"));
		openNifti.setIcon(PrefParam.iconNifTI);
		JMenuItem quit = new JMenuItem(new ActionsButtonMenu(this, "Quit"));

		JMenuItem optionExport = new JMenuItem(new ExportFiles(this, "Option export"));

		exportf.add(optionExport);

		JMenuItem help = new JMenuItem(new ActionsButtonMenu(this, "Help"));
		JMenuItem about = new JMenuItem(new ActionsButtonMenu(this, "About.."));
		JMenuItem bug = new JMenuItem(new ActionsButtonMenu(this, "Error window"));
		JMenuItem repwork = new JMenuItem(new ActionsButtonMenu(this, "Current working directory"));
		JMenu lookAfeel = new JMenu("Look and Feel");

		ButtonGroup group = new ButtonGroup();
		JCheckBoxMenuItem menuLaF;

		for (String lf : PrefParam.nameLookAndFeel) {
			menuLaF = new JCheckBoxMenuItem(lf);
			menuLaF.addItemListener(this);
			group.add(menuLaF);
			lookAfeel.add(menuLaF);
		}

		showicon = new JCheckBoxMenuItem("show icons in the file chooser dialog");
		showicon.setSelected(false);
		
		JMenuItem openImagej = new JMenuItem(new ActionsButtonMenu(this,"Open ImageJ"));

		file.add(openf);
		file.addSeparator();
		file.add(exportf);
		file.addSeparator();
		file.add(quit);
		inform.add(help);
		inform.add(about);
		openf.add(openBruker);
		// openf.add(openDicom);
		// openf.add(openParRec);
		openf.add(openNifti);
		pref.add(showicon);
		option.add(bug);
		option.add(repwork);
		option.add(lookAfeel);
		tools.add(openImagej);

		menu_bar1.add(file);
		menu_bar1.add(inform);
		menu_bar1.add(pref);
		menu_bar1.add(option);
		menu_bar1.add(tools);
		menu_bar1.add(Box.createHorizontalGlue());

		this.setJMenuBar(menu_bar1);

		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.setBackground(Color.LIGHT_GRAY);

		JPanel panelButton = new JPanel();

		JButton boutonBruker = new JButton(new ActionsButtonMenu(this, "Bruker"));
		JButton boutonDicom = new JButton(new ActionsButtonMenu(this, "Dicom"));
		JButton boutonParRec = new JButton(new ActionsButtonMenu(this, "Philips Archieva"));
		JButton boutonNifTI = new JButton(new ActionsButtonMenu(this, "NifTI"));
//		JButton boutonQuit = new JButton(new ActionsButtonMenu(this, "Quit"));

		boutonBruker.setIcon(PrefParam.iconBruker);
		boutonDicom.setIcon(PrefParam.iconDicom);
		boutonParRec.setIcon(PrefParam.iconPhilips);
		boutonNifTI.setIcon(PrefParam.iconNifTI);

		boutonBruker.setToolTipText("Paravision 5 & 6");
		boutonDicom.setToolTipText("<html>" + "Bruker PV5,PV6" + "<br>" + "Philips" + "<br>" + "Siemens" + "</html>");
		boutonParRec.setToolTipText("<html>" + "Par/Rec" + "<br>" + "Xml/Rec" + "</html>");
		boutonNifTI.setToolTipText("Nifti-1");
		
		boutonDicom.setEnabled(true);

		panelButton.add(boutonBruker);
		panelButton.add(boutonDicom);
		panelButton.add(boutonParRec);
		panelButton.add(boutonNifTI);

		listPath = new JComboBox<String>();
		listPath.addActionListener(new ActionsButtonMenu(this, "comboboxChanged"));
		// textPath.setMinimumSize(new Dimension(this.getWidth(),
		// boutonBruker.getHeight()));
		listPath.setPrototypeDisplayValue(
				"_______________________________history of repertories visited______________________________");
//		listPath.setForeground(Color.RED);
		listPath.setEnabled(true);
		listPath.setEditable(false);

		panelButton.add(listPath);
//		panelButton.add(boutonQuit, BorderLayout.EAST);

		tabData = new DataList(new Object[20][ParamMRI2.headerListData.length]).getTableData();
		tabData.setSelectionBackground(Color.ORANGE);
		tabData.setEnabled(false);
		tabData.addMouseListener(new ActionSelectionData(this, ""));
		tabData.addKeyListener(new ActionSelectionData(this, ""));
		treeData = new JScrollPane(tabData);

		JPanel panSeq = new JPanel();
		panSeq.setBackground(Color.WHITE);

		tabSeq = new SeqList(new Object[20][ParamMRI2.headerListSeq.length]).getTableSeq();
		tabSeq.setSelectionBackground(Color.ORANGE);
		tabSeq.getTableHeader().addMouseListener(new ActionSelectionSeq(this));
		tabSeq.setEnabled(false);
		tabSeq.addMouseListener(new ActionSelectionSeq(this));
		tabSeq.addKeyListener(new ActionSelectionSeq(this));
		tabSeq.getSelectionModel().addListSelectionListener(new ActionSelectionSeq(this));
		JScrollPane treeSeq = new JScrollPane(tabSeq);

		boxThumb = new Box(BoxLayout.Y_AXIS);
		boxThumb.setBackground(Color.WHITE);
		thumb = new JScrollPane(boxThumb);

		treeParamInfoGeneral = new TreeInfo2(ParamMRI2.listParamInfoSystem, null).getTreeInfo();
		for (int j = 0; j < treeParamInfoGeneral.getRowCount(); j++)
			treeParamInfoGeneral.expandRow(j);
		treeParamInfoUser = new TreeInfo2(ParamMRI2.listParamInfoUser, null).getTreeInfo();

		treeInfoGeneral = new JScrollPane(treeParamInfoGeneral);
		treeInfoUser = new JScrollPane(treeParamInfoUser);
		
		tabInfoParam.add("Info param.", treeInfoGeneral);
		tabInfoParam.add("User param.", treeInfoUser);

		JSeparator sep = new JSeparator(SwingConstants.HORIZONTAL);
		sep.setMaximumSize(new Dimension(10 * WScreen / 100, 4 * HScreen / 100));

		// JLabel labelPreview = new JLabel(" ",SwingConstants.LEFT);

		boxImage = new Box(BoxLayout.X_AXIS);
		// boxImage.setMinimumSize(new Dimension(250,200));
		// boxImage.setMaximumSize(new Dimension(200,200));
		// boxImage.setPreferredSize(new Dimension(220,200));
//		boxImage.setMaximumSize(new Dimension(20 * WScreen / 100, 25 * HScreen / 100));
		boxImage.add(new ImagePanel(null));

		slidImage1 = new JSlider();
		slidImage1.setValue(1);
		slidImage1.setMinimumSize(new Dimension(10 * WScreen / 100, 3 * HScreen / 100));
		slidImage1.setMaximumSize(new Dimension(10 * WScreen / 100, 3 * HScreen / 100));
		slidImage1.setEnabled(false);
		slidImage2 = new JSlider();
		slidImage2.setValue(1);
		slidImage2.setMinimumSize(new Dimension(10 * WScreen / 100, 3 * HScreen / 100));
		slidImage2.setMaximumSize(new Dimension(10 * WScreen / 100, 3 * HScreen / 100));
		slidImage2.setEnabled(false);
		slidImage3 = new JSlider();
		slidImage3.setValue(1);
		slidImage3.setMinimumSize(new Dimension(10 * WScreen / 100, 3 * HScreen / 100));
		slidImage3.setMaximumSize(new Dimension(10 * WScreen / 100, 3 * HScreen / 100));
		slidImage3.setEnabled(false);

		c = new JLabel();
		c.setMinimumSize(new Dimension(60 * WScreen / 100, 3 * HScreen / 100));
		c.setMaximumSize(new Dimension(60 * WScreen / 100, 3 * HScreen / 100));
		c.setText(" 0");

		z = new JLabel();
		z.setMinimumSize(new Dimension(60 * WScreen / 100, 3 * HScreen / 100));
		z.setMaximumSize(new Dimension(60 * WScreen / 100, 3 * HScreen / 100));
		z.setText(" 0");

		t = new JLabel();
		t.setMinimumSize(new Dimension(60 * WScreen / 100, 3 * HScreen / 100));
		t.setMaximumSize(new Dimension(60 * WScreen / 100, 3 * HScreen / 100));
		t.setText(" 0");

		JPanel panPreview = new JPanel();
		panPreview.setLayout(new BoxLayout(panPreview, BoxLayout.PAGE_AXIS));
		
		boxSlid1 = new Box(BoxLayout.X_AXIS);
		boxSlid2 = new Box(BoxLayout.X_AXIS);
		boxSlid3 = new Box(BoxLayout.X_AXIS);

		boxSlid1.add(slidImage1);
		boxSlid1.add(c);
		boxSlid2.add(slidImage2);
		boxSlid2.add(z);
		boxSlid3.add(slidImage3);
		boxSlid3.add(t);

		panPreview.add(boxImage, BorderLayout.CENTER);
		panPreview.add(boxSlid1,BorderLayout.CENTER);
		panPreview.add(boxSlid2,BorderLayout.CENTER);
		panPreview.add(boxSlid3,BorderLayout.CENTER);
		panPreview.setBorder(BorderFactory.createTitledBorder("Image Preview"));
		preview = new JScrollPane(panPreview);

		JPanel panCategory = new JPanel();
		panCategory.setBackground(Color.GRAY);
		JLabel labCat = new JLabel("Category list");
		panCategory.add(labCat);

		JPanel panGroupCategory = new JPanel();
		panGroupCategory.setBackground(Color.GRAY);
		JLabel labGoC = new JLabel("Group of category list");
		panGroupCategory.add(labGoC);

		WFrame = this.getWidth();
		HFrame = this.getHeight();

		split1 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true,treeData, tabInfoParam);
		split1.setDividerLocation(WFrame * 60 / 100);
		split1.setDividerSize(5);

		split2 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true,treeSeq, preview);
		split2.setDividerLocation(WFrame * 70 / 100);
		split2.setDividerSize(5);

		split3 = new JSplitPane(JSplitPane.VERTICAL_SPLIT, true,split1, split2);
		split3.setDividerLocation(HFrame * 60 / 100);
		split3.setDividerSize(5);

		split4 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true,thumb, split3);
		split4.setDividerLocation(WFrame * 10 / 100);
		split4.setDividerSize(10);

		panel.add(panelButton, BorderLayout.NORTH);
		panel.add(split4, BorderLayout.CENTER);

		tabPrincipal.add("Home", panel);
		
		getContentPane().add(tabPrincipal);
	}

	private void buildBasketWindow() {

		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();

		listOfBasket = new JList<>();
		// listinBasket.add(listinBasket.size()," empty ");
		// listOfBasket.setModel(listinBasket);
		// listOfBasket.setPreferredSize(new Dimension(350,800));
		JScrollPane scrollBasket = new JScrollPane(listOfBasket);
		scrollBasket.setPreferredSize(new Dimension(this.getWidth() - 100, this.getHeight() - 200));
		scrollBasket.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

		JPanel panelBasket = new JPanel();
		// panelBasket.setLayout(new BorderLayout());
		panelBasket.add(scrollBasket);

		JPanel buttonBasket = new JPanel();
		// buttonBasket.setLayout(new BorderLayout());

		JPanel panelRepNifti = new JPanel();
		pathExportNifti = new JLabel();
		if (PrefParam.FilestmpExportNifit != null)
			pathExportNifti.setText(PrefParam.FilestmpExportNifit.toString());
		JScrollPane scrollRepNifti = new JScrollPane(pathExportNifti);
		scrollRepNifti.setPreferredSize(new Dimension(40 * WScreen / 100, 3 * HScreen / 100));
		panelRepNifti.add(scrollRepNifti);
		JButton changeRepNifti = new JButton(new BasketManager(this, "Change"));
		panelRepNifti.add(changeRepNifti);

		JButton exportNifti = new JButton(new BasketManager(this, "export to NifTI-1"));
		JButton remove = new JButton(new BasketManager(this, "remove selection"));
		JButton removeAll = new JButton(new BasketManager(this, "remove all"));
		buttonBasket.add(exportNifti);
		buttonBasket.add(remove);
		buttonBasket.add(removeAll);

		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 1;
		c.weighty = 1;
		panel.add(panelBasket, c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 1;
		c.weighty = 0.1;
		panel.add(buttonBasket, c);
		c.fill = GridBagConstraints.HORIZONTAL;
		c.gridx = 0;
		c.gridy = 2;
		c.weighty = 1;
		panel.add(panelRepNifti, c);

		tabPrincipal.add("Basket (0)", panel);
	}
	
	private void buildProgress() {
		dlg = new JDialog(this, "Progress dialog ...", false);
		dlg.add(BorderLayout.NORTH, new JLabel("Export in progress, wait..."));
		dlg.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		dlg.setSize(300, 75);
		dlg.setLocationRelativeTo(this);

	}

	private void lookFeel() {
		
		try {
			UIManager.setLookAndFeel(PrefParam.LookFeelCurrent);
			SwingUtilities.updateComponentTreeUI(this);

		} catch (Exception e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
		}
		
	}
	
	private void buildDetailDisplaySeq() {

		popupMenuDetailSeq = new JPopupMenu();

		itemSeqDetail = new JCheckBoxMenuItem[ParamMRI2.headerListSeq.length];

		for (int i = 0; i < 5; i++) {
			itemSeqDetail[i] = new JCheckBoxMenuItem(ParamMRI2.headerListSeq[i]);
			if (i == 0)
				itemSeqDetail[i].setEnabled(false);
			itemSeqDetail[i].setSelected(true);
			itemSeqDetail[i].addActionListener(new ChangeDetailSeq(this, ""));
			popupMenuDetailSeq.add(itemSeqDetail[i]);
		}

		JMenuItem otherDetail = new JMenuItem("Other detail");
		otherDetail.addActionListener(new ChangeDetailSeq(this, "showdetail"));
		popupMenuDetailSeq.add(otherDetail);

		/*********************************************************************/
		frameDetailSeq = new JFrame("Detail Sequence");
		frameDetailSeq.setSize(300, 400);
		frameDetailSeq.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		frameDetailSeq.setLocationRelativeTo(this);
		frameDetailSeq.setAlwaysOnTop(true);
		// frameDetailSeq.addWindowListener(new WindowAdapter() {
		// public void windowClosing(WindowEvent evt) {
		// PrefParam.detailSeqShow=true;
		// }
		// });

		ls = new JCheckBox[ParamMRI2.headerListSeq.length];
		JPanel p = new JPanel();
		p.setSize(600, 400);
		p.setBackground(Color.WHITE);
		BoxLayout boxLayout = new BoxLayout(p, BoxLayout.Y_AXIS);
		p.setLayout(boxLayout);
		for (int i = 0; i < ParamMRI2.headerListSeq.length; i++) {
			ls[i] = new JCheckBox(ParamMRI2.headerListSeq[i]);
			if (i < 5)
				if (this.itemSeqDetail[i].isSelected())
					ls[i].setSelected(true);
				else
					ls[i].setSelected(false);
			if (i == 0)
				ls[i].setEnabled(false);
			else
				ls[i].setSelected(true);
			ls[i].addItemListener(new ChangeDetailSeq(this, ""));
			p.add(ls[i]);
		}

		JScrollPane scrollpane = new JScrollPane(p);
		frameDetailSeq.getContentPane().add(scrollpane, BorderLayout.CENTER);

	}

	/***************************** accesseurs ****************************/

	public JTable getTabData() {
		return tabData;
	}

	public JTable getTabSeq() {
		return tabSeq;
	}

	public JTree getTreeInfoGeneral() {
		return treeParamInfoGeneral;
	}
	
	public JTree getTreeInfoUser() {
		return treeParamInfoUser;
	}

//	public JScrollPane getScrollTreeInfoGeneral() {
//		return treeInfoGeneral;
//	}
	
//	public JScrollPane getScrollTreeInfoUser() {
//		return treeInfoUser;
//	}
	
	public JScrollPane getPreview() {
		return preview;
	}

	public JScrollPane getScrollThumb() {
		return thumb;
	}

	public JScrollPane getScrollTabData() {
		return treeData;
	}

	public JComboBox<String> getListPath() {
		return listPath;
	}

	public static JTextArea getBugText() {
		return textBug;
	}

	public JFrame getFenBug() {
		return winBug;
	}

	public Box getBoxImage() {
		return boxImage;
	}

	public JSlider[] getSlidImage() {
		JSlider[] listSlid = new JSlider[3];
		listSlid[0] = slidImage1;
		listSlid[1] = slidImage2;
		listSlid[2] = slidImage3;
		return listSlid;
	}

	public JLabel[] getFieldSlid() {
		JLabel[] listFieldSlid = new JLabel[3];
		listFieldSlid[0] = c;
		listFieldSlid[1] = z;
		listFieldSlid[2] = t;
		return listFieldSlid;
	}

	public Box getBoxThumb() {
		return boxThumb;
	}

	public JList<String> getListBasket() {
		return listOfBasket;
	}

	public JLabel getpathExportNifti() {
		return pathExportNifti;
	}

	public JDialog getFenProgress() {
		return dlg;
	}

	public JCheckBoxMenuItem getIconCheck() {
		return showicon;
	}

	public JFrame getFramDetailSeq() {
		return frameDetailSeq;
	}

	public JPopupMenu getMenuCheckDisplaySeq() {
		return popupMenuDetailSeq;
	}

	public JCheckBoxMenuItem[] getCheckDisplaySeq() {
		return itemSeqDetail;
	}

	public JCheckBox[] getCheckDisplaySeqinWindow() {
		return ls;
	}
	
	public JTabbedPane getTabbedPrincipal() {
		return tabPrincipal;
	}

	public JTabbedPane getTabbedPane() {
		return tabPrincipal;
	}

	public JTable getDictionnaryJTable() {
		return tabDictionnaryMri;
	}

	public JTextField[] getTextFieldManagingDiction() {
		return textFieldManagingDiction;
	}
	
	public JButton getButtonAddDiction() {
		return buttonRec;
	}

	public JLabel getPathDictionary() {
		return pathDictionnary;
	}

	public JCheckBox getCheckJsonManagingDiction() {
		return chJson;
	}

	/***************************** reset ****************************/

	public void resetTabSeq() {
		// getTabSeq().setEnabled(true);
		TableModel model20;
		Object[][] data = { { "", "", "", "", "", "", "", "", "", "", "" } };
		String[] columnNames = ParamMRI2.headerListSeq;
		model20 = new TableModel(data, columnNames);
		TableRowSorter<TableModel> sorter0 = new TableRowSorter<TableModel>(model20);
		tabSeq.setModel(model20);
		tabSeq.setRowSorter(sorter0);
		new ChangeDetailSeq(this);
		tabSeq.setEnabled(false);
	}

	public int[] widthColumnJtable(JTable tab) {
		int nb = tab.getColumnCount();
		int[] listW = new int[nb];
		for (int i = 0; i < nb; i++) {
			listW[i] = tab.getColumnModel().getColumn(i).getWidth();
		}
		return listW;
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		JCheckBoxMenuItem check = (JCheckBoxMenuItem) e.getSource();
		if (check.isSelected()) {
			try {
				for (int i = 0; i < PrefParam.nameLookAndFeel.length; i++) {
					if (PrefParam.nameLookAndFeel[i].contains(check.getText())) {
						UIManager.setLookAndFeel(PrefParam.urlLookAndFeel[i]);
						PrefParam.LookFeelCurrent = PrefParam.urlLookAndFeel[i];
						break;
					}
				}
				SwingUtilities.updateComponentTreeUI(this);
			} catch (Exception e1) {
			}
			
			new PrefParamModif("[LookAndFeel]", PrefParam.LookFeelCurrent);
		}
	}
}