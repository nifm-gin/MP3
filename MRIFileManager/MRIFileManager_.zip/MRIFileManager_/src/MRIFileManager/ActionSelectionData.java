package MRIFileManager;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.SwingUtilities;

import AbstractClass.Format;
import AbstractClass.PrefParam;
import AbstractClass.SelectionData;
import BrukerParavision.SelectionDataBruker;
import Dicom.SelectionDataDicom;
import Nifti.SelectionDataNifti;
import Philips.SelectionDataPhilips;

public class ActionSelectionData extends PrefParam implements MouseListener, KeyListener, Format {

	private FileManagerFrame wind;
	private SelectionData seledata;

	public ActionSelectionData(FileManagerFrame wind, String command) {
		this.wind = wind;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		JTable target = (JTable) e.getSource();

		if (SwingUtilities.isLeftMouseButton(e) && !e.getSource().toString().contains("JTableHeader")
				&& wind.getTabData().isEnabled()) {
			goSelectionData();
		}

		if (SwingUtilities.isRightMouseButton(e) && !e.getSource().toString().contains("JTableHeader")
				&& wind.getTabData().isEnabled() && target.getSelectedRow() == target.rowAtPoint(e.getPoint())) {
			JPopupMenu popmenu = new JPopupMenu();
			if (formatCurrent.contains("Bruker"))
				try {
					seledata.popMenuData(popmenu);
				} catch (Exception e1) {
					wind.setCursor(null);
				}

			popmenu.show(e.getComponent(), e.getX(), e.getY());
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_UP
				|| e.getKeyCode() == KeyEvent.VK_ENTER)
			goSelectionData();
	}

	@Override
	public void keyTyped(KeyEvent e) {
	}

	private void goSelectionData() {

		try {
			switch (formatCurrentInt) {
			case Bruker:
				seledata = new SelectionDataBruker(wind);
				break;
			case Philips:
				seledata = new SelectionDataPhilips(wind);
				break;
			case Dicom:
				seledata = new SelectionDataDicom(wind); 
				break;
			case Nifti:
				seledata = new SelectionDataNifti(wind);
				break;
			default:
				break;
			}

		} catch (Exception e1) {
			wind.setCursor(null);
		}
		seledata.goSelectionData(wind);
	}
}