package MRIFileManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.StringReader;

import AbstractClass.PrefParam;

public class PrefParamLoad extends PrefParam {

	public PrefParamLoad() {

		// lectBruker = new JFileChooser().getCurrentDirectory().toString();
		lectBruker = UtilsSystem.pathOfJar();
		lectDicom = lectBruker;
		lectParRec = lectBruker;
		lectNifTI = lectBruker;
		namingNiftiExport = "PatientName-StudyName-CreationDate-SeqNumber-Protocol-SequenceName";
		pathDictionaryUser = "";

		new UtilsSystem();
		FilestmpRep = new File(UtilsSystem.pathOfJar() + separator + "FilestmpRep.txt");

		String txt = "";

		if (FilestmpRep.exists()) {
			txt = new ExtractTxtfromFile(FilestmpRep.toString()).getTxt();

			try {
				BufferedReader bg = new BufferedReader(new StringReader(txt));
				String tmp = "";
				while ((tmp = bg.readLine()) != null) {
					if (tmp.contains("[Bruker]"))
						lectBruker = tmp.substring(9);
					if (tmp.contains("[Dicom]"))
						lectDicom = tmp.substring(8);
					if (tmp.contains("[ParRec]"))
						lectParRec = tmp.substring(9);
					if (tmp.contains("[NifTI]"))
						lectNifTI = tmp.substring(8);
					if (tmp.contains("[NamingNifTI]"))
						namingNiftiExport = tmp.substring(14);
					if (tmp.contains("[LookAndFeel]"))
						LookFeelCurrent = tmp.substring(14);
					if (tmp.contains("[DictionaryUser]"))
						pathDictionaryUser = tmp.substring(17);
				}
			} catch (Exception e) {
				new GetStackTrace(e);
				FileManagerFrame.getBugText().setText(GetStackTrace.getMessage());
			}

			if (!new File(lectBruker).exists())
				lectBruker = "";
			if (!new File(lectDicom).exists())
				lectDicom = "";
			if (!new File(lectParRec).exists())
				lectParRec = "";
			if (!new File(lectNifTI).exists())
				lectNifTI = "";
			if (!new File(pathDictionaryUser).exists())
				pathDictionaryUser = "";
		}
		
		else {
			txt = "[Bruker] " + lectBruker + "\n" + "[Dicom] " + lectDicom + "\n"
			+ "[ParRec] " + lectParRec + "\n" + "[NifTI] " + lectNifTI + "\n"
			+ "[LookAndFeel] " + LookFeelCurrent + "\n" 
			+ "[NamingNifTI] " +"PatientName-StudyName-CreationDate-SeqNumber-Protocol-SequenceName"+"\n"
			+ "[DictionaryUser] "+ pathDictionaryUser+"\n";
		}
	}
}