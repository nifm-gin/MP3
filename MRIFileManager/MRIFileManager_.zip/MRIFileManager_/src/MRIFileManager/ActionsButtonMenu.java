package MRIFileManager;

import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Locale;

import javax.swing.AbstractAction;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileView;
import javax.swing.table.TableRowSorter;

import AbstractClass.Format;
import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;
import BrukerParavision.BrukerFileView;
import BrukerParavision.TableBrukerData;
import Dicom.TableDicomData;
import Nifti.NiftiFileView;
import Nifti.TableNiftiData;
import Philips.PhilipsFileView;
import Philips.TablePhilipsData;

class ActionsButtonMenu extends AbstractAction implements ParamMRI2, Format {

	private static final long serialVersionUID = 1L;
	private FileManagerFrame wind;
	private String dialogTitle;
	private String repselected = null;
	private FileView view;

	public ActionsButtonMenu(FileManagerFrame wind, String command) {
		super(command);
		this.wind = wind;
	}

	@Override
	public void actionPerformed(ActionEvent evt) {

		String cmd = evt.getActionCommand().toString();

		/*****************************************************************************************************************/
		/* button Quit action */

		if (cmd.contains("Quit"))
			quit();
		if (cmd.contains("comboBoxChanged")) {
			comboBoxChanged();
		}
		if (cmd.contains("Help"))
			;
		if (cmd.contains("About"))
			;
		if (cmd.contains("Error window"))
			wind.getFenBug().setVisible(true);
		if (cmd.contains("Detailed file window"))
			;
		if (cmd.contains("Current working directory"))
			new WindowRepSelection();

		if (cmd.contains("Open ImageJ"))
			new OpenImageJ();

		if (cmd.contains("Bruker")) {
			dialogTitle = "Choose Bruker Data";
			PrefParam.formatCurrent = "[Bruker]    ";
			PrefParam.formatCurrentInt = 0;
			PrefParam.lectCurrent = PrefParam.lectBruker;
			view = new BrukerFileView();
			selectDirData();
		}
		if (cmd.contains("Dicom")) {
			dialogTitle = "Choose Dicom Data";
			PrefParam.formatCurrent = "[Dicom]     ";
			PrefParam.formatCurrentInt = 1;
			PrefParam.lectCurrent = PrefParam.lectDicom;
//			view = new DicomFileView();
			selectDirData();
		}
		if (cmd.contains("Philips Archieva")) {
			dialogTitle = "Choose Philips Data";
			PrefParam.formatCurrent = "[Philips]   ";
			PrefParam.formatCurrentInt = 2;
			PrefParam.lectCurrent = PrefParam.lectParRec;
			view = new PhilipsFileView();
			selectDirData();
		}
		if (cmd.contains("NifTI")) {
			dialogTitle = "Choose Nifti Data";
			PrefParam.formatCurrent = "[Nifti]     ";
			PrefParam.formatCurrentInt = 3;
			PrefParam.lectCurrent = PrefParam.lectNifTI;
			view = new NiftiFileView();
			selectDirData();
		}
		// if (cmd.contains("GTK") || cmd.contains("Nimbus"))
		// {changeLookAndFeel();}
		/*****************************************************************************************************************/
		/* button Directory action */

	}

	private void quit() {
		System.exit(0);
	}

	private void selectDirData() {

		final JFileChooser rep = new JFileChooser();
		rep.setAcceptAllFileFilterUsed(false);
		rep.setApproveButtonText("Select this directory");
		rep.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		rep.setLocale(Locale.ENGLISH);
		rep.setDialogTitle(dialogTitle);
		rep.setCurrentDirectory(new File(PrefParam.lectCurrent));
		if (wind.getIconCheck().getState())
			rep.setFileView(view);
		rep.updateUI();
		rep.addMouseListener(new MouseListener() {

			@Override
			public void mouseReleased(MouseEvent e) {
			}

			@Override
			public void mousePressed(MouseEvent e) {
			}

			@Override
			public void mouseExited(MouseEvent e) {
			}

			@Override
			public void mouseEntered(MouseEvent e) {
			}

			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2) {
					File file = rep.getSelectedFile();
					if (file.isDirectory())
						rep.approveSelection();
					else {
						rep.setCurrentDirectory(file);
						rep.rescanCurrentDirectory();
					}
				}
			}
		});

		switch (rep.showOpenDialog(wind)) {

		case JFileChooser.APPROVE_OPTION:
			repselected = rep.getSelectedFile().getPath();

			if (!rep.getSelectedFile().isDirectory())
				repselected = repselected.substring(0, repselected.lastIndexOf(PrefParam.separator));
			else if (repselected.substring(repselected.length() - 1).contentEquals(PrefParam.separator))
				repselected = repselected.substring(0, repselected.length() - 1);
			fillListPath();
			break;
		}
		rep.setSelectedFile(null);
	}

	private void comboBoxChanged() {
		wind.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
		hmSeq.clear();
		hmInfo.clear();
		hmOrderImage.clear();
		hmData.clear();
		dictionaryMRISystem.clear();
		dictionaryMRIUser.clear();
		listParamInfoSystem.clear();
		listParamInfoUser.clear();
		wind.resetTabSeq();
		wind.getBoxThumb().removeAll();
		wind.getBoxThumb().updateUI();
		wind.getBoxImage().removeAll();
		wind.getBoxImage().updateUI();

		repselected = wind.getListPath().getSelectedItem().toString().substring(12);
		PrefParam.formatCurrent = wind.getListPath().getSelectedItem().toString().substring(0, 12);
		String tmp = PrefParam.formatCurrent;
		tmp = tmp.substring(tmp.indexOf("[") + 1, tmp.indexOf("]"));
		PrefParam.formatCurrentInt = format.valueOf(tmp).toInt();

		Object[][] data = null;

		switch (PrefParam.formatCurrentInt) {
		case Bruker:
			new DictionaryYaml(PrefParam.formatCurrentInt, UtilsSystem.pathOfJar()+PrefParam.separator+"DictionaryMRI_Bruker_System.yml").loadDictionarySystem();
			new DictionaryYaml(PrefParam.formatCurrentInt, UtilsSystem.pathOfJar()+PrefParam.separator+"DictionaryMRI_Bruker_User.yml").loadDictionaryUser();

			try {
				data = new TableBrukerData(repselected).getData();
			} catch (IOException e) {
				new GetStackTrace(e);
				FileManagerFrame.getBugText().setText(
						FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
			}
			break;

		case Philips:
			new DictionaryYaml(PrefParam.formatCurrentInt, UtilsSystem.pathOfJar()+PrefParam.separator+"DictionaryMRI_Philips_System.yml").loadDictionarySystem();
			new DictionaryYaml(PrefParam.formatCurrentInt, UtilsSystem.pathOfJar()+PrefParam.separator+"DictionaryMRI_Philips_User.yml").loadDictionaryUser();

			try {
				data = new TablePhilipsData(repselected).getData();
			} catch (IOException e) {
				new GetStackTrace(e);
				FileManagerFrame.getBugText().setText(
						FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
			}

			break;
		
		case Dicom:
			new DictionaryYaml(PrefParam.formatCurrentInt, UtilsSystem.pathOfJar()+PrefParam.separator+"DictionaryMRI_Dicom_System.yml").loadDictionarySystem();

			try {
				data = new TableDicomData(repselected).getData();
			} catch (IOException e) {
				new GetStackTrace(e);
				FileManagerFrame.getBugText().setText(
						FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
			}
			
			break;
		case Nifti:
			new DictionaryYaml(PrefParam.formatCurrentInt, UtilsSystem.pathOfJar()+PrefParam.separator+"DictionaryMRI_Nifti_System.yml").loadDictionarySystem();
			new DictionaryYaml(PrefParam.formatCurrentInt, UtilsSystem.pathOfJar()+PrefParam.separator+"DictionaryMRI_Nifti_User.yml").loadDictionaryUser();

			try {
				data = new TableNiftiData(repselected).getData();
			} catch (IOException e) {
				new GetStackTrace(e);
				FileManagerFrame.getBugText().setText(
						FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
			}
			break;

		default:
			break;
		}

		TableModel model = new TableModel(data, headerListData);
		TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(model);

		wind.getTabData().removeAll();
		wind.getTabData().updateUI();
		wind.getTabData().setModel(model);
		wind.getTabData().setRowSorter(sorter);
		wind.getTabData().setEnabled(true);
		wind.getTabData().getRowSorter().toggleSortOrder(4);

		wind.getBoxImage().removeAll();
		wind.getBoxImage().add(new ImagePanel(null));
		wind.getBoxImage().updateUI();
		wind.getBoxThumb().removeAll();
		wind.getBoxThumb().updateUI();
		wind.getScrollThumb().updateUI();

		for (int i = 0; i < wind.getSlidImage().length; i++) {
			wind.getSlidImage()[i].setEnabled(false);
			wind.getSlidImage()[i].removeAll();
			wind.getFieldSlid()[i].setText(" 0");
		}

		wind.getPreview().updateUI();

		wind.getTreeInfoGeneral().setModel(new TreeInfo2(ParamMRI2.listParamInfoSystem, null).getTreeInfo().getModel());
		for (int j = 0; j < wind.getTreeInfoGeneral().getRowCount(); j++)
			wind.getTreeInfoGeneral().expandRow(j);

		wind.getTreeInfoUser().setModel(new TreeInfo2(ParamMRI2.listParamInfoUser, null).getTreeInfo().getModel());
		for (int j = 0; j < wind.getTreeInfoUser().getRowCount(); j++)
			wind.getTreeInfoUser().expandRow(j);

		wind.setCursor(null);
	}

	private void fillListPath() {

		File tmpfile = new File(repselected);

		switch (PrefParam.formatCurrentInt) {
		case Bruker:
			FilenameFilter filterSubject = new FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					if (name.contains("subject"))
						return true;
					return false;
				}
			};
			if (tmpfile.list(filterSubject).length != 0)
				repselected = repselected.substring(0, repselected.lastIndexOf(PrefParam.separator));
			PrefParam.lectBruker = repselected;
			break;
			
		case Dicom:
			FilenameFilter filterDicom = new FilenameFilter() {
				public boolean accept(File dir, String name) {
					 if(name.contains("DICOMDIR") || name.contains("DIRFILE"))
				           return true;
				               return false;
				}
			};
			if (tmpfile.list(filterDicom).length!=0) 
				repselected=repselected.substring(0,repselected.lastIndexOf(PrefParam.separator));
			PrefParam.lectDicom = repselected;
			break;

		case Philips:
			FilenameFilter filterParRec = new FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					if (name.endsWith(".REC"))
						return true;
					return false;
				}
			};
			if (tmpfile.list(filterParRec).length != 0)
				repselected = repselected.substring(0, repselected.lastIndexOf(PrefParam.separator));
			PrefParam.lectParRec = repselected;
			break;
		
		case Nifti:
			FilenameFilter filterNifTI = new FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					if (name.endsWith(".nii"))
						return true;
					return false;
				}
			};
			if (tmpfile.list(filterNifTI).length != 0)
				repselected = repselected.substring(0, repselected.lastIndexOf(PrefParam.separator));
			PrefParam.lectNifTI = repselected;
			break;

		}

		if (wind.getListPath().getItemCount() != 0) {
			boolean isYet = false;
			int ing = 0;
			for (int g = 0; g < wind.getListPath().getItemCount(); g++)
				if (wind.getListPath().getItemAt(g).equals(PrefParam.formatCurrent + repselected)) {
					isYet = true;
					ing = g;
					break;
				}
			if (!isYet) {
				wind.getListPath().insertItemAt(PrefParam.formatCurrent + repselected, 0);
				wind.getListPath().setSelectedIndex(0);
			} else
				wind.getListPath().setSelectedIndex(ing);
		} else {
			wind.getListPath().addItem(PrefParam.formatCurrent + repselected);
		}
	}
}