package MRIFileManager;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.StringReader;

import AbstractClass.PrefParam;

public class PrefParamModif extends PrefParam {

	public PrefParamModif(String key,String newVal) {

		String txt = "";

		if (FilestmpRep.exists()) {
			txt = new ExtractTxtfromFile(FilestmpRep.toString()).getTxt();

			try {
				BufferedReader bg = new BufferedReader(new StringReader(txt));
				String tmp = "";
				while ((tmp = bg.readLine()) != null) {
					if (tmp.contains(key))
						txt = txt.replace(tmp,key+" "+newVal);
				}
			} catch (Exception e) {
				new GetStackTrace(e);
				FileManagerFrame.getBugText().setText(GetStackTrace.getMessage());
			}
		}
		
		else {
			txt = "[Bruker] " + lectBruker + "\n" + "[Dicom] " + lectDicom + "\n"
			+ "[ParRec] " + lectParRec + "\n" + "[NifTI] " + lectNifTI + "\n"
			+ "[LookAndFeel] " + LookFeelCurrent + "\n" 
			+ "[NamingNifTI] " +"PatientName-StudyName-CreationDate-SeqNumber-Protocol-SequenceName"+"\n"
			+ "[DictionaryUser] "+ pathDictionaryUser+"\n";
		}
			try {				
				FileWriter printRep = new FileWriter(FilestmpRep);
				printRep.write(txt);
				printRep.close();
			} catch (Exception e1) {
				new GetStackTrace(e1);
				FileManagerFrame.getBugText().setText(FileManagerFrame.getBugText().getText()+"\n----------------\n"+GetStackTrace.getMessage());
			}
		
	}
}