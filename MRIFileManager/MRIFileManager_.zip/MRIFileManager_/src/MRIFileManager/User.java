package MRIFileManager;
import java.util.HashMap;

public class User {

	private HashMap<String, HashMap<String, HashMap<String , String>>> dictionaryMRI;

	public HashMap<String, HashMap<String, HashMap<String , String>>> getDictionaryMRI() {
		return dictionaryMRI;
	}

	public void setDictionaryMRI(HashMap<String, HashMap<String, HashMap<String , String>>> dictionaryMRI) {
		this.dictionaryMRI = dictionaryMRI;
	}

}