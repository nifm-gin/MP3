package BrukerParavision;

import java.io.IOException;
import java.util.List;

import AbstractClass.ParamMRI2;

public class TableBrukerSequence implements ParamMRI2 {
	
	private Object[][] data;
	
	public TableBrukerSequence(String repertory) throws IOException{
		
		List<String> list2dseq = new Search2dseq(repertory).getList2dseq();
		
		if (!list2dseq.isEmpty()) {
			
			data = new Object[list2dseq.size()][headerListSeq.length];
			for (int i=0;i<data[0].length;i++)
				data[0][i]="";
			data[0][0]="no Bruker sequence found";
			
			for (int i=0; i<data.length;i++) {
				data[i] = new ListBrukerSequence(list2dseq.get(i)).ListSeqBruker();
				
			}
		}
		else {
			data = new Object[1][headerListSeq.length];
			for (int i=0;i<data[0].length;i++)
				data[0][i]="";
			data[0][0]="no Bruker sequence found";
		}
	}
	
	public Object[][] getSequence() {
		return data;
	}
}