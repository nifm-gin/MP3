package BrukerParavision;

import java.io.File;

import AbstractClass.PrefParam;
import MRIFileManager.ExtractTxtfromFile;

public class ConcatenatFileBruker extends PrefParam {
	
	private String chemAcqp, chemMethod, chemVisupars, chemReco, chemSubject;
	private String txtCont;
	
	public ConcatenatFileBruker(String chemSeq) {
		
		chemAcqp = chemSeq.substring(0, chemSeq.indexOf("pdata") - 1) + separator + "acqp";
		chemMethod = chemSeq.substring(0, chemSeq.indexOf("pdata") - 1) + separator + "method";
		chemVisupars = chemSeq.substring(0, chemSeq.indexOf("2dseq") - 1) + separator + "visu_pars";
		chemReco = chemSeq.substring(0, chemSeq.indexOf("2dseq") - 1) + separator + "reco";
		chemSubject = chemSeq;
		for (int i=0;i<4;i++)
			chemSubject = chemSubject.substring(0, chemSubject.lastIndexOf(separator));
		chemSubject+=separator+"subject";
		if (!new File(chemReco).exists()) {
			chemReco = chemReco.substring(0, chemReco.lastIndexOf(PrefParam.separator));
			chemReco = chemReco.substring(0, chemReco.lastIndexOf(PrefParam.separator) + 1) + "1" + separator + "reco";
		}
		
		txtCont=new ExtractTxtfromFile(chemSubject).getTxt()+"\n"+
				new ExtractTxtfromFile(chemAcqp).getTxt()+"\n"+
				new ExtractTxtfromFile(chemVisupars).getTxt()+"\n"+
				new ExtractTxtfromFile(chemReco).getTxt()+"\n"+
				new ExtractTxtfromFile(chemMethod).getTxt();
		
	}
	
	public String getTxtCont() {
		return txtCont;
	}
}