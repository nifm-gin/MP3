package BrukerParavision;

import AbstractClass.ParamMRI2;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;

public class FillHmsBruker implements ParamMRI2 {

	public FillHmsBruker(String seqSel) {

		String dim, nImage;

		try {
			ListBrukerParam2 listBrukPar = new ListBrukerParam2(hmSeq.get(seqSel)[0], seqSel);
			hmInfo.put(seqSel, listBrukPar.ListParamValue());
//			for (String pp : hmInfo.keySet())
//				System.out.println(pp+" : "+hmInfo.get(pp));
			dim = hmInfo.get(seqSel).get("Scan Mode");
			if (dim.contains("3"))
				nImage = hmInfo.get(seqSel).get("Scan Resolution").split(" +")[2];
			else
				nImage = hmInfo.get(seqSel).get("Images In Acquisition");
			hmOrderImage.put(seqSel, listBrukPar.ListOrderStack(dim, nImage));

		} catch (Exception e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
		}
	}
}