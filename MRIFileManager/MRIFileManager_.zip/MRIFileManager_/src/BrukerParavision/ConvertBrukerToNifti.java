package BrukerParavision;

import AbstractClass.ParamMRI2;
import AbstractClass.convertNifti;
import ij.ImagePlus;

public class ConvertBrukerToNifti extends convertNifti implements ParamMRI2 {

	private AffineQuaternionBruker bts;

	@Override
	public ImagePlus convertToNifti(String lb) {
		return new OpenBruker2(listBasket_hms.get(lb).get("noSeq"), false, true, lb).getImp();
	}

	@Override
	public void AffineQuaternion(String lb) {
		bts = new AffineQuaternionBruker(listBasket_hms.get(lb).get("File path"));
	}

	@Override
	public double[][] srow() {
		return bts.getMat();
	}

	@Override
	public double[] quaterns() {
		return bts.getQuatern();
	}
}