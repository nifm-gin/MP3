package BrukerParavision;

import java.io.IOException;
import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;
import MRIFileManager.ExtractTxtfromFile;
import MRIFileManager.Timeformatmodif;

public class ListBrukerSequence extends PrefParam implements ParamMRI2 {

	private String[] listParamSeq = headerListSeq;
	private String chemSeq;

	public ListBrukerSequence(String chemSeq) {

		this.chemSeq = chemSeq;

	}

	public Object[] ListSeqBruker() throws IOException {

		String[] hmValue = new String[2];
		hmValue[0] = chemSeq.replace("*", "");
		hmValue[1] = "";

		String noSeq = chemSeq.substring(0, chemSeq.indexOf("pdata") - 1);
		noSeq = noSeq.substring(noSeq.lastIndexOf(separator) + 1);

		String noReco = chemSeq.substring(chemSeq.indexOf("pdata") + 6);
		noReco = noReco.substring(0, noReco.lastIndexOf(separator));

		Object[] resul = new String[listParamSeq.length];
		if (Integer.parseInt(noSeq) < 10)
			noSeq = "0" + noSeq;
		resul[0] = noSeq;
		if (chemSeq.contains("*"))
			resul[0] += "-" + noReco;

		/**********************
		 * Hashmap hm add
		 *******************************************************/

		hmSeq.put(resul[0].toString(), hmValue);
		new FillHmsBruker(resul[0].toString());

		for (int i = 1; i < resul.length; i++) {
			resul[i] = hmInfo.get(resul[0].toString()).get(listParamSeq[i]);
		}

		String txtParam = new ExtractTxtfromFile(
				chemSeq.substring(0, chemSeq.indexOf("2dseq") - 1) + separator + "visu_pars").getTxt();

		String tmp = new SearchParamBruker("##$VisuSeriesComment", txtParam).result();
		if (!tmp.isEmpty()) {
			tmp = tmp.replaceAll("<", "");
			tmp = tmp.replaceAll(">", "");
			resul[1] = tmp;
		}
		/**********************
		 * Format modification
		 *******************************************************/
		try {
			resul[3] = new Timeformatmodif(resul[3].toString(), "ms").newformtime();
		} catch (Exception e) {
			// resul[2]="";
		}
		resul[4] = new Dateformatmodif(resul[4].toString()).newformdate();
		resul[5] = resul[5] + "D";

		return resul;
	}
}