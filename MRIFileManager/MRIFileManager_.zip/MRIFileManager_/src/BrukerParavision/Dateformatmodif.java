package BrukerParavision;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Dateformatmodif {

	private String rdate="";
	
	public Dateformatmodif (String rdate){
		this.rdate=rdate;
	}

	public String newformdate () {
		
		if (!rdate.contains("T")) {
			rdate=rdate.replace("Jan", "01");
	        rdate=rdate.replace("Feb", "02");
	        rdate=rdate.replace("Mar", "03");
	        rdate=rdate.replace("Apr", "04");
	        rdate=rdate.replace("May", "05");
	        rdate=rdate.replace("Jun", "06");
	        rdate=rdate.replace("Jul", "07");
	        rdate=rdate.replace("Aug", "08");
	        rdate=rdate.replace("Sep", "09");
	        rdate=rdate.replace("Oct", "10");
	        rdate=rdate.replace("Nov", "11");
	        rdate=rdate.replace("Dec", "12");
	    	
	    	try {
	    	SimpleDateFormat sdfSource1 = new SimpleDateFormat(
	                "HH:mm:ss dd MM yyyy");

	        // parse the string into Date object
	         Date date1 = sdfSource1.parse(rdate);

	        // create SimpleDateFormat object with desired date format
	        SimpleDateFormat sdfDestination = new SimpleDateFormat(
	                "yyyy-MM-dd_HH-mm-ss");

	        // parse the date into another format
	        rdate = sdfDestination.format(date1);
	    	}catch (Exception e) {
	    		
	    	}
	    	}
	    	
	    	else if (rdate.contains("T")) {
	    		try {
	    	    	SimpleDateFormat sdfSource1 = new SimpleDateFormat(
	    	                "yyyy-MM-dd'T'HH:mm:ss','SSSZZZZ");

	    	        // parse the string into Date object
	    	         Date date1 = sdfSource1.parse(rdate);

	    	        // create SimpleDateFormat object with desired date format
	    	        SimpleDateFormat sdfDestination = new SimpleDateFormat(
	    	                "yyyy-MM-dd_HH-mm-ss");

	    	        // parse the date into another format
	    	        rdate = sdfDestination.format(date1);
	    	    	}catch (Exception e) {
	   	    	}
	    	}
		return rdate;
	}
}