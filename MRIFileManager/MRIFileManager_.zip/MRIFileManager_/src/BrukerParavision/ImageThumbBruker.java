package BrukerParavision;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.net.URL;

import javax.swing.ImageIcon;

import AbstractClass.ImageThumb;
import AbstractClass.ParamMRI2;
import ij.ImagePlus;
import ij.gui.ProfilePlot;
import ij.io.FileInfo;
import ij.io.FileOpener;

public class ImageThumbBruker extends ImageThumb implements ParamMRI2 {

	private Image img;
	private ImagePlus imp;
	private ProfilePlot profPlot;

	private URL imgURL = getClass().getResource("/WhiteScreen.jpg");

	@Override
	public Image ImageThumbShow(String noSeq) {

		String sliceOrientation = hmInfo.get(noSeq).get("Slice Orientation");
		String readDirection = hmInfo.get(noSeq).get("Read Direction");

		String[] listParamToFind = { "Scan Resolution", "Images In Acquisition", "Byte Order", "Data Type"};
		String[] values = new String[listParamToFind.length];

		values[0] = hmInfo.get(noSeq).get(listParamToFind[0]);

		for (int i = 1; i < values.length; i++) {
			values[i] = hmInfo.get(noSeq).get(listParamToFind[i]);
			if (values[i] == "") {
				img = new ImageIcon(imgURL).getImage();
				return img;
			}
		}

		String type;// byteOrder;
		int w = Integer.parseInt(values[0].split(" +")[0]);
		int h;
		if (values[0].split(" +").length == 1)
			h = 1;
		else
			h = Integer.parseInt(values[0].split(" +")[1]);
		int nImage;
		int tmp;

		if ((sliceOrientation.contentEquals("coronal") && readDirection.contentEquals("H_F"))
				|| (sliceOrientation.contentEquals("sagittal") && readDirection.contentEquals("H_F"))
				|| (sliceOrientation.contentEquals("axial") && readDirection.contentEquals("A_P"))) {
			tmp = w;
			w = h;
			h = tmp;
		}

		if (values[0].split(" +").length > 2)
			nImage = Integer.parseInt(values[0].split(" +")[2]);
		else
			nImage = Integer.parseInt(values[1]);

		type = values[3];

		Float f = new Float(nImage);
		int intValue = f.intValue();

		intValue = intValue / 2;

		int mult = 1;

		FileInfo fi = new FileInfo();

		if (type.contains("_16BIT_SGN_INT")) {
			fi.fileType = FileInfo.GRAY16_SIGNED;
			mult = 2;
		} else if (type.contains("_32BIT_SGN_INT")) {
			fi.fileType = FileInfo.GRAY32_INT;
			mult = 4;
		} else {
			fi.fileType = FileInfo.GRAY8;
		}

		int off = w * h * intValue * mult;

		fi.fileFormat = FileInfo.RAW;
		fi.fileName = hmInfo.get(noSeq).get("File path");
		fi.width = w;
		fi.height = h;
		fi.offset = off;
		fi.nImages = 1;
		if (values[2].contains("littleEndian"))
			fi.intelByteOrder = true;
		else
			fi.intelByteOrder = false;
		fi.gapBetweenImages = 0;

		FileOpener fo = new FileOpener(fi);

		imp = fo.open(false);
		imp.resetDisplayRange();

		if (imp != null) {
			if (imp.getHeight() != 1)
				img = imp.getImage();
			else {
				imp.setRoi(0, 0, imp.getWidth(), 1);
				profPlot = new ProfilePlot(imp);
				img = profPlot.getPlot().getImagePlus().getImage();
			}
			img = getScaledImage(img, 120, 120);
		}
		return img;
	}

	private Image getScaledImage(Image srcImg, int w, int h) {
		BufferedImage resizedImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g2 = resizedImg.createGraphics();

		g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g2.drawImage(srcImg, 0, 0, w, h, null);
		g2.dispose();

		return resizedImg;
	}
}