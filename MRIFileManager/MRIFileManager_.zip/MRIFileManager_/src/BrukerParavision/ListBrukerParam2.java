package BrukerParavision;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;

import AbstractClass.ListParam2;
import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;

public class ListBrukerParam2 extends PrefParam implements ParamMRI2, ListParam2 {

	private String chem2dseq, chemVisupars, seqSel;

	public ListBrukerParam2(String chem2dseq, String seqSel) {
		this.chem2dseq = chem2dseq;
		this.seqSel=seqSel;
		chemVisupars = chem2dseq.substring(0, chem2dseq.indexOf("2dseq") - 1) + separator + "visu_pars";
	}

	@Override
	public HashMap<String, String> ListParamValue() throws IOException {
		HashMap<String, String> lv = new HashMap<String, String>();
		String txtParam = new ConcatenatFileBruker(chem2dseq).getTxtCont();
		File file2dseq = new File(chem2dseq);
		lv.put("noSeq",	seqSel);
		lv.put("File path",file2dseq.getAbsolutePath());
		lv.put("File Name",file2dseq.getName());
		lv.put("File Size (Mo)",String.valueOf(file2dseq.length() / (1024 * 1024.0)));
		
		for (String sg : dictionaryMRISystem.keySet()) 
			lv.put(sg, new SearchParamBruker(dictionaryMRISystem.get(sg).get("keyName"), txtParam).result());
		
		for (String sh : dictionaryMRIUser.keySet())
			lv.put(sh, new SearchParamBruker(dictionaryMRIUser.get(sh).get("keyName"), txtParam).result());

		
		/************************************************
		 * recalculate spatial resol
		 ************************************************/
		String scanResol = lv.get("Scan Resolution");
		String fov = lv.get("FOV");

		if (!lv.get("Scan Mode").contentEquals("1")) {
			float x, y, z;
			String tmp;

			x = Float.parseFloat(fov.split(" +")[0]) * 10 / Float.parseFloat(scanResol.split(" +")[0]);
			y = Float.parseFloat(fov.split(" +")[1]) * 10 / Float.parseFloat(scanResol.split(" +")[1]);
			tmp = String.valueOf(x) + " " + String.valueOf(y);

			if (fov.split(" +").length == 3) {
				z = Float.parseFloat(fov.split(" +")[2]) * 10 / Float.parseFloat(scanResol.split(" +")[2]);
				tmp += " " + String.valueOf(z);
			}

			lv.put("Spatial Resolution", tmp);
		}

		return lv;
	}

	@Override
	public Object[] ListOrderStack(String dim, String nImage) {
		Object[] lv = new Object[5];
		lv[0] = "xyczt";
		lv[1] = 1;
		lv[2] = 1;
		lv[3] = 1;
		lv[4] = null;
		String exp = "\\)\\s\\(";
		String lab, val;

		String[][] listStackParam = null;
		try {
			listStackParam = new StackOrderImage(chemVisupars).listStack();
		} catch (IOException e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
		}

		String[] listlabel = new String[listStackParam[2][1].split(exp).length];

		if (listStackParam[2][1] != "") {
			for (int i = 0; i < listlabel.length; i++) {
				lab = listStackParam[2][1].split(exp)[i].split(",")[1];
				val = listStackParam[2][1].split(exp)[i].split(",")[0];
				val = val.replace("(", "");
				listlabel[i] = lab + " : " + val;
			}
		}

		int orderDescDim = 0;

		if (listStackParam[1][1] != "")
			orderDescDim = Integer.parseInt(listStackParam[1][1]);
		String tmp = listStackParam[2][1];

		/************************************* 2d **************************************************************/
		if (dim.contains("2") && !listStackParam[0][1].equals("1")) {

			if (orderDescDim == 1) {
				lv[0] = "xyczt";
				lv[1] = 1;
				lv[2] = Integer.parseInt(listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
				lv[3] = 1;
			}

			if (orderDescDim == 2) {

				if (tmp.contains("FG_SLICE")) {
					lv[1] = 1;
					if (listlabel[0].contains("FG_SLICE")) {
						lv[0] = "xyczt";
						lv[2] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					} else {
						lv[0] = "xyczt";
						lv[3] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					}
					if (listlabel[1].contains("FG_SLICE")) {
						lv[0] = "xyctz";
						lv[2] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					} else {
						lv[0] = "xyczt";
						lv[3] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					}
				}

				else if (tmp.contains("FG_CYCLE")) {
					lv[1] = 1;
					if (listlabel[0].contains("FG_CYCLE")) {
						lv[0] = "xyczt";
						lv[2] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					} else {
						lv[0] = "xyczt";
						lv[3] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					}
					if (listlabel[1].contains("FG_CYCLE")) {
						lv[0] = "xyctz";
						lv[2] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					} else {
						lv[0] = "xyczt";
						lv[3] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					}
				}

				else if (tmp.contains("FG_ECHO")) {
					lv[1] = 1;
					if (listlabel[0].contains("FG_ECHO")) {
						lv[0] = "xyczt";
						lv[2] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					} else {
						lv[0] = "xyczt";
						lv[3] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					}
					if (listlabel[1].contains("FG_ECHO")) {
						lv[0] = "xyctz";
						lv[2] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					} else {
						lv[0] = "xyczt";
						lv[3] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					}
				}

				else if (tmp.contains("FG_ISA")) {
					lv[1] = 1;
					if (listlabel[0].contains("FG_ISA")) {
						lv[0] = "xyctz";
						lv[2] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					} else {
						lv[0] = "xyczt";
						lv[3] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					}
					if (listlabel[1].contains("FG_ISA")) {
						lv[0] = "xyczt";
						lv[2] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					} else {
						lv[0] = "xyczt";
						lv[3] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					}
				}
			}

			if (orderDescDim == 3) {
				lv[0] = "xyzct";
				lv[1] = Integer.parseInt(listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
				lv[2] = Integer.parseInt(listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
				lv[3] = Integer.parseInt(listlabel[2].substring(listlabel[2].indexOf(": ") + 2, listlabel[2].length()));

			}

		}

		/************************************* 3d **************************************************************/

		if (dim.contains("3")) {
			lv[0] = "xyzct";
			lv[1] = 1;
			lv[2] = Integer.parseInt(nImage);
			lv[3] = 1;

			if (orderDescDim == 1)
				lv[1] = Integer.parseInt(listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));

			if (orderDescDim == 2) {
				if (tmp.contains("FG_CYCLE")) {
					if (listlabel[0].contains("FG_CYCLE")) {
						lv[0] = "xyczt";
						lv[3] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					} else {
						lv[0] = "xyczt";
						lv[1] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					}

					if (listlabel[1].contains("FG_CYCLE")) {
						lv[0] = "xyctz";
						lv[3] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					} else {
						lv[0] = "xyczt";
						lv[1] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					}
				}

				else if (tmp.contains("FG_ECHO")) {
					if (listlabel[0].contains("FG_ECHO")) {
						lv[0] = "xyczt";
						lv[3] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					} else {
						lv[0] = "xyczt";
						lv[1] = Integer.parseInt(
								listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
					}

					if (listlabel[1].contains("FG_ECHO")) {
						lv[0] = "xyctz";
						lv[3] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					} else {
						lv[0] = "xyczt";
						lv[1] = Integer.parseInt(
								listlabel[1].substring(listlabel[1].indexOf(": ") + 2, listlabel[1].length()));
					}
				}

				else {
					lv[0] = "xyczt";
					lv[1] = Integer
							.parseInt(listlabel[0].substring(listlabel[0].indexOf(": ") + 2, listlabel[0].length()));
				}
			}
		}

		String[][] listElements = null;
		try {
			listElements = new ListElementFrame(chemVisupars).listElement();
		} catch (Exception e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(GetStackTrace.getMessage());
		}

		String ch1, ch2, chb;

		chb = tmp;
		ch1 = listElements[0][1];
		ch2 = listElements[1][1];
		String txt = null;

		if (ch1 != null && ch2 != null) {
			if (tmp.contains("FG_ISA")) {
				tmp = tmp.substring(tmp.indexOf("FG_ISA, ") + 8);
				tmp = tmp.substring(0, tmp.indexOf(",") - 1);
				txt = tmp + " :\n";

				for (int i = 0; i < Integer.parseInt(chb.substring(chb.indexOf("(") + 1, chb.indexOf(","))); i++) {
					txt += "t:" + (i + 1) + "/" + chb.substring(chb.indexOf("(") + 1, chb.indexOf(",")) + " - "
							+ ch2.substring(ch2.indexOf("<") + 1, ch2.indexOf(">")) + " " + "["
							+ ch1.substring(ch1.indexOf("<") + 1, ch1.indexOf(">")) + "] \n";
					ch1 = ch1.substring(ch1.indexOf(">") + 1);
					ch2 = ch2.substring(ch2.indexOf(">") + 1);
				}
				txt += "\n";
			}
		}
		lv[4] = txt;

		return lv;
	}
}