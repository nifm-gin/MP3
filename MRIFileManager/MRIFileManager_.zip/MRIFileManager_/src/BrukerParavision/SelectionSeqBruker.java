package BrukerParavision;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringWriter;

import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;
import AbstractClass.SelectionSeq;
import ExportFiles.GetListFieldFromFilestmpRep;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;
import MRIFileManager.OpenImageJ;
import MRIFileManager.ShowImagePanel;
import MRIFileManager.ThumbnailList;
import MRIFileManager.TreeInfo2;
import ij.IJ;

public class SelectionSeqBruker implements ParamMRI2, SelectionSeq {

	private FileManagerFrame wind;
	private String seqSelected;

	public SelectionSeqBruker(FileManagerFrame wind) {
		this.wind = wind;
		seqSelected = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRow(), 0).toString();
	}

	@Override
	public void goSelectionSeq() {

		try {
			wind.getTreeInfoGeneral().setModel(new TreeInfo2(listParamInfoSystem,hmInfo.get(seqSelected)).getTreeInfo().getModel());
			for (int j = 0; j < wind.getTreeInfoGeneral().getRowCount(); j++)
				wind.getTreeInfoGeneral().expandRow(j);
			wind.getTreeInfoUser().setModel(new TreeInfo2(listParamInfoUser,hmInfo.get(seqSelected)).getTreeInfo().getModel());
			for (int j = 0; j < wind.getTreeInfoUser().getRowCount(); j++)
				wind.getTreeInfoUser().expandRow(j);
		} catch (Exception e1) {
			new GetStackTrace(e1);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
		}

		new ShowImagePanel(wind, new OpenBruker2(seqSelected, false, false, seqSelected).getImp(), seqSelected);

		String seqSel;

		if (wind.getTabSeq().getSelectedRowCount() == 1) {
			seqSel = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[0], 0).toString();
			ThumbnailList.list.setSelectedValue(seqSel, true);
		} else {
			int[] ls = new int[wind.getTabSeq().getSelectedRowCount()];
			for (int i = 0; i < wind.getTabSeq().getSelectedRowCount(); i++) {
				seqSel = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i], 0).toString();
				for (int g = 0; g < ThumbnailList.list.getModel().getSize(); g++)
					if (ThumbnailList.list.getModel().getElementAt(g) == seqSel)
						ls[i] = g;
			}
			ThumbnailList.list.setSelectedIndices(ls);
		}
	}

	@Override
	public void popMenuSeq(JPopupMenu pm) {
		String[] listShowParam = { "see 'method' file", "see 'acqp' file", "see 'reco' file", "see 'visu_pars' file" };

		/*********************************************************************************/
		JMenuItem sampleOpen = new JMenuItem("Open image(s) Ctrl+o");
		pm.add(sampleOpen);

		sampleOpen.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				openImage();
			}
		});
		/*********************************************************************************/
		pm.addSeparator();
		/*********************************************************************************/
		JMenuItem openParamFile;

		for (String df : listShowParam) {
			openParamFile = new JMenuItem(df);
			openParamFile.addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					showParamFile(hmSeq.get(seqSelected)[0], df);

				}
			});

			pm.add(openParamFile);
		}
		/*********************************************************************************/
		pm.addSeparator();
		/*********************************************************************************/
		JMenuItem addBasket = new JMenuItem("Add to basket Ctrl+b");
		pm.add(addBasket);

		addBasket.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				fillBasket();
			}
		});
	}

	@Override
	public void openImage() {

		new OpenImageJ();
		// new OpenImageJ("C:\\Program Files\\ImageJ\\ImageJ.exe");

		for (int i = 0; i < wind.getTabSeq().getSelectedRowCount(); i++) {
			String seqSelected = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i], 0).toString();
//			new FillHmsBruker(seqSelected);
//			new OpenBruker(hmInfo.get(seqSelected), hmOrderImage.get(seqSelected), true, false, seqSelected);
			new OpenBruker2(seqSelected, true, false, seqSelected);
		}
	}

	@Override
	public void showParamFile(String chemReco, String keyword) {

		String pathFile = null;
		String tm = "";
		boolean fileOk = false;

		chemReco = chemReco.substring(0, chemReco.lastIndexOf(PrefParam.separator) + 1);

		if (keyword.contains("visu_pars")) {
			pathFile = chemReco + "visu_pars";
			tm = "\n******************************** Seq n� " + seqSelected
					+ " - visu_pars **********************************************" + "\n";
		}

		if (keyword.contains("reco")) {
			pathFile = chemReco + "reco";
			tm = "\n******************************** Seq n� " + seqSelected
					+ " - reco ***************************************************" + "\n";
		}

		if (keyword.contains("acqp")) {
			pathFile = chemReco.substring(0, chemReco.indexOf("pdata")) + "acqp";
			tm = "\n******************************** Seq n� " + seqSelected
					+ " - acqp ***************************************************" + "\n";
		}

		if (keyword.contains("method")) {
			pathFile = chemReco.substring(0, chemReco.indexOf("pdata")) + "method";
			tm = "\n******************************** Seq n� " + seqSelected
					+ " - method *************************************************" + "\n";
		}

		try {
			BufferedInputStream in = new BufferedInputStream(new FileInputStream(pathFile));
			StringWriter out = new StringWriter();
			int b;
			while ((b = in.read()) != -1)
				out.write(b);
			out.flush();
			out.close();
			in.close();
			tm = tm + out.toString();
			fileOk = true;

		} catch (IOException e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
		}

		if (fileOk) {
			new OpenImageJ();
			IJ.log(tm);
		}
	}

	@Override
	public void fillBasket() {

		String seqSel = null;
		String listInBask = "[Bruker] ";

		GetListFieldFromFilestmpRep dg = new GetListFieldFromFilestmpRep(PrefParam.namingNiftiExport);

		for (int i = 0; i < wind.getTabSeq().getSelectedRowCount(); i++) {

			listInBask = "[Bruker] ";
			seqSel = wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i], 0).toString();
//			new FillHmsBruker(seqSel);

			if (hmInfo.get(seqSel).get("Slice Orientation").split(" ").length > 1)
				JOptionPane.showMessageDialog(wind, "Can't export seq. n� " + seqSel + " (number of orientation > 1)");

			else {
				for (String gk : dg.getListFieldTrue()) {
					if (gk.contains("Patient Name") || gk.contains("Study Name") || gk.contains("Creation Date")) {
						listInBask += (String) wind.getTabData().getValueAt(wind.getTabData().getSelectedRow(),
								wind.getTabData().getColumn(gk).getModelIndex());
					}
					if (gk.contains("Seq. n�") || gk.contains("Protocol") || gk.contains("Sequence Name")) {
						listInBask += (String) wind.getTabSeq().getValueAt(wind.getTabSeq().getSelectedRows()[i],
								wind.getTabSeq().getColumn(gk).getModelIndex());
					}
					listInBask += dg.getSeparateChar();
				}
				listInBask = listInBask.substring(0, listInBask.lastIndexOf(dg.getSeparateChar()));

				int n = 0;

				if (listinBasket.contains(listInBask)) {
					n = JOptionPane.showOptionDialog(null,
							listInBask + "\n" + "This already exits, Do you want to overwrite it? ", "Warning",
							JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
							new Object[] { "Yes", "No" }, "No");
				}

				if (n == 0) {
					listinBasket.removeElement(listInBask);
					listinBasket.add(listinBasket.size(), listInBask);
					listBasket_hms.put(listInBask, hmInfo.get(seqSel));
					listBasket_hmo.put(listInBask, hmOrderImage.get(seqSel));
				}

			}
		}
		wind.getListBasket().setModel(listinBasket);
		wind.getListBasket().updateUI();
		wind.getTabbedPane().setSelectedIndex(1);
		wind.getTabbedPane().setTitleAt(1, "Basket " + "(" + listinBasket.size() + ")");

	}
}