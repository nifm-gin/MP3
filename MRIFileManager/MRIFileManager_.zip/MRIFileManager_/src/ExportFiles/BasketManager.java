package ExportFiles;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Locale;

import javax.swing.AbstractAction;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.WindowConstants;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;
import MRIFileManager.FileManagerFrame;

public class BasketManager extends AbstractAction implements ParamMRI2 {

	private static final long serialVersionUID = 1L;

	public static HashMap<String, String[]> listBasket = new HashMap<String, String[]>();

	private FileManagerFrame wind;

	public BasketManager(FileManagerFrame wind, String command) {

		super(command);
		this.wind = wind;

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getActionCommand().contentEquals("remove selection")) {
			int j = 0;
			for (int sdg : wind.getListBasket().getSelectedIndices()) {
				listBasket.remove(listinBasket.get(sdg - j));
				listinBasket.remove(sdg - j);
				j++;
			}
		}

		if (arg0.getActionCommand().contentEquals("remove all")) {
			listBasket = new HashMap<String, String[]>();
			listinBasket.removeAllElements();
		}

		if (arg0.getActionCommand().contentEquals("export to NifTI-1")
				&& wind.getListBasket().getModel().getSize() != 0) {

			JDialog dlg = new JDialog(wind, "Progress dialog ...", false);
			dlg.add(BorderLayout.NORTH, new JLabel("Export in progress, wait..."));
			dlg.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
			dlg.setSize(300, 75);
			dlg.setLocationRelativeTo(wind);
			dlg.setVisible(true);
			
			new ConvertImage(wind, "export to NifTI-1");

			dlg.dispose();

			JOptionPane.showMessageDialog(wind, "Export completed");
		}

		if (arg0.getActionCommand().contentEquals("Change")) {
			final JFileChooser rep = new JFileChooser();
			rep.setAcceptAllFileFilterUsed(false);
			rep.setCurrentDirectory(PrefParam.FilestmpExportNifit);
			rep.setApproveButtonText("Select this directory");
			rep.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			rep.setLocale(Locale.ENGLISH);
			rep.updateUI();

			switch (rep.showOpenDialog(null)) {
			case JFileChooser.APPROVE_OPTION:
				wind.getpathExportNifti().setText(rep.getSelectedFile().getPath());
				PrefParam.FilestmpExportNifit = rep.getSelectedFile();
				break;
			}
		}

		wind.getListBasket().setModel(listinBasket);
		wind.getListBasket().updateUI();
		wind.getListBasket().clearSelection();
		wind.getTabbedPane().setTitleAt(1, "basket "+"("+listinBasket.size()+")");	}
}