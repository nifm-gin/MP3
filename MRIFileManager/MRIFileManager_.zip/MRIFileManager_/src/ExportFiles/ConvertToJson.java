package ExportFiles;

import java.io.FileWriter;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import AbstractClass.Format;
import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;


public class ConvertToJson extends PrefParam implements ParamMRI2, Format {

	public ConvertToJson(String pathJson, String nameJson, Object linebasket) {

		JSONObject obj = new JSONObject();
		JSONArray list, list2;

		for (String kn : dictionaryJsonSystem.keySet()) { // kn listLabelMRI
			try {
				if (listBasket_hms.get(linebasket).get(kn) != null) {
					if (dictionaryJsonSystem.get(kn).get("type").contains(("string"))) {
						list = new JSONArray();
						list.add(listBasket_hms.get(linebasket).get(kn));
						obj.put(dictionaryJsonSystem.get(kn).get("tagJson").toString(), list);
					}

					if (dictionaryJsonSystem.get(kn).get("type").contains(("float"))) {
						list = new JSONArray();

						if (listBasket_hms.get(linebasket).get(kn).split(" +").length > 1) {
							for (String hj : listBasket_hms.get(linebasket).get(kn).split(" +")) {
								list2 = new JSONArray();
								list2.add(Float.parseFloat(hj));
								list.add(list2);
							}

						} else
							list.add(Float.parseFloat(listBasket_hms.get(linebasket).get(kn)));
						obj.put(dictionaryJsonSystem.get(kn).get("tagJson").toString(), list);
					}

					if (dictionaryJsonSystem.get(kn).get("type").contains(("int"))) {
						list = new JSONArray();

						if (listBasket_hms.get(linebasket).get(kn).split(" +").length > 1) {
							for (String hj : listBasket_hms.get(linebasket).get(kn).split(" +")) {
								list2 = new JSONArray();
								list2.add(Integer.parseInt(hj));
								list.add(list2);
							}

						} else
							list.add(Integer.parseInt(listBasket_hms.get(linebasket).get(kn)));

						obj.put(dictionaryJsonSystem.get(kn).get("tagJson").toString(), list);
					}
				}
			} catch (Exception e) {

			}
		}
		for (String kn : dictionaryJsonUser.keySet()) {
			
			try {
				if (listBasket_hms.get(linebasket).get(kn) != null) {

					if (dictionaryJsonUser.get(kn).get("type").contains(("string"))) {
						list = new JSONArray();
						list.add(listBasket_hms.get(linebasket).get(kn));
						obj.put(dictionaryJsonUser.get(kn).get("tagJson").toString(), list);
					}

					if (dictionaryJsonUser.get(kn).get("type").contains(("float"))) {
						list = new JSONArray();

						if (listBasket_hms.get(linebasket).get(kn).split(" +").length > 1) {
							for (String hj : listBasket_hms.get(linebasket).get(kn).split(" +")) {
								list2 = new JSONArray();
								list2.add(Float.parseFloat(hj));
								list.add(list2);
							}

						} else
							list.add(Float.parseFloat(listBasket_hms.get(linebasket).get(kn)));
						obj.put(dictionaryJsonUser.get(kn).get("tagJson").toString(), list);
					}

					if (dictionaryJsonUser.get(kn).get("type").contains(("int"))) {
						list = new JSONArray();

						if (listBasket_hms.get(linebasket).get(kn).split(" +").length > 1) {
							for (String hj : listBasket_hms.get(linebasket).get(kn).split(" +")) {
								list2 = new JSONArray();
								list2.add(Integer.parseInt(hj));
								list.add(list2);
							}

						} else
							list.add(Integer.parseInt(listBasket_hms.get(linebasket).get(kn)));

						obj.put(dictionaryJsonUser.get(kn).get("tagJson").toString(), list);
					}

				}
			} catch (Exception e) {

			}
		}
		try

		{
			FileWriter writer = new FileWriter(pathJson + PrefParam.separator + nameJson + ".json");
			writer.write(obj.toJSONString());
			writer.flush();
			writer.close();
		} catch (Exception e) {
			System.out.println("Erreur: impossible de cr�er le fichier '" + pathJson + PrefParam.separator + nameJson
					+ ".json" + "'");
		}
	}
}