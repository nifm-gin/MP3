package ExportFiles;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Scanner;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

import AbstractClass.PrefParam;
import MRIFileManager.ExtractTxtfromFile;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;
import MRIFileManager.PrefParamModif;

public class ExportFiles extends AbstractAction {
	
	private static final long serialVersionUID = 1L;
	private FileManagerFrame wind;
	private JFrame frameOptionExport;
	private JPanel panelL;
	private JTextField nField,replaceCharForbidden;
	private String[] listField={"PatientName","StudyName","CreationDate","SeqNumber","Protocol","SequenceName"};
	private String[] listFieldChooseinFile=null;
	private String[] listnull=null;
	private int dButton=2;
	private JComboBox<String>[] listCombo;
	private JTextField textSeparate;
	private Scanner sc;	
	private String separateChar="-";
	
	public ExportFiles(FileManagerFrame wind,String command) {
		super(command);
		this.wind=wind;
	}
	
	public void optionExport() {

		String txt="";
		if (PrefParam.FilestmpRep.exists()) {
			txt=new ExtractTxtfromFile(PrefParam.FilestmpRep.toString()).getTxt();
			sc = new Scanner(txt);
			String tmp="";
			while (sc.hasNext()) {
				tmp=sc.next();
				if (tmp.contains("[NamingNifTI]")) {
//					listFieldChooseinFile=getListFieldFromFilestmpRep(sc.next());
					GetListFieldFromFilestmpRep dg = new GetListFieldFromFilestmpRep(sc.next());
					listFieldChooseinFile=dg.getListField();
					separateChar=dg.getSeparateChar();
				}
			}
		}
		
		frameOptionExport = new JFrame("Options export - file naming");
		frameOptionExport.setMinimumSize(new Dimension(500, 400));
		frameOptionExport.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		frameOptionExport.setLocationRelativeTo(wind);
		
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(1, 1));

        panelL = new JPanel();
        panelL.setLayout(null);
			
		nField = new JTextField();
		if (listFieldChooseinFile==null)
			nField.setText(String.valueOf(listField.length));
		else
			nField.setText(String.valueOf(listFieldChooseinFile.length));
				
		nField.setBounds(10, 0, 100, 25);
		JLabel nField_label = new JLabel("Number of Fields (<7)",SwingConstants.LEFT);
		nField_label.setBounds( 130, 0, 200, 25);
		
		panelL.add(nField_label);
		panelL.add(nField);
		
		nField.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				try {
				if (Integer.parseInt(nField.getText())>6)
					nField.setText("6");
				if (Integer.parseInt(nField.getText())<=0)
					nField.setText("1");
				listFieldChooseinFile= listnull;
				dButton=2;
				panelL.removeAll();
				panelL.add(nField_label);
				panelL.add(nField);
				CreateRemoveCombo();
				panelL.add(buttonApply());
				panelL.add(buttonCancel());
				panel.add(panelL);
				} catch (Exception e2) {
					new GetStackTrace(e2);
					FileManagerFrame.getBugText().setText(FileManagerFrame.getBugText().getText()
							+ "\n----------------\n" + GetStackTrace.getMessage());
				}
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
	
		CreateRemoveCombo();
		panelL.add(buttonApply());
		panelL.add(buttonCancel());
		panel.add(panelL);
		
		frameOptionExport.getContentPane().add(panel);
		frameOptionExport.setVisible(true);
	
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		optionExport();
	}
	
	private void CreateRemoveCombo() {

		listCombo = new JComboBox[Integer.parseInt(nField.getText())];	
		JLabel[] listLabel = new JLabel[Integer.parseInt(nField.getText())];
//		panelL.removeAll();
		
		textSeparate = new JTextField();
		textSeparate.setText(separateChar);
		textSeparate.setToolTipText("Warning    < > / \\ * . ? | : are forbidden");
		textSeparate.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				
				
				if (e.getKeyChar()==' ' || e.getKeyChar()=='\\' || e.getKeyChar()=='/' || e.getKeyChar()=='.'
										|| e.getKeyChar()=='*'  || e.getKeyChar()=='"' || e.getKeyChar()=='?' 
										|| e.getKeyChar()=='<'  || e.getKeyChar()=='>' || e.getKeyChar()==':'
										|| e.getKeyChar()==' '	|| e.getKeyChar()=='|') {
					try {
//						textSeparate.setText(textSeparate.getText().replace(" +", ""));
//						textSeparate.setText(textSeparate.getText().replace("\\", ""));
//						textSeparate.setText(textSeparate.getText().replace("/", ""));
//						textSeparate.setText(textSeparate.getText().replace(".", ""));
						textSeparate.setText(textSeparate.getText().replace("[<>:?/\\\\*|"+'"'+"]", ""));
						e.consume();
						
					} catch (Exception e1) {
						new GetStackTrace(e1);
						FileManagerFrame.getBugText().setText(FileManagerFrame.getBugText().getText()
								+ "\n----------------\n" + GetStackTrace.getMessage());
					}
				}
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
			}
		});
		JLabel labelSeparate = new JLabel("separator character between fields");
		
		textSeparate.setBounds(10  , 30, 200, 30);
		labelSeparate.setBounds(220, 30, 200,30);
		panelL.add(textSeparate);
		panelL.add(labelSeparate);
		
		replaceCharForbidden = new JTextField();
		replaceCharForbidden.setText(" ");
		
		
		for (int i=0;i<Integer.parseInt(nField.getText());i++) {
			listCombo[i] = new JComboBox<String>(listField);
			if (listFieldChooseinFile==null)
				listCombo[i].setSelectedIndex(i);
			else 
				listCombo[i].setSelectedItem(listFieldChooseinFile[i]);
			listLabel[i] = new JLabel("Field n� "+String.valueOf(i+1),SwingConstants.LEFT);
			listCombo[i].setBounds(10 ,(i+2)*30+5 , 200, 25);
			listLabel[i].setBounds(220,(i+2)*30+5 , 200, 25);
			panelL.add(listCombo[i]);
			panelL.add(listLabel[i]);
			panelL.revalidate();
			dButton++;
		}
		panelL.repaint();
//		frameOptionExport.pack();
		frameOptionExport.validate();
	}
	
	private JButton buttonApply() {
		JButton buttonOk = new JButton("Apply");
		buttonOk.setBounds(50, 40*dButton, 100, 25);
		buttonOk.addActionListener(new ActionListener() {
		
			@Override
			public void actionPerformed(ActionEvent e) {
				frameOptionExport.dispose();
				String tmp="";
				for (int i=0;i<listCombo.length;i++) {
					tmp+=listCombo[i].getSelectedItem().toString()+textSeparate.getText();
				}
				if (!tmp.contentEquals("")){
					tmp=tmp.substring(0,tmp.lastIndexOf(textSeparate.getText()));
				}
				
				new PrefParamModif("[NamingNifTI]", tmp);
				
//				String txt="";
//				boolean found=false;
//				
//				if (PrefParam.FilestmpRep.exists()) {
//					txt=new ExtractTxtfromFile(PrefParam.FilestmpRep.toString()).getTxt();
//					sc = new Scanner(txt);
//					String tmp1="";
//					
//				while (sc.hasNext()) {
//					tmp1=sc.next();
//					if (tmp1.contains("[NamingNifTI]")) {
//						txt=txt.replace("[NamingNifTI]"+" "+sc.next(), "[NamingNifTI] "+tmp);
//						found=true;
//					}
//				}
//				
//				if (!found) {
//					txt=txt+"[NamingNifTI] "+tmp+"\n";
//				}
//				}
//				else 
//					txt="[NamingNifTI] "+tmp+"\n";
				
				PrefParam.namingNiftiExport=tmp;
				
//				try {
//					FileWriter printRep = new FileWriter(PrefParam.FilestmpRep);
//					printRep.write(txt);
//					printRep.close();
//					
//				} catch (Exception e1) {
//					new GetStackTrace(e1);
//					FileManagerFrame.getBugText().setText(FileManagerFrame.getBugText().getText()+"\n----------------\n"+GetStackTrace.getMessage());
//				}
			}
		});
		return buttonOk;
	}

	private JButton buttonCancel() {
		
		JButton buttonCanc = new JButton("Cancel");
		buttonCanc.setBounds(150, 40*dButton, 100, 25);
		buttonCanc.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frameOptionExport.dispose();
				
			}
		});

		return buttonCanc;
	}	
}