package ExportFiles;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import AbstractClass.ParamMRI2;
import AbstractClass.PrefParam;
import AbstractClass.convertNifti;
import BrukerParavision.ConvertBrukerToNifti;
import MRIFileManager.FileManagerFrame;
import MRIFileManager.GetStackTrace;
import Philips.ConvertPhilipsToNifti;
import ij.IJ;
import ij.ImagePlus;
import ij.ImageStack;
import ij.io.FileInfo;
import ij.io.ImageWriter;
import ij.measure.Calibration;
import ij.process.ColorProcessor;

public class ConvertImage extends PrefParam implements ParamMRI2 {

	public static final int ANALYZE_7_5 = 0;
	public static final int NIFTI_ANALYZE = 1; 
	public static final int NIFTI_FILE = 2;
	public boolean littleEndian = false; // Change this to force little endian
											// output
	private int output_type = NIFTI_FILE; // Change this to change default
											// output
	private boolean signed16Bit = false;

	private String directory = "", suffix = ".nii";
	private String seqSel;
	private convertNifti conv;

	private ImagePlus imp;
	private double[] quaterns = new double[5];
	private double[][] srow = new double[3][4];
	private int qform, sform;
	private Boolean continuSave = false;
	

	public ConvertImage (FileManagerFrame wind, String command) {
		
		Boolean ok = true;

		if (FilestmpExportNifit == null) {

			final JFileChooser rep = new JFileChooser();
			rep.setAcceptAllFileFilterUsed(false);
			rep.setCurrentDirectory(FilestmpExportNifit);
			rep.setApproveButtonText("Select this directory");
			rep.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
			rep.setLocale(Locale.ENGLISH);
			rep.updateUI();

			switch (rep.showOpenDialog(null)) {
			case JFileChooser.APPROVE_OPTION:
				directory = rep.getSelectedFile().getPath();
				FilestmpExportNifit = rep.getSelectedFile();
				wind.getpathExportNifti().setText(directory);
				ok = true;
				break;

			case JFileChooser.CANCEL_OPTION:
				ok = false;
				break;
			}
		} else {
			directory = FilestmpExportNifit.toString();
			ok = true;
		}

		if (ok) {
			Object lb;

			for (int i=0;i<listinBasket.size();i++) {
			
				lb = listinBasket.getElementAt(i);

				for (int j = 0; j < 5; j++)
					quaterns[j] = 0.0; // initialization
				for (int j = 0; j < 3; j++)
					srow[j][j] = 1.0; // initialization

				if (lb.toString().contains("[Bruker]")) {
					qform = 2;
					sform = 1;
					conv = new ConvertBrukerToNifti();
				}
				// if (lb.toString().contains("[Dicom]")) {
				// conv = new convertDicomToNifti();
				// qform=0;
				// sform=1;
				// }
				if (lb.toString().contains("[Philips]")) {
					qform = 1;
					sform = 1;
					conv = new ConvertPhilipsToNifti();
				}
				
				try{

				imp = conv.convertToNifti((String) lb);
				conv.AffineQuaternion((String) lb);
				quaterns = conv.quaterns();
				srow = conv.srow();
				String nameFile = (lb.toString().substring(9)).replaceAll(" +", "");
				nameFile = nameFile.replace(":", "");
				nameFile = nameFile.replace("/", "");
				nameFile = nameFile.replace("\\", "");
				nameFile = nameFile.replace("*", "");
				
				save(imp, directory, nameFile + suffix);
				new ConvertToJson(directory, nameFile, lb);
				} catch (Exception e) {
					e.printStackTrace();
					JOptionPane.showMessageDialog(wind, "Warning : some conversions are failed !!");
				}
			}
			
			listinBasket.removeAllElements();
			listBasket_hmo.clear();
			listBasket_hms.clear();
		}
	}

	public boolean save(ImagePlus imp, String directory, String name) {

		if (name == null)
			return false;
		name = name.trim();
		directory = directory.trim();

		if (!directory.endsWith(PrefParam.separator))
			directory += PrefParam.separator;

		int n = 0;

		if (new File(directory + name).exists() && !continuSave) {
			n = JOptionPane.showOptionDialog(null,
					directory + name + "\n" + "This file already exits, Do you want to overwrite it? ", "Warning",
					JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null,
					new Object[] { "Yes", "Yes to all", "No" }, "No");
		}

		if (n == 2)
			return false;

		if (n == 1)
			continuSave = true;

		try {
			String hdrFile = (output_type == NIFTI_FILE) ? directory + name : directory + name + ".hdr";
			FileOutputStream stream = new FileOutputStream(hdrFile);
			DataOutputStream output = new DataOutputStream(stream);

			IJ.showStatus("Saving as Analyze: " + directory + name);

			writeHeader(imp, output, output_type);

			if (output_type != NIFTI_FILE) {
				output.close();
				stream.close();
				String fileName = directory + name + ".img";

				stream = new FileOutputStream(fileName);
				output = new DataOutputStream(stream);
			}
			FileInfo fi = imp.getFileInfo();
			// System.out.println(imp.getFileInfo());
			fi.intelByteOrder = littleEndian;
			if (fi.fileType != FileInfo.RGB) {
				// if (imp.getStackSize()>1 && imp.getStack().isVirtual()) {
				// fi.virtualStack = (VirtualStack)imp.getStack();
				// fi.fileName = "FlipTheseImages";
				// }
				ImageWriter iw = new ImageWriter(fi);
				iw.write(output);
			} else {
				writeRGBPlanar(imp, output);
			}

			output.close();
			stream.close();

			return true;
		} catch (IOException e) {
			new GetStackTrace(e);
			FileManagerFrame.getBugText().setText(
					FileManagerFrame.getBugText().getText() + "\n----------------\n" + GetStackTrace.getMessage());
			IJ.log("Nifti_Writer: " + e.getMessage());
			return false;
		}
	}

	private void writeHeader(ImagePlus imp, DataOutputStream output, int type) throws IOException {

		FileInfo fi = imp.getFileInfo();

		short bitsallocated, datatype;

		NiftiHeader nfti_hdr = (NiftiHeader) imp.getProperty("nifti");

		Calibration c = imp.getCalibration();

		switch (fi.fileType) {
		case FileInfo.GRAY8:
			datatype = 2; // DT_UNSIGNED_CHAR
			bitsallocated = 8;
			break;
		case FileInfo.GRAY16_SIGNED:
		case FileInfo.GRAY16_UNSIGNED:
			datatype = 4; // DT_SIGNED_SHORT
			bitsallocated = 16;
			break;
		case FileInfo.GRAY32_INT:
			datatype = 8; // DT_SIGNED_INT
			bitsallocated = 32;
			break;
		case FileInfo.GRAY32_FLOAT:
			datatype = 16; // DT_FLOAT
			bitsallocated = 32;
			break;
		case FileInfo.RGB:
			datatype = 128; // DT_RGB
			bitsallocated = 24;
			break;
		default:
			datatype = 0; // DT_UNKNOWN
			bitsallocated = (short) (fi.getBytesPerPixel() * 8);
		}

		// header_key

		writeInt(output, 348); // sizeof_hdr
		int i;
		for (i = 0; i < 10; i++)
			output.write(0); // data_type
		for (i = 0; i < 18; i++)
			output.write(0); // db_name
		writeInt(output, 16384); // extents
		output.writeShort(0); // session_error
		output.writeByte('r'); // regular
		output.writeByte(0); // hkey_un dim_info

		// image_dimension
		// short [] dims = new short[8];
		// dims[0] = (imp.getNChannels() == 1) ? (short) 4 : (short) 5;
		// dims[1] = (short) fi.width;
		// dims[2] = (short) fi.height;
		// dims[3] = (short) imp.getNSlices();
		// dims[4] = (short) imp.getNFrames();
		// dims[5] = (short) imp.getNChannels();
		//
		// for (i = 0; i < 8; i++) writeShort( output, dims[i] ); // dim[0-7]

		// System.out.println(imp.getNDimensions());
		// System.out.println("Channel :"+imp.getNChannels());
		// System.out.println("Slices :"+imp.getNSlices());
		// System.out.println("Frame :"+imp.getNFrames());

		if (imp.getNDimensions() == 1) {
			writeShort(output, (short) 4); // dim[0]
			writeShort(output, (short) fi.width); // dim[1]
			writeShort(output, (short) fi.height); // dim[2]
			writeShort(output, (short) 1); // dim[3]
			writeShort(output, (short) 1); // dim[4]
		}
		if (imp.getNDimensions() == 2) {
			writeShort(output, (short) 4); // dim[0]
			writeShort(output, (short) fi.width); // dim[1]
			writeShort(output, (short) fi.height); // dim[2]
			int rap = Integer.parseInt(BasketManager.listBasket.get(seqSel)[4])
					/ Integer.parseInt(BasketManager.listBasket.get(seqSel)[6]);
			writeShort(output, (short) Integer.parseInt(BasketManager.listBasket.get(seqSel)[6])); // dim[3]
			writeShort(output, (short) rap); // dim[4]
			writeShort(output, (short) 1); // dim[5]
		}
		if (imp.getNDimensions() == 3) {
			writeShort(output, (short) 4); // dim[0]
			writeShort(output, (short) fi.width); // dim[1]
			writeShort(output, (short) fi.height); // dim[2]
			writeShort(output, (short) fi.nImages); // dim[3]
			writeShort(output, (short) 1); // dim[4]
			writeShort(output, (short) 1); // dim[5]
		}
		if (imp.getNDimensions() == 4 && imp.getNChannels()==1) {
			writeShort(output, (short) 4); // dim[0]
			writeShort(output, (short) fi.width); // dim[1]
			writeShort(output, (short) fi.height); // dim[2]
			writeShort(output, (short) imp.getNSlices()); // dim[3]
			writeShort(output, (short) imp.getNFrames()); // dim[4]
			writeShort(output, (short) 1); // dim[5]
		}
		if (imp.getNDimensions() == 4 && imp.getNFrames()==1) {
			writeShort(output, (short) 4); // dim[0]
			writeShort(output, (short) fi.width); // dim[1]
			writeShort(output, (short) fi.height); // dim[2]
			writeShort(output, (short) imp.getNChannels()); // dim[3]
			writeShort(output, (short) imp.getNSlices()); // dim[4]
			writeShort(output, (short) 1); // dim[5]
		}
		if (imp.getNDimensions() == 5) {
			writeShort(output, (short) 5); // dim[0]
			writeShort(output, (short) fi.width); // dim[1]
			writeShort(output, (short) fi.height); // dim[2]
			writeShort(output, (short) imp.getNSlices()); // dim[3]
			writeShort(output, (short) imp.getNFrames()); // dim[4]
			writeShort(output, (short) imp.getNChannels()); // dim[5]
		}

		for (i = 0; i < 2; i++)
			output.writeShort(0); // dim[6-7]

		writeFloat(output, (nfti_hdr == null) ? 0.0 : nfti_hdr.intent_p1); // intent_p1
		writeFloat(output, (nfti_hdr == null) ? 0.0 : nfti_hdr.intent_p2); // intent_p2
		writeFloat(output, (nfti_hdr == null) ? 0.0 : nfti_hdr.intent_p3); // intent_p3
		writeShort(output, (nfti_hdr == null) ? 0 : nfti_hdr.intent_code); // intent_code

		writeShort(output, datatype); // datatype
		writeShort(output, bitsallocated); // bitpix
		if (nfti_hdr == null) {
			output.writeShort(0); // dim_un0
		} else {
			writeShort(output, nfti_hdr.slice_start); // slice_start
		}

		// double [] quaterns = new double [ 5 ];
		int qform_code = NiftiHeader.NIFTI_XFORM_UNKNOWN;
		int sform_code = NiftiHeader.NIFTI_XFORM_UNKNOWN;
		double qoffset_x = 0.0, qoffset_y = 0.0, qoffset_z = 0.0;
		qoffset_x = srow[0][3];
		qoffset_y = srow[1][3];
		qoffset_z = srow[2][3];
		// for (i=0; i<5; i++) quaterns[i] = 0.0;
		// double [][] srow = new double[3][4];
		// for (i=0; i<3; i++) srow[i][i] = 1.0;

		qform_code = qform;
		sform_code = sform;

		// if (bruker) {
		// try {
		// BrukerToSPM bts = new
		// BrukerToSPM(BasketManager.listBasket.get(seqSel)[0],title);
		// qform_code=2;
		// sform_code=1;
		// srow=bts.getMat();
		// quaterns=bts.getQuatern();
		// qoffset_x=srow[0][3];
		// qoffset_y=srow[1][3];
		// qoffset_z=srow[2][3];
		// } catch (Exception e){
		// IJ.log(title+" : cannot do affine transformation and quaternion");
		// }
		//
		// }

		// if (parrec) {
		// try {
		// ParRecToSPM2 pts = new ParRecToSPM2(chemPar,title);
		// qform_code=1;
		// sform_code=1;
		// srow=pts.getsform();
		// quaterns=pts.getquaterns();
		// qoffset_x=srow[0][3];
		// qoffset_y=srow[1][3];
		// qoffset_z=srow[2][3];
		// } catch (Exception e){
		// IJ.log(title+" : cannot do affine transformation and quaternion");
		// }
		// }

		// if (dicom) {
		// try{
		// // DicomToSPM(position, orientation, dim, fov, sliceOrientation)
		// DicomToSPM2 dts = new DicomToSPM2(off, ang, dimDicom, pxDicom,
		// orienDicom);
		// qform_code=0;
		// sform_code=1;
		// srow=dts.getsform();
		// quaterns=dts.getquaterns();
		// qform_code=1;
		// qoffset_x=srow[0][3];
		// qoffset_y=srow[1][3];
		// qoffset_z=srow[2][3];
		//
		// } catch (Exception e){
		// IJ.log(title+" : cannot do affine transformation and quaternion");
		// new GetStackTrace(e);
		// MRIFileManager_.getBugText().setText(MRIFileManager_.getBugText().getText()+"\n----------------\n"+GetStackTrace.getMessage());
		// }
		// }

		// sform_code=0;
		//
		// srow[0][0]=1;
		// srow[0][1]=0;
		// srow[0][2]=0;
		// srow[0][3]=0;
		//
		// srow[1][0]=0;
		// srow[1][1]=1;
		// srow[1][2]=0;
		// srow[1][3]=0;
		//
		// srow[2][0]=0;
		// srow[2][1]=0;
		// srow[2][2]=1;
		// srow[2][3]=0;

		// srow[3][0]=0;
		// srow[3][1]=0;
		// srow[3][2]=0;
		// srow[3][3]=1;

		float[] pixdims = new float[8];
		pixdims[0] = (float) quaterns[0];
		pixdims[1] = (float) fi.pixelWidth;
		pixdims[2] = (float) fi.pixelHeight;
		pixdims[3] = (float) fi.pixelDepth;
		pixdims[4] = (float) fi.frameInterval;

		 if ((type!=ANALYZE_7_5) && (nfti_hdr!=null)) {
		 for (i=5; i<8; i++) pixdims[i] = nfti_hdr.pixdim[i];
		 }

		for (i = 0; i < 8; i++)
			writeFloat(output, pixdims[i]); // pixdim[4-7]

		writeFloat(output, (type == NIFTI_FILE) ? 352 : 0); // vox_offset
		double[] coeff = new double[2];
		coeff[0] = 0.0;
		coeff[1] = 1.0;
		if (c.getFunction() == Calibration.STRAIGHT_LINE) {
			coeff = c.getCoefficients();
		}

		double c_offset = coeff[0];
		if (signed16Bit) {
			if (coeff[1] != 0.0)
				c_offset += 32768.0 * coeff[1];
			else
				c_offset += 32768.0;
		}

		// if (type==ANALYZE_7_5) {
		// writeFloat( output, 1 ); // roi_scale
		// writeFloat( output, 0 ); // funused1
		// writeFloat( output, 0 ); // funused2
		// } else {
		writeFloat(output, coeff[1]); // scl_slope
		writeFloat(output, c_offset); // scl_inter

		// writeShort( output, (nfti_hdr!=null) ? (short) nfti_hdr.slice_end :
		// (short) (fi.nImages-1) ); // slice_end
		writeShort(output, (short) 0); // slice_end
		output.write((nfti_hdr != null) ? nfti_hdr.slice_code : 0); // slice_code

		String unit = c.getUnit().toLowerCase().trim();
		byte xyzt_unit = NiftiHeader.UNITS_UNKNOWN;
		if (unit.equals("meter") || unit.equals("metre") || unit.equals("m")) {
			xyzt_unit |= NiftiHeader.UNITS_METER;
		} else if (unit.equals("mm")) {
			xyzt_unit |= NiftiHeader.UNITS_MM;
		} else if (unit.equals("micron")) {
			xyzt_unit |= NiftiHeader.UNITS_MICRON;
		}
		output.write(xyzt_unit); // xyzt_units

		// }
		double min = imp.getProcessor().getMin();
		double max = imp.getProcessor().getMax() + 1;

		writeFloat(output, coeff[0] + (coeff[1] * max)); // cal_max
		writeFloat(output, coeff[0] + (coeff[1] * min)); // cal_min
		// if (type==ANALYZE_7_5) {
		// output.writeInt( 0 ); // compressed
		// output.writeInt( 0 ); // verified
		// ImageStatistics s = imp.getStatistics();
		// writeInt(output, signed16Bit ? (int) s.max+32768 : (int) s.max); //
		// glmax
		// writeInt(output, signed16Bit ? (int) s.min+32768 : (int) s.min); //
		// glmin
		// } else {
		writeFloat(output, (nfti_hdr != null) ? nfti_hdr.slice_duration : 0.0); // slice_duration
		writeFloat(output, (nfti_hdr != null) ? nfti_hdr.toffset : 0.0); // toffset
		writeFloat(output, 0.0); // glmax
		writeFloat(output, 0.0); // glmin
		// }

		// data_history

		// if (type==ANALYZE_7_5) {
		// for (i = 0; i < 80; i++) output.write( 0 ); // descrip
		// for (i = 0; i < 24; i++) output.write( 0 ); // aux_file
		//
		// output.write(0); // orient
		// for (i = 0; i < 10; i++) output.write( 0 ); // originator
		// for (i = 0; i < 10; i++) output.write( 0 ); // generated
		// for (i = 0; i < 10; i++) output.write( 0 ); // scannum
		// for (i = 0; i < 10; i++) output.write( 0 ); // patient_id
		// for (i = 0; i < 10; i++) output.write( 0 ); // exp_date
		// for (i = 0; i < 10; i++) output.write( 0 ); // exp_time
		// for (i = 0; i < 3; i++) output.write( 0 ); // hist_un0
		// output.writeInt( 0 ); // views
		// output.writeInt( 0 ); // vols_added
		// output.writeInt( 0 ); // start_field
		// output.writeInt( 0 ); // field_skip
		// output.writeInt( 0 ); // omax
		// output.writeInt( 0 ); // omin
		// output.writeInt( 0 ); // smax
		// output.writeInt( 0 ); // smin
		// } else {
		String desc = (nfti_hdr == null) ? new String() : nfti_hdr.descrip.trim();
		int length = desc.length();
		if (length > 80) {
			output.writeBytes(desc.substring(0, 80));
		} else {
			output.writeBytes(desc);
			for (i = length; i < 80; i++)
				output.write(0);
		}

		desc = (nfti_hdr == null) ? "" : nfti_hdr.aux_file.trim();
		length = desc.length();
		if (length > 24) {
			output.writeBytes(desc.substring(0, 24));
		} else {
			output.writeBytes(desc);
			for (i = length; i < 24; i++)
				output.write(0);
		}

		writeShort(output, (short) qform_code); // qform_code
		writeShort(output, (short) sform_code); // sform_code
		writeFloat(output, quaterns[2]); // quatern_b
		writeFloat(output, quaterns[3]); // quatern_c
		writeFloat(output, quaterns[4]); // quatern_d

		writeFloat(output, qoffset_x); // qoffset_x
		writeFloat(output, qoffset_y); // qoffset_y
		writeFloat(output, qoffset_z); // qoffset_z

		for (i = 0; i < 3; i++) {
			for (int j = 0; j < 4; j++)
				writeFloat(output, srow[i][j]); // srow_x, srow_y, srow_z
		}

		desc = (nfti_hdr == null) ? "" : nfti_hdr.intent_name.trim();
		length = desc.length();
		if (length > 16) {
			output.writeBytes(desc.substring(0, 16));
		} else {
			output.writeBytes(desc);
			for (i = length; i < 16; i++)
				output.write(0);
		}

		output.writeBytes((type==NIFTI_ANALYZE) ? "ni1\0" : "n+1\0" );
		if (type == NIFTI_FILE)
			output.writeInt(0); // extension
		// }

	}

	private void writeRGBPlanar(ImagePlus imp, OutputStream out) throws IOException {
		ImageStack stack = null;
		int nImages = imp.getStackSize();
		if (nImages > 1)
			stack = imp.getStack();

		int w = imp.getWidth();
		int h = imp.getHeight();
		byte[] r, g, b;

		for (int i = 1; i <= nImages; i++) {
			ColorProcessor cp = (nImages == 1) ? (ColorProcessor) imp.getProcessor()
					: (ColorProcessor) stack.getProcessor(i);
			r = new byte[w * h];
			g = new byte[w * h];
			b = new byte[w * h];
			cp.getRGB(r, g, b);
			out.write(r, 0, w * h);
			out.write(g, 0, w * h);
			out.write(b, 0, w * h);
			IJ.showProgress((double) i / nImages);
		}
	}

	private void writeInt(DataOutputStream input, int value) throws IOException {
		if (littleEndian) {
			byte b1 = (byte) (value & 0xff);
			byte b2 = (byte) ((value >> 8) & 0xff);
			byte b3 = (byte) ((value >> 16) & 0xff);
			byte b4 = (byte) ((value >> 24) & 0xff);
			input.writeByte(b1);
			input.writeByte(b2);
			input.writeByte(b3);
			input.writeByte(b4);
		} else {
			input.writeInt(value);
		}
	}

	private void writeShort(DataOutputStream input, short value) throws IOException {

		if (littleEndian) {
			byte b1 = (byte) (value & 0xff);
			byte b2 = (byte) ((value >> 8) & 0xff);
			input.writeByte(b1);
			input.writeByte(b2);
		} else {
			input.writeShort(value);
		}
	}

	private void writeFloat(DataOutputStream input, float value) throws IOException {
		writeInt(input, Float.floatToIntBits(value));
	}

	private void writeFloat(DataOutputStream input, double value) throws IOException {
		writeFloat(input, (float) value);
	}

	// boolean is16BitSigned(ImagePlus imp) {
	// if (imp.getType() != ImagePlus.GRAY16) return false;
	// int min = 65536, max = 0;
	// ImageStack s = imp.getStack();
	// int sliceSize = imp.getWidth()*imp.getHeight();
	// for (int i=1; i<=s.getSize(); i++) {
	// short [] pixels = (short []) s.getProcessor(i).getPixels();
	// for (int j=0; j<sliceSize; j++) {
	// min = (min<(pixels[j]&0xffff)) ? min : pixels[j]&0xffff;
	// max = (max>(pixels[j]&0xffff)) ? max : pixels[j]&0xffff;
	// }
	// }
	// return (max>32767);

	// Old version
	// Calibration c = imp.getCalibration();
	// if (c.getFunction()!=Calibration.STRAIGHT_LINE) return false;
	// double [] coeff = c.getCoefficients();
	// if (coeff[1] == 0.0) return false;
	// return (coeff[0] == - 32768.0 * coeff[1]);
	// }

	// void add(ImagePlus imp, int value) {
	// //IJ.log("add: "+value);
	// ImageStack stack = imp.getStack();
	// for (int slice=1; slice<=stack.getSize(); slice++) {
	// ImageProcessor ip = stack.getProcessor(slice);
	// short[] pixels = (short[])ip.getPixels();
	// for (int i=0; i<pixels.length; i++)
	// pixels[i] = (short)((pixels[i]&0xffff)+value);
	// }
	// }
}